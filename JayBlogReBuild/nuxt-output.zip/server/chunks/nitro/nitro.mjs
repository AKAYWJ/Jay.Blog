import process from 'node:process';globalThis._importMeta_=globalThis._importMeta_||{url:"file:///_entry.js",env:process.env};import http, { Server as Server$1 } from 'node:http';
import https, { Server } from 'node:https';
import { EventEmitter } from 'node:events';
import { Buffer as Buffer$1 } from 'node:buffer';
import { promises, existsSync } from 'node:fs';
import { resolve as resolve$1, dirname as dirname$1, join } from 'node:path';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';

const suspectProtoRx = /"(?:_|\\u0{2}5[Ff]){2}(?:p|\\u0{2}70)(?:r|\\u0{2}72)(?:o|\\u0{2}6[Ff])(?:t|\\u0{2}74)(?:o|\\u0{2}6[Ff])(?:_|\\u0{2}5[Ff]){2}"\s*:/;
const suspectConstructorRx = /"(?:c|\\u0063)(?:o|\\u006[Ff])(?:n|\\u006[Ee])(?:s|\\u0073)(?:t|\\u0074)(?:r|\\u0072)(?:u|\\u0075)(?:c|\\u0063)(?:t|\\u0074)(?:o|\\u006[Ff])(?:r|\\u0072)"\s*:/;
const JsonSigRx = /^\s*["[{]|^\s*-?\d{1,16}(\.\d{1,17})?([Ee][+-]?\d+)?\s*$/;
function jsonParseTransform(key, value) {
  if (key === "__proto__" || key === "constructor" && value && typeof value === "object" && "prototype" in value) {
    warnKeyDropped(key);
    return;
  }
  return value;
}
function warnKeyDropped(key) {
  console.warn(`[destr] Dropping "${key}" key to prevent prototype pollution.`);
}
function destr(value, options = {}) {
  if (typeof value !== "string") {
    return value;
  }
  if (value[0] === '"' && value[value.length - 1] === '"' && value.indexOf("\\") === -1) {
    return value.slice(1, -1);
  }
  const _value = value.trim();
  if (_value.length <= 9) {
    switch (_value.toLowerCase()) {
      case "true": {
        return true;
      }
      case "false": {
        return false;
      }
      case "undefined": {
        return void 0;
      }
      case "null": {
        return null;
      }
      case "nan": {
        return Number.NaN;
      }
      case "infinity": {
        return Number.POSITIVE_INFINITY;
      }
      case "-infinity": {
        return Number.NEGATIVE_INFINITY;
      }
    }
  }
  if (!JsonSigRx.test(value)) {
    if (options.strict) {
      throw new SyntaxError("[destr] Invalid JSON");
    }
    return value;
  }
  try {
    if (suspectProtoRx.test(value) || suspectConstructorRx.test(value)) {
      if (options.strict) {
        throw new Error("[destr] Possible prototype pollution");
      }
      return JSON.parse(value, jsonParseTransform);
    }
    return JSON.parse(value);
  } catch (error) {
    if (options.strict) {
      throw error;
    }
    return value;
  }
}

const HASH_RE = /#/g;
const AMPERSAND_RE = /&/g;
const SLASH_RE = /\//g;
const EQUAL_RE = /=/g;
const IM_RE = /\?/g;
const PLUS_RE = /\+/g;
const ENC_CARET_RE = /%5e/gi;
const ENC_BACKTICK_RE = /%60/gi;
const ENC_PIPE_RE = /%7c/gi;
const ENC_SPACE_RE = /%20/gi;
const ENC_SLASH_RE = /%2f/gi;
const ENC_ENC_SLASH_RE = /%252f/gi;
function encode(text) {
  return encodeURI("" + text).replace(ENC_PIPE_RE, "|");
}
function encodeQueryValue(input) {
  return encode(typeof input === "string" ? input : JSON.stringify(input)).replace(PLUS_RE, "%2B").replace(ENC_SPACE_RE, "+").replace(HASH_RE, "%23").replace(AMPERSAND_RE, "%26").replace(ENC_BACKTICK_RE, "`").replace(ENC_CARET_RE, "^").replace(SLASH_RE, "%2F");
}
function encodeQueryKey(text) {
  return encodeQueryValue(text).replace(EQUAL_RE, "%3D");
}
function encodePath(text) {
  return encode(text).replace(HASH_RE, "%23").replace(IM_RE, "%3F").replace(ENC_ENC_SLASH_RE, "%2F").replace(AMPERSAND_RE, "%26").replace(PLUS_RE, "%2B");
}
function decode$1(text = "") {
  try {
    return decodeURIComponent("" + text);
  } catch {
    return "" + text;
  }
}
function decodePath(text) {
  return decode$1(text.replace(ENC_SLASH_RE, "%252F"));
}
function decodeQueryKey(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}
function decodeQueryValue(text) {
  return decode$1(text.replace(PLUS_RE, " "));
}

function parseQuery(parametersString = "") {
  const object = /* @__PURE__ */ Object.create(null);
  if (parametersString[0] === "?") {
    parametersString = parametersString.slice(1);
  }
  for (const parameter of parametersString.split("&")) {
    const s = parameter.match(/([^=]+)=?(.*)/) || [];
    if (s.length < 2) {
      continue;
    }
    const key = decodeQueryKey(s[1]);
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = decodeQueryValue(s[2] || "");
    if (object[key] === void 0) {
      object[key] = value;
    } else if (Array.isArray(object[key])) {
      object[key].push(value);
    } else {
      object[key] = [object[key], value];
    }
  }
  return object;
}
function encodeQueryItem(key, value) {
  if (typeof value === "number" || typeof value === "boolean") {
    value = String(value);
  }
  if (!value) {
    return encodeQueryKey(key);
  }
  if (Array.isArray(value)) {
    return value.map(
      (_value) => `${encodeQueryKey(key)}=${encodeQueryValue(_value)}`
    ).join("&");
  }
  return `${encodeQueryKey(key)}=${encodeQueryValue(value)}`;
}
function stringifyQuery(query) {
  return Object.keys(query).filter((k) => query[k] !== void 0).map((k) => encodeQueryItem(k, query[k])).filter(Boolean).join("&");
}

const PROTOCOL_STRICT_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{1,2})/;
const PROTOCOL_REGEX = /^[\s\w\0+.-]{2,}:([/\\]{2})?/;
const PROTOCOL_RELATIVE_REGEX = /^([/\\]\s*){2,}[^/\\]/;
const PROTOCOL_SCRIPT_RE = /^[\s\0]*(blob|data|javascript|vbscript):$/i;
const TRAILING_SLASH_RE = /\/$|\/\?|\/#/;
const JOIN_LEADING_SLASH_RE = /^\.?\//;
function hasProtocol(inputString, opts = {}) {
  if (typeof opts === "boolean") {
    opts = { acceptRelative: opts };
  }
  if (opts.strict) {
    return PROTOCOL_STRICT_REGEX.test(inputString);
  }
  return PROTOCOL_REGEX.test(inputString) || (opts.acceptRelative ? PROTOCOL_RELATIVE_REGEX.test(inputString) : false);
}
function isScriptProtocol(protocol) {
  return !!protocol && PROTOCOL_SCRIPT_RE.test(protocol);
}
function hasTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/");
  }
  return TRAILING_SLASH_RE.test(input);
}
function withoutTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return (hasTrailingSlash(input) ? input.slice(0, -1) : input) || "/";
  }
  if (!hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
  }
  const [s0, ...s] = path.split("?");
  const cleanPath = s0.endsWith("/") ? s0.slice(0, -1) : s0;
  return (cleanPath || "/") + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function withTrailingSlash(input = "", respectQueryAndFragment) {
  if (!respectQueryAndFragment) {
    return input.endsWith("/") ? input : input + "/";
  }
  if (hasTrailingSlash(input, true)) {
    return input || "/";
  }
  let path = input;
  let fragment = "";
  const fragmentIndex = input.indexOf("#");
  if (fragmentIndex !== -1) {
    path = input.slice(0, fragmentIndex);
    fragment = input.slice(fragmentIndex);
    if (!path) {
      return fragment;
    }
  }
  const [s0, ...s] = path.split("?");
  return s0 + "/" + (s.length > 0 ? `?${s.join("?")}` : "") + fragment;
}
function hasLeadingSlash(input = "") {
  return input.startsWith("/");
}
function withLeadingSlash(input = "") {
  return hasLeadingSlash(input) ? input : "/" + input;
}
function withBase(input, base) {
  if (isEmptyURL(base) || hasProtocol(input)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (input.startsWith(_base)) {
    const nextChar = input[_base.length];
    if (!nextChar || nextChar === "/" || nextChar === "?") {
      return input;
    }
  }
  return joinURL(_base, input);
}
function withoutBase(input, base) {
  if (isEmptyURL(base)) {
    return input;
  }
  const _base = withoutTrailingSlash(base);
  if (!input.startsWith(_base)) {
    return input;
  }
  const nextChar = input[_base.length];
  if (nextChar && nextChar !== "/" && nextChar !== "?") {
    return input;
  }
  const trimmed = input.slice(_base.length).replace(/^\/+/, "");
  return "/" + trimmed;
}
function withQuery(input, query) {
  const parsed = parseURL(input);
  const mergedQuery = { ...parseQuery(parsed.search), ...query };
  parsed.search = stringifyQuery(mergedQuery);
  return stringifyParsedURL(parsed);
}
function getQuery$1(input) {
  return parseQuery(parseURL(input).search);
}
function isEmptyURL(url) {
  return !url || url === "/";
}
function isNonEmptyURL(url) {
  return url && url !== "/";
}
function joinURL(base, ...input) {
  let url = base || "";
  for (const segment of input.filter((url2) => isNonEmptyURL(url2))) {
    if (url) {
      const _segment = segment.replace(JOIN_LEADING_SLASH_RE, "");
      url = withTrailingSlash(url) + _segment;
    } else {
      url = segment;
    }
  }
  return url;
}
function joinRelativeURL(..._input) {
  const JOIN_SEGMENT_SPLIT_RE = /\/(?!\/)/;
  const input = _input.filter(Boolean);
  const segments = [];
  let segmentsDepth = 0;
  for (const i of input) {
    if (!i || i === "/") {
      continue;
    }
    for (const [sindex, s] of i.split(JOIN_SEGMENT_SPLIT_RE).entries()) {
      if (!s || s === ".") {
        continue;
      }
      if (s === "..") {
        if (segments.length === 1 && hasProtocol(segments[0])) {
          continue;
        }
        segments.pop();
        segmentsDepth--;
        continue;
      }
      if (sindex === 1 && segments[segments.length - 1]?.endsWith(":/")) {
        segments[segments.length - 1] += "/" + s;
        continue;
      }
      segments.push(s);
      segmentsDepth++;
    }
  }
  let url = segments.join("/");
  if (segmentsDepth >= 0) {
    if (input[0]?.startsWith("/") && !url.startsWith("/")) {
      url = "/" + url;
    } else if (input[0]?.startsWith("./") && !url.startsWith("./")) {
      url = "./" + url;
    }
  } else {
    url = "../".repeat(-1 * segmentsDepth) + url;
  }
  if (input[input.length - 1]?.endsWith("/") && !url.endsWith("/")) {
    url += "/";
  }
  return url;
}

const protocolRelative = Symbol.for("ufo:protocolRelative");
function parseURL(input = "", defaultProto) {
  const _specialProtoMatch = input.match(
    /^[\s\0]*(blob:|data:|javascript:|vbscript:)(.*)/i
  );
  if (_specialProtoMatch) {
    const [, _proto, _pathname = ""] = _specialProtoMatch;
    return {
      protocol: _proto.toLowerCase(),
      pathname: _pathname,
      href: _proto + _pathname,
      auth: "",
      host: "",
      search: "",
      hash: ""
    };
  }
  if (!hasProtocol(input, { acceptRelative: true })) {
    return parsePath(input);
  }
  const [, protocol = "", auth, hostAndPath = ""] = input.replace(/\\/g, "/").match(/^[\s\0]*([\w+.-]{2,}:)?\/\/([^/@]+@)?(.*)/) || [];
  let [, host = "", path = ""] = hostAndPath.match(/([^#/?]*)(.*)?/) || [];
  if (protocol === "file:") {
    path = path.replace(/\/(?=[A-Za-z]:)/, "");
  }
  const { pathname, search, hash } = parsePath(path);
  return {
    protocol: protocol.toLowerCase(),
    auth: auth ? auth.slice(0, Math.max(0, auth.length - 1)) : "",
    host,
    pathname,
    search,
    hash,
    [protocolRelative]: !protocol
  };
}
function parsePath(input = "") {
  const [pathname = "", search = "", hash = ""] = (input.match(/([^#?]*)(\?[^#]*)?(#.*)?/) || []).splice(1);
  return {
    pathname,
    search,
    hash
  };
}
function stringifyParsedURL(parsed) {
  const pathname = parsed.pathname || "";
  const search = parsed.search ? (parsed.search.startsWith("?") ? "" : "?") + parsed.search : "";
  const hash = parsed.hash || "";
  const auth = parsed.auth ? parsed.auth + "@" : "";
  const host = parsed.host || "";
  const proto = parsed.protocol || parsed[protocolRelative] ? (parsed.protocol || "") + "//" : "";
  return proto + auth + host + pathname + search + hash;
}

const NullObject = /* @__PURE__ */ (() => {
  const C = function() {
  };
  C.prototype = /* @__PURE__ */ Object.create(null);
  return C;
})();
function parse(str, options) {
  if (typeof str !== "string") {
    throw new TypeError("argument str must be a string");
  }
  const obj = new NullObject();
  const opt = {};
  const dec = opt.decode || decode;
  let index = 0;
  while (index < str.length) {
    const eqIdx = str.indexOf("=", index);
    if (eqIdx === -1) {
      break;
    }
    let endIdx = str.indexOf(";", index);
    if (endIdx === -1) {
      endIdx = str.length;
    } else if (endIdx < eqIdx) {
      index = str.lastIndexOf(";", eqIdx - 1) + 1;
      continue;
    }
    const key = str.slice(index, eqIdx).trim();
    if (opt?.filter && !opt?.filter(key)) {
      index = endIdx + 1;
      continue;
    }
    if (void 0 === obj[key]) {
      let val = str.slice(eqIdx + 1, endIdx).trim();
      if (val.codePointAt(0) === 34) {
        val = val.slice(1, -1);
      }
      obj[key] = tryDecode(val, dec);
    }
    index = endIdx + 1;
  }
  return obj;
}
function decode(str) {
  return str.includes("%") ? decodeURIComponent(str) : str;
}
function tryDecode(str, decode2) {
  try {
    return decode2(str);
  } catch {
    return str;
  }
}

const fieldContentRegExp = /^[\u0009\u0020-\u007E\u0080-\u00FF]+$/;
function serialize$2(name, value, options) {
  const opt = options || {};
  const enc = opt.encode || encodeURIComponent;
  if (typeof enc !== "function") {
    throw new TypeError("option encode is invalid");
  }
  if (!fieldContentRegExp.test(name)) {
    throw new TypeError("argument name is invalid");
  }
  const encodedValue = enc(value);
  if (encodedValue && !fieldContentRegExp.test(encodedValue)) {
    throw new TypeError("argument val is invalid");
  }
  let str = name + "=" + encodedValue;
  if (void 0 !== opt.maxAge && opt.maxAge !== null) {
    const maxAge = opt.maxAge - 0;
    if (Number.isNaN(maxAge) || !Number.isFinite(maxAge)) {
      throw new TypeError("option maxAge is invalid");
    }
    str += "; Max-Age=" + Math.floor(maxAge);
  }
  if (opt.domain) {
    if (!fieldContentRegExp.test(opt.domain)) {
      throw new TypeError("option domain is invalid");
    }
    str += "; Domain=" + opt.domain;
  }
  if (opt.path) {
    if (!fieldContentRegExp.test(opt.path)) {
      throw new TypeError("option path is invalid");
    }
    str += "; Path=" + opt.path;
  }
  if (opt.expires) {
    if (!isDate(opt.expires) || Number.isNaN(opt.expires.valueOf())) {
      throw new TypeError("option expires is invalid");
    }
    str += "; Expires=" + opt.expires.toUTCString();
  }
  if (opt.httpOnly) {
    str += "; HttpOnly";
  }
  if (opt.secure) {
    str += "; Secure";
  }
  if (opt.priority) {
    const priority = typeof opt.priority === "string" ? opt.priority.toLowerCase() : opt.priority;
    switch (priority) {
      case "low": {
        str += "; Priority=Low";
        break;
      }
      case "medium": {
        str += "; Priority=Medium";
        break;
      }
      case "high": {
        str += "; Priority=High";
        break;
      }
      default: {
        throw new TypeError("option priority is invalid");
      }
    }
  }
  if (opt.sameSite) {
    const sameSite = typeof opt.sameSite === "string" ? opt.sameSite.toLowerCase() : opt.sameSite;
    switch (sameSite) {
      case true: {
        str += "; SameSite=Strict";
        break;
      }
      case "lax": {
        str += "; SameSite=Lax";
        break;
      }
      case "strict": {
        str += "; SameSite=Strict";
        break;
      }
      case "none": {
        str += "; SameSite=None";
        break;
      }
      default: {
        throw new TypeError("option sameSite is invalid");
      }
    }
  }
  if (opt.partitioned) {
    str += "; Partitioned";
  }
  return str;
}
function isDate(val) {
  return Object.prototype.toString.call(val) === "[object Date]" || val instanceof Date;
}

function parseSetCookie(setCookieValue, options) {
  const parts = (setCookieValue || "").split(";").filter((str) => typeof str === "string" && !!str.trim());
  const nameValuePairStr = parts.shift() || "";
  const parsed = _parseNameValuePair(nameValuePairStr);
  const name = parsed.name;
  let value = parsed.value;
  try {
    value = options?.decode === false ? value : (options?.decode || decodeURIComponent)(value);
  } catch {
  }
  const cookie = {
    name,
    value
  };
  for (const part of parts) {
    const sides = part.split("=");
    const partKey = (sides.shift() || "").trimStart().toLowerCase();
    const partValue = sides.join("=");
    switch (partKey) {
      case "expires": {
        cookie.expires = new Date(partValue);
        break;
      }
      case "max-age": {
        cookie.maxAge = Number.parseInt(partValue, 10);
        break;
      }
      case "secure": {
        cookie.secure = true;
        break;
      }
      case "httponly": {
        cookie.httpOnly = true;
        break;
      }
      case "samesite": {
        cookie.sameSite = partValue;
        break;
      }
      default: {
        cookie[partKey] = partValue;
      }
    }
  }
  return cookie;
}
function _parseNameValuePair(nameValuePairStr) {
  let name = "";
  let value = "";
  const nameValueArr = nameValuePairStr.split("=");
  if (nameValueArr.length > 1) {
    name = nameValueArr.shift();
    value = nameValueArr.join("=");
  } else {
    value = nameValuePairStr;
  }
  return { name, value };
}

const NODE_TYPES = {
  NORMAL: 0,
  WILDCARD: 1,
  PLACEHOLDER: 2
};

function createRouter$1(options = {}) {
  const ctx = {
    options,
    rootNode: createRadixNode(),
    staticRoutesMap: {}
  };
  const normalizeTrailingSlash = (p) => options.strictTrailingSlash ? p : p.replace(/\/$/, "") || "/";
  if (options.routes) {
    for (const path in options.routes) {
      insert(ctx, normalizeTrailingSlash(path), options.routes[path]);
    }
  }
  return {
    ctx,
    lookup: (path) => lookup(ctx, normalizeTrailingSlash(path)),
    insert: (path, data) => insert(ctx, normalizeTrailingSlash(path), data),
    remove: (path) => remove(ctx, normalizeTrailingSlash(path))
  };
}
function lookup(ctx, path) {
  const staticPathNode = ctx.staticRoutesMap[path];
  if (staticPathNode) {
    return staticPathNode.data;
  }
  const sections = path.split("/");
  const params = {};
  let paramsFound = false;
  let wildcardNode = null;
  let node = ctx.rootNode;
  let wildCardParam = null;
  for (let i = 0; i < sections.length; i++) {
    const section = sections[i];
    if (node.wildcardChildNode !== null) {
      wildcardNode = node.wildcardChildNode;
      wildCardParam = sections.slice(i).join("/");
    }
    const nextNode = node.children.get(section);
    if (nextNode === void 0) {
      if (node && node.placeholderChildren.length > 1) {
        const remaining = sections.length - i;
        node = node.placeholderChildren.find((c) => c.maxDepth === remaining) || null;
      } else {
        node = node.placeholderChildren[0] || null;
      }
      if (!node) {
        break;
      }
      if (node.paramName) {
        params[node.paramName] = section;
      }
      paramsFound = true;
    } else {
      node = nextNode;
    }
  }
  if ((node === null || node.data === null) && wildcardNode !== null) {
    node = wildcardNode;
    params[node.paramName || "_"] = wildCardParam;
    paramsFound = true;
  }
  if (!node) {
    return null;
  }
  if (paramsFound) {
    return {
      ...node.data,
      params: paramsFound ? params : void 0
    };
  }
  return node.data;
}
function insert(ctx, path, data) {
  let isStaticRoute = true;
  const sections = path.split("/");
  let node = ctx.rootNode;
  let _unnamedPlaceholderCtr = 0;
  const matchedNodes = [node];
  for (const section of sections) {
    let childNode;
    if (childNode = node.children.get(section)) {
      node = childNode;
    } else {
      const type = getNodeType(section);
      childNode = createRadixNode({ type, parent: node });
      node.children.set(section, childNode);
      if (type === NODE_TYPES.PLACEHOLDER) {
        childNode.paramName = section === "*" ? `_${_unnamedPlaceholderCtr++}` : section.slice(1);
        node.placeholderChildren.push(childNode);
        isStaticRoute = false;
      } else if (type === NODE_TYPES.WILDCARD) {
        node.wildcardChildNode = childNode;
        childNode.paramName = section.slice(
          3
          /* "**:" */
        ) || "_";
        isStaticRoute = false;
      }
      matchedNodes.push(childNode);
      node = childNode;
    }
  }
  for (const [depth, node2] of matchedNodes.entries()) {
    node2.maxDepth = Math.max(matchedNodes.length - depth, node2.maxDepth || 0);
  }
  node.data = data;
  if (isStaticRoute === true) {
    ctx.staticRoutesMap[path] = node;
  }
  return node;
}
function remove(ctx, path) {
  let success = false;
  const sections = path.split("/");
  let node = ctx.rootNode;
  for (const section of sections) {
    node = node.children.get(section);
    if (!node) {
      return success;
    }
  }
  if (node.data) {
    const lastSection = sections.at(-1) || "";
    node.data = null;
    if (Object.keys(node.children).length === 0 && node.parent) {
      node.parent.children.delete(lastSection);
      node.parent.wildcardChildNode = null;
      node.parent.placeholderChildren = [];
    }
    success = true;
  }
  return success;
}
function createRadixNode(options = {}) {
  return {
    type: options.type || NODE_TYPES.NORMAL,
    maxDepth: 0,
    parent: options.parent || null,
    children: /* @__PURE__ */ new Map(),
    data: options.data || null,
    paramName: options.paramName || null,
    wildcardChildNode: null,
    placeholderChildren: []
  };
}
function getNodeType(str) {
  if (str.startsWith("**")) {
    return NODE_TYPES.WILDCARD;
  }
  if (str[0] === ":" || str === "*") {
    return NODE_TYPES.PLACEHOLDER;
  }
  return NODE_TYPES.NORMAL;
}

function toRouteMatcher(router) {
  const table = _routerNodeToTable("", router.ctx.rootNode);
  return _createMatcher(table, router.ctx.options.strictTrailingSlash);
}
function _createMatcher(table, strictTrailingSlash) {
  return {
    ctx: { table },
    matchAll: (path) => _matchRoutes(path, table, strictTrailingSlash)
  };
}
function _createRouteTable() {
  return {
    static: /* @__PURE__ */ new Map(),
    wildcard: /* @__PURE__ */ new Map(),
    dynamic: /* @__PURE__ */ new Map()
  };
}
function _matchRoutes(path, table, strictTrailingSlash) {
  if (strictTrailingSlash !== true && path.endsWith("/")) {
    path = path.slice(0, -1) || "/";
  }
  const matches = [];
  for (const [key, value] of _sortRoutesMap(table.wildcard)) {
    if (path === key || path.startsWith(key + "/")) {
      matches.push(value);
    }
  }
  for (const [key, value] of _sortRoutesMap(table.dynamic)) {
    if (path.startsWith(key + "/")) {
      const subPath = "/" + path.slice(key.length).split("/").splice(2).join("/");
      matches.push(..._matchRoutes(subPath, value));
    }
  }
  const staticMatch = table.static.get(path);
  if (staticMatch) {
    matches.push(staticMatch);
  }
  return matches.filter(Boolean);
}
function _sortRoutesMap(m) {
  return [...m.entries()].sort((a, b) => a[0].length - b[0].length);
}
function _routerNodeToTable(initialPath, initialNode) {
  const table = _createRouteTable();
  function _addNode(path, node) {
    if (path) {
      if (node.type === NODE_TYPES.NORMAL && !(path.includes("*") || path.includes(":"))) {
        if (node.data) {
          table.static.set(path, node.data);
        }
      } else if (node.type === NODE_TYPES.WILDCARD) {
        table.wildcard.set(path.replace("/**", ""), node.data);
      } else if (node.type === NODE_TYPES.PLACEHOLDER) {
        const subTable = _routerNodeToTable("", node);
        if (node.data) {
          subTable.static.set("/", node.data);
        }
        table.dynamic.set(path.replace(/\/\*|\/:\w+/, ""), subTable);
        return;
      }
    }
    for (const [childPath, child] of node.children.entries()) {
      _addNode(`${path}/${childPath}`.replace("//", "/"), child);
    }
  }
  _addNode(initialPath, initialNode);
  return table;
}

function isPlainObject(value) {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== null && prototype !== Object.prototype && Object.getPrototypeOf(prototype) !== null) {
    return false;
  }
  if (Symbol.iterator in value) {
    return false;
  }
  if (Symbol.toStringTag in value) {
    return Object.prototype.toString.call(value) === "[object Module]";
  }
  return true;
}

function _defu(baseObject, defaults, namespace = ".", merger) {
  if (!isPlainObject(defaults)) {
    return _defu(baseObject, {}, namespace, merger);
  }
  const object = { ...defaults };
  for (const key of Object.keys(baseObject)) {
    if (key === "__proto__" || key === "constructor") {
      continue;
    }
    const value = baseObject[key];
    if (value === null || value === void 0) {
      continue;
    }
    if (merger && merger(object, key, value, namespace)) {
      continue;
    }
    if (Array.isArray(value) && Array.isArray(object[key])) {
      object[key] = [...value, ...object[key]];
    } else if (isPlainObject(value) && isPlainObject(object[key])) {
      object[key] = _defu(
        value,
        object[key],
        (namespace ? `${namespace}.` : "") + key.toString(),
        merger
      );
    } else {
      object[key] = value;
    }
  }
  return object;
}
function createDefu(merger) {
  return (...arguments_) => (
    // eslint-disable-next-line unicorn/no-array-reduce
    arguments_.reduce((p, c) => _defu(p, c, "", merger), {})
  );
}
const defu = createDefu();
const defuFn = createDefu((object, key, currentValue) => {
  if (object[key] !== void 0 && typeof currentValue === "function") {
    object[key] = currentValue(object[key]);
    return true;
  }
});

function o(n){throw new Error(`${n} is not implemented yet!`)}let i$1 = class i extends EventEmitter{__unenv__={};readableEncoding=null;readableEnded=true;readableFlowing=false;readableHighWaterMark=0;readableLength=0;readableObjectMode=false;readableAborted=false;readableDidRead=false;closed=false;errored=null;readable=false;destroyed=false;static from(e,t){return new i(t)}constructor(e){super();}_read(e){}read(e){}setEncoding(e){return this}pause(){return this}resume(){return this}isPaused(){return  true}unpipe(e){return this}unshift(e,t){}wrap(e){return this}push(e,t){return  false}_destroy(e,t){this.removeAllListeners();}destroy(e){return this.destroyed=true,this._destroy(e),this}pipe(e,t){return {}}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return this.destroy(),Promise.resolve()}async*[Symbol.asyncIterator](){throw o("Readable.asyncIterator")}iterator(e){throw o("Readable.iterator")}map(e,t){throw o("Readable.map")}filter(e,t){throw o("Readable.filter")}forEach(e,t){throw o("Readable.forEach")}reduce(e,t,r){throw o("Readable.reduce")}find(e,t){throw o("Readable.find")}findIndex(e,t){throw o("Readable.findIndex")}some(e,t){throw o("Readable.some")}toArray(e){throw o("Readable.toArray")}every(e,t){throw o("Readable.every")}flatMap(e,t){throw o("Readable.flatMap")}drop(e,t){throw o("Readable.drop")}take(e,t){throw o("Readable.take")}asIndexedPairs(e){throw o("Readable.asIndexedPairs")}};let l$1 = class l extends EventEmitter{__unenv__={};writable=true;writableEnded=false;writableFinished=false;writableHighWaterMark=0;writableLength=0;writableObjectMode=false;writableCorked=0;closed=false;errored=null;writableNeedDrain=false;writableAborted=false;destroyed=false;_data;_encoding="utf8";constructor(e){super();}pipe(e,t){return {}}_write(e,t,r){if(this.writableEnded){r&&r();return}if(this._data===void 0)this._data=e;else {const s=typeof this._data=="string"?Buffer$1.from(this._data,this._encoding||t||"utf8"):this._data,a=typeof e=="string"?Buffer$1.from(e,t||this._encoding||"utf8"):e;this._data=Buffer$1.concat([s,a]);}this._encoding=t,r&&r();}_writev(e,t){}_destroy(e,t){}_final(e){}write(e,t,r){const s=typeof t=="string"?this._encoding:"utf8",a=typeof t=="function"?t:typeof r=="function"?r:void 0;return this._write(e,s,a),true}setDefaultEncoding(e){return this}end(e,t,r){const s=typeof e=="function"?e:typeof t=="function"?t:typeof r=="function"?r:void 0;if(this.writableEnded)return s&&s(),this;const a=e===s?void 0:e;if(a){const u=t===s?void 0:t;this.write(a,u,s);}return this.writableEnded=true,this.writableFinished=true,this.emit("close"),this.emit("finish"),this}cork(){}uncork(){}destroy(e){return this.destroyed=true,delete this._data,this.removeAllListeners(),this}compose(e,t){throw new Error("Method not implemented.")}[Symbol.asyncDispose](){return Promise.resolve()}};const c$1=class c{allowHalfOpen=true;_destroy;constructor(e=new i$1,t=new l$1){Object.assign(this,e),Object.assign(this,t),this._destroy=m(e._destroy,t._destroy);}};function _(){return Object.assign(c$1.prototype,i$1.prototype),Object.assign(c$1.prototype,l$1.prototype),c$1}function m(...n){return function(...e){for(const t of n)t(...e);}}const g=_();class A extends g{__unenv__={};bufferSize=0;bytesRead=0;bytesWritten=0;connecting=false;destroyed=false;pending=false;localAddress="";localPort=0;remoteAddress="";remoteFamily="";remotePort=0;autoSelectFamilyAttemptedAddresses=[];readyState="readOnly";constructor(e){super();}write(e,t,r){return  false}connect(e,t,r){return this}end(e,t,r){return this}setEncoding(e){return this}pause(){return this}resume(){return this}setTimeout(e,t){return this}setNoDelay(e){return this}setKeepAlive(e,t){return this}address(){return {}}unref(){return this}ref(){return this}destroySoon(){this.destroy();}resetAndDestroy(){const e=new Error("ERR_SOCKET_CLOSED");return e.code="ERR_SOCKET_CLOSED",this.destroy(e),this}}class y extends i$1{aborted=false;httpVersion="1.1";httpVersionMajor=1;httpVersionMinor=1;complete=true;connection;socket;headers={};trailers={};method="GET";url="/";statusCode=200;statusMessage="";closed=false;errored=null;readable=false;constructor(e){super(),this.socket=this.connection=e||new A;}get rawHeaders(){const e=this.headers,t=[];for(const r in e)if(Array.isArray(e[r]))for(const s of e[r])t.push(r,s);else t.push(r,e[r]);return t}get rawTrailers(){return []}setTimeout(e,t){return this}get headersDistinct(){return p(this.headers)}get trailersDistinct(){return p(this.trailers)}}function p(n){const e={};for(const[t,r]of Object.entries(n))t&&(e[t]=(Array.isArray(r)?r:[r]).filter(Boolean));return e}class w extends l$1{statusCode=200;statusMessage="";upgrading=false;chunkedEncoding=false;shouldKeepAlive=false;useChunkedEncodingByDefault=false;sendDate=false;finished=false;headersSent=false;strictContentLength=false;connection=null;socket=null;req;_headers={};constructor(e){super(),this.req=e;}assignSocket(e){e._httpMessage=this,this.socket=e,this.connection=e,this.emit("socket",e),this._flush();}_flush(){this.flushHeaders();}detachSocket(e){}writeContinue(e){}writeHead(e,t,r){e&&(this.statusCode=e),typeof t=="string"&&(this.statusMessage=t,t=void 0);const s=r||t;if(s&&!Array.isArray(s))for(const a in s)this.setHeader(a,s[a]);return this.headersSent=true,this}writeProcessing(){}setTimeout(e,t){return this}appendHeader(e,t){e=e.toLowerCase();const r=this._headers[e],s=[...Array.isArray(r)?r:[r],...Array.isArray(t)?t:[t]].filter(Boolean);return this._headers[e]=s.length>1?s:s[0],this}setHeader(e,t){return this._headers[e.toLowerCase()]=t,this}setHeaders(e){for(const[t,r]of Object.entries(e))this.setHeader(t,r);return this}getHeader(e){return this._headers[e.toLowerCase()]}getHeaders(){return this._headers}getHeaderNames(){return Object.keys(this._headers)}hasHeader(e){return e.toLowerCase()in this._headers}removeHeader(e){delete this._headers[e.toLowerCase()];}addTrailers(e){}flushHeaders(){}writeEarlyHints(e,t){typeof t=="function"&&t();}}const E=(()=>{const n=function(){};return n.prototype=Object.create(null),n})();function R(n={}){const e=new E,t=Array.isArray(n)||H(n)?n:Object.entries(n);for(const[r,s]of t)if(s){if(e[r]===void 0){e[r]=s;continue}e[r]=[...Array.isArray(e[r])?e[r]:[e[r]],...Array.isArray(s)?s:[s]];}return e}function H(n){return typeof n?.entries=="function"}function v(n={}){if(n instanceof Headers)return n;const e=new Headers;for(const[t,r]of Object.entries(n))if(r!==void 0){if(Array.isArray(r)){for(const s of r)e.append(t,String(s));continue}e.set(t,String(r));}return e}const S=new Set([101,204,205,304]);async function b(n,e){const t=new y,r=new w(t);t.url=e.url?.toString()||"/";let s;if(!t.url.startsWith("/")){const d=new URL(t.url);s=d.host,t.url=d.pathname+d.search+d.hash;}t.method=e.method||"GET",t.headers=R(e.headers||{}),t.headers.host||(t.headers.host=e.host||s||"localhost"),t.connection.encrypted=t.connection.encrypted||e.protocol==="https",t.body=e.body||null,t.__unenv__=e.context,await n(t,r);let a=r._data;(S.has(r.statusCode)||t.method.toUpperCase()==="HEAD")&&(a=null,delete r._headers["content-length"]);const u={status:r.statusCode,statusText:r.statusMessage,headers:r._headers,body:a};return t.destroy(),r.destroy(),u}async function C(n,e,t={}){try{const r=await b(n,{url:e,...t});return new Response(r.body,{status:r.status,statusText:r.statusText,headers:v(r.headers)})}catch(r){return new Response(r.toString(),{status:Number.parseInt(r.statusCode||r.code)||500,statusText:r.statusText})}}

function hasProp(obj, prop) {
  try {
    return prop in obj;
  } catch {
    return false;
  }
}

class H3Error extends Error {
  static __h3_error__ = true;
  statusCode = 500;
  fatal = false;
  unhandled = false;
  statusMessage;
  data;
  cause;
  constructor(message, opts = {}) {
    super(message, opts);
    if (opts.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
  toJSON() {
    const obj = {
      message: this.message,
      statusCode: sanitizeStatusCode(this.statusCode, 500)
    };
    if (this.statusMessage) {
      obj.statusMessage = sanitizeStatusMessage(this.statusMessage);
    }
    if (this.data !== void 0) {
      obj.data = this.data;
    }
    return obj;
  }
}
function createError$1(input) {
  if (typeof input === "string") {
    return new H3Error(input);
  }
  if (isError(input)) {
    return input;
  }
  const err = new H3Error(input.message ?? input.statusMessage ?? "", {
    cause: input.cause || input
  });
  if (hasProp(input, "stack")) {
    try {
      Object.defineProperty(err, "stack", {
        get() {
          return input.stack;
        }
      });
    } catch {
      try {
        err.stack = input.stack;
      } catch {
      }
    }
  }
  if (input.data) {
    err.data = input.data;
  }
  if (input.statusCode) {
    err.statusCode = sanitizeStatusCode(input.statusCode, err.statusCode);
  } else if (input.status) {
    err.statusCode = sanitizeStatusCode(input.status, err.statusCode);
  }
  if (input.statusMessage) {
    err.statusMessage = input.statusMessage;
  } else if (input.statusText) {
    err.statusMessage = input.statusText;
  }
  if (err.statusMessage) {
    const originalMessage = err.statusMessage;
    const sanitizedMessage = sanitizeStatusMessage(err.statusMessage);
    if (sanitizedMessage !== originalMessage) {
      console.warn(
        "[h3] Please prefer using `message` for longer error messages instead of `statusMessage`. In the future, `statusMessage` will be sanitized by default."
      );
    }
  }
  if (input.fatal !== void 0) {
    err.fatal = input.fatal;
  }
  if (input.unhandled !== void 0) {
    err.unhandled = input.unhandled;
  }
  return err;
}
function sendError(event, error, debug) {
  if (event.handled) {
    return;
  }
  const h3Error = isError(error) ? error : createError$1(error);
  const responseBody = {
    statusCode: h3Error.statusCode,
    statusMessage: h3Error.statusMessage,
    stack: [],
    data: h3Error.data
  };
  if (debug) {
    responseBody.stack = (h3Error.stack || "").split("\n").map((l) => l.trim());
  }
  if (event.handled) {
    return;
  }
  const _code = Number.parseInt(h3Error.statusCode);
  setResponseStatus(event, _code, h3Error.statusMessage);
  event.node.res.setHeader("content-type", MIMES.json);
  event.node.res.end(JSON.stringify(responseBody, void 0, 2));
}
function isError(input) {
  return input?.constructor?.__h3_error__ === true;
}

function getQuery(event) {
  return getQuery$1(event.path || "");
}
function isMethod(event, expected, allowHead) {
  if (typeof expected === "string") {
    if (event.method === expected) {
      return true;
    }
  } else if (expected.includes(event.method)) {
    return true;
  }
  return false;
}
function assertMethod(event, expected, allowHead) {
  if (!isMethod(event, expected)) {
    throw createError$1({
      statusCode: 405,
      statusMessage: "HTTP method is not allowed."
    });
  }
}
function getRequestHeaders(event) {
  const _headers = {};
  for (const key in event.node.req.headers) {
    const val = event.node.req.headers[key];
    _headers[key] = Array.isArray(val) ? val.filter(Boolean).join(", ") : val;
  }
  return _headers;
}
function getRequestHeader(event, name) {
  const headers = getRequestHeaders(event);
  const value = headers[name.toLowerCase()];
  return value;
}
function getRequestHost(event, opts = {}) {
  if (opts.xForwardedHost) {
    const _header = event.node.req.headers["x-forwarded-host"];
    const xForwardedHost = (_header || "").split(",").shift()?.trim();
    if (xForwardedHost) {
      return xForwardedHost;
    }
  }
  return event.node.req.headers.host || "localhost";
}
function getRequestProtocol(event, opts = {}) {
  if (opts.xForwardedProto !== false && event.node.req.headers["x-forwarded-proto"] === "https") {
    return "https";
  }
  return event.node.req.connection?.encrypted ? "https" : "http";
}
function getRequestURL(event, opts = {}) {
  const host = getRequestHost(event, opts);
  const protocol = getRequestProtocol(event, opts);
  const path = (event.node.req.originalUrl || event.path).replace(
    /^[/\\]+/g,
    "/"
  );
  return new URL(path, `${protocol}://${host}`);
}

const RawBodySymbol = Symbol.for("h3RawBody");
const PayloadMethods$1 = ["PATCH", "POST", "PUT", "DELETE"];
function readRawBody(event, encoding = "utf8") {
  assertMethod(event, PayloadMethods$1);
  const _rawBody = event._requestBody || event.web?.request?.body || event.node.req[RawBodySymbol] || event.node.req.rawBody || event.node.req.body;
  if (_rawBody) {
    const promise2 = Promise.resolve(_rawBody).then((_resolved) => {
      if (Buffer.isBuffer(_resolved)) {
        return _resolved;
      }
      if (typeof _resolved.pipeTo === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.pipeTo(
            new WritableStream({
              write(chunk) {
                chunks.push(chunk);
              },
              close() {
                resolve(Buffer.concat(chunks));
              },
              abort(reason) {
                reject(reason);
              }
            })
          ).catch(reject);
        });
      } else if (typeof _resolved.pipe === "function") {
        return new Promise((resolve, reject) => {
          const chunks = [];
          _resolved.on("data", (chunk) => {
            chunks.push(chunk);
          }).on("end", () => {
            resolve(Buffer.concat(chunks));
          }).on("error", reject);
        });
      }
      if (_resolved.constructor === Object) {
        return Buffer.from(JSON.stringify(_resolved));
      }
      if (_resolved instanceof URLSearchParams) {
        return Buffer.from(_resolved.toString());
      }
      if (_resolved instanceof FormData) {
        return new Response(_resolved).bytes().then((uint8arr) => Buffer.from(uint8arr));
      }
      return Buffer.from(_resolved);
    });
    return encoding ? promise2.then((buff) => buff.toString(encoding)) : promise2;
  }
  if (!Number.parseInt(event.node.req.headers["content-length"] || "") && !/\bchunked\b/i.test(
    String(event.node.req.headers["transfer-encoding"] ?? "")
  )) {
    return Promise.resolve(void 0);
  }
  const promise = event.node.req[RawBodySymbol] = new Promise(
    (resolve, reject) => {
      const bodyData = [];
      event.node.req.on("error", (err) => {
        reject(err);
      }).on("data", (chunk) => {
        bodyData.push(chunk);
      }).on("end", () => {
        resolve(Buffer.concat(bodyData));
      });
    }
  );
  const result = encoding ? promise.then((buff) => buff.toString(encoding)) : promise;
  return result;
}
function getRequestWebStream(event) {
  if (!PayloadMethods$1.includes(event.method)) {
    return;
  }
  const bodyStream = event.web?.request?.body || event._requestBody;
  if (bodyStream) {
    return bodyStream;
  }
  const _hasRawBody = RawBodySymbol in event.node.req || "rawBody" in event.node.req || "body" in event.node.req || "__unenv__" in event.node.req;
  if (_hasRawBody) {
    return new ReadableStream({
      async start(controller) {
        const _rawBody = await readRawBody(event, false);
        if (_rawBody) {
          controller.enqueue(_rawBody);
        }
        controller.close();
      }
    });
  }
  return new ReadableStream({
    start: (controller) => {
      event.node.req.on("data", (chunk) => {
        controller.enqueue(chunk);
      });
      event.node.req.on("end", () => {
        controller.close();
      });
      event.node.req.on("error", (err) => {
        controller.error(err);
      });
    }
  });
}

function handleCacheHeaders(event, opts) {
  const cacheControls = ["public", ...opts.cacheControls || []];
  let cacheMatched = false;
  if (opts.maxAge !== void 0) {
    cacheControls.push(`max-age=${+opts.maxAge}`, `s-maxage=${+opts.maxAge}`);
  }
  if (opts.modifiedTime) {
    const modifiedTime = new Date(opts.modifiedTime);
    const ifModifiedSince = event.node.req.headers["if-modified-since"];
    event.node.res.setHeader("last-modified", modifiedTime.toUTCString());
    if (ifModifiedSince && new Date(ifModifiedSince) >= modifiedTime) {
      cacheMatched = true;
    }
  }
  if (opts.etag) {
    event.node.res.setHeader("etag", opts.etag);
    const ifNonMatch = event.node.req.headers["if-none-match"];
    if (ifNonMatch === opts.etag) {
      cacheMatched = true;
    }
  }
  event.node.res.setHeader("cache-control", cacheControls.join(", "));
  if (cacheMatched) {
    event.node.res.statusCode = 304;
    if (!event.handled) {
      event.node.res.end();
    }
    return true;
  }
  return false;
}

const MIMES = {
  html: "text/html",
  json: "application/json"
};

const DISALLOWED_STATUS_CHARS = /[^\u0009\u0020-\u007E]/g;
function sanitizeStatusMessage(statusMessage = "") {
  return statusMessage.replace(DISALLOWED_STATUS_CHARS, "");
}
function sanitizeStatusCode(statusCode, defaultStatusCode = 200) {
  if (!statusCode) {
    return defaultStatusCode;
  }
  if (typeof statusCode === "string") {
    statusCode = Number.parseInt(statusCode, 10);
  }
  if (statusCode < 100 || statusCode > 999) {
    return defaultStatusCode;
  }
  return statusCode;
}

function getDistinctCookieKey(name, opts) {
  return [name, opts.domain || "", opts.path || "/"].join(";");
}

function parseCookies(event) {
  return parse(event.node.req.headers.cookie || "");
}
function getCookie(event, name) {
  return parseCookies(event)[name];
}
function setCookie(event, name, value, serializeOptions = {}) {
  if (!serializeOptions.path) {
    serializeOptions = { path: "/", ...serializeOptions };
  }
  const newCookie = serialize$2(name, value, serializeOptions);
  const currentCookies = splitCookiesString(
    event.node.res.getHeader("set-cookie")
  );
  if (currentCookies.length === 0) {
    event.node.res.setHeader("set-cookie", newCookie);
    return;
  }
  const newCookieKey = getDistinctCookieKey(name, serializeOptions);
  event.node.res.removeHeader("set-cookie");
  for (const cookie of currentCookies) {
    const parsed = parseSetCookie(cookie);
    const key = getDistinctCookieKey(parsed.name, parsed);
    if (key === newCookieKey) {
      continue;
    }
    event.node.res.appendHeader("set-cookie", cookie);
  }
  event.node.res.appendHeader("set-cookie", newCookie);
}
function deleteCookie(event, name, serializeOptions) {
  setCookie(event, name, "", {
    ...serializeOptions,
    maxAge: 0
  });
}
function splitCookiesString(cookiesString) {
  if (Array.isArray(cookiesString)) {
    return cookiesString.flatMap((c) => splitCookiesString(c));
  }
  if (typeof cookiesString !== "string") {
    return [];
  }
  const cookiesStrings = [];
  let pos = 0;
  let start;
  let ch;
  let lastComma;
  let nextStart;
  let cookiesSeparatorFound;
  const skipWhitespace = () => {
    while (pos < cookiesString.length && /\s/.test(cookiesString.charAt(pos))) {
      pos += 1;
    }
    return pos < cookiesString.length;
  };
  const notSpecialChar = () => {
    ch = cookiesString.charAt(pos);
    return ch !== "=" && ch !== ";" && ch !== ",";
  };
  while (pos < cookiesString.length) {
    start = pos;
    cookiesSeparatorFound = false;
    while (skipWhitespace()) {
      ch = cookiesString.charAt(pos);
      if (ch === ",") {
        lastComma = pos;
        pos += 1;
        skipWhitespace();
        nextStart = pos;
        while (pos < cookiesString.length && notSpecialChar()) {
          pos += 1;
        }
        if (pos < cookiesString.length && cookiesString.charAt(pos) === "=") {
          cookiesSeparatorFound = true;
          pos = nextStart;
          cookiesStrings.push(cookiesString.slice(start, lastComma));
          start = pos;
        } else {
          pos = lastComma + 1;
        }
      } else {
        pos += 1;
      }
    }
    if (!cookiesSeparatorFound || pos >= cookiesString.length) {
      cookiesStrings.push(cookiesString.slice(start));
    }
  }
  return cookiesStrings;
}

const defer = typeof setImmediate === "undefined" ? (fn) => fn() : setImmediate;
function send(event, data, type) {
  if (type) {
    defaultContentType(event, type);
  }
  return new Promise((resolve) => {
    defer(() => {
      if (!event.handled) {
        event.node.res.end(data);
      }
      resolve();
    });
  });
}
function sendNoContent(event, code) {
  if (event.handled) {
    return;
  }
  if (!code && event.node.res.statusCode !== 200) {
    code = event.node.res.statusCode;
  }
  const _code = sanitizeStatusCode(code, 204);
  if (_code === 204) {
    event.node.res.removeHeader("content-length");
  }
  event.node.res.writeHead(_code);
  event.node.res.end();
}
function setResponseStatus(event, code, text) {
  if (code) {
    event.node.res.statusCode = sanitizeStatusCode(
      code,
      event.node.res.statusCode
    );
  }
  if (text) {
    event.node.res.statusMessage = sanitizeStatusMessage(text);
  }
}
function getResponseStatus(event) {
  return event.node.res.statusCode;
}
function getResponseStatusText(event) {
  return event.node.res.statusMessage;
}
function defaultContentType(event, type) {
  if (type && event.node.res.statusCode !== 304 && !event.node.res.getHeader("content-type")) {
    event.node.res.setHeader("content-type", type);
  }
}
function sendRedirect(event, location, code = 302) {
  event.node.res.statusCode = sanitizeStatusCode(
    code,
    event.node.res.statusCode
  );
  event.node.res.setHeader("location", location);
  const encodedLoc = location.replace(/"/g, "%22");
  const html = `<!DOCTYPE html><html><head><meta http-equiv="refresh" content="0; url=${encodedLoc}"></head></html>`;
  return send(event, html, MIMES.html);
}
function getResponseHeader(event, name) {
  return event.node.res.getHeader(name);
}
function setResponseHeaders(event, headers) {
  for (const [name, value] of Object.entries(headers)) {
    event.node.res.setHeader(
      name,
      value
    );
  }
}
const setHeaders = setResponseHeaders;
function setResponseHeader(event, name, value) {
  event.node.res.setHeader(name, value);
}
const setHeader = setResponseHeader;
function appendResponseHeader(event, name, value) {
  let current = event.node.res.getHeader(name);
  if (!current) {
    event.node.res.setHeader(name, value);
    return;
  }
  if (!Array.isArray(current)) {
    current = [current.toString()];
  }
  event.node.res.setHeader(name, [...current, value]);
}
function removeResponseHeader(event, name) {
  return event.node.res.removeHeader(name);
}
function isStream(data) {
  if (!data || typeof data !== "object") {
    return false;
  }
  if (typeof data.pipe === "function") {
    if (typeof data._read === "function") {
      return true;
    }
    if (typeof data.abort === "function") {
      return true;
    }
  }
  if (typeof data.pipeTo === "function") {
    return true;
  }
  return false;
}
function isWebResponse(data) {
  return typeof Response !== "undefined" && data instanceof Response;
}
function sendStream(event, stream) {
  if (!stream || typeof stream !== "object") {
    throw new Error("[h3] Invalid stream provided.");
  }
  event.node.res._data = stream;
  if (!event.node.res.socket) {
    event._handled = true;
    return Promise.resolve();
  }
  if (hasProp(stream, "pipeTo") && typeof stream.pipeTo === "function") {
    return stream.pipeTo(
      new WritableStream({
        write(chunk) {
          event.node.res.write(chunk);
        }
      })
    ).then(() => {
      event.node.res.end();
    });
  }
  if (hasProp(stream, "pipe") && typeof stream.pipe === "function") {
    return new Promise((resolve, reject) => {
      stream.pipe(event.node.res);
      if (stream.on) {
        stream.on("end", () => {
          event.node.res.end();
          resolve();
        });
        stream.on("error", (error) => {
          reject(error);
        });
      }
      event.node.res.on("close", () => {
        if (stream.abort) {
          stream.abort();
        }
      });
    });
  }
  throw new Error("[h3] Invalid or incompatible stream provided.");
}
function sendWebResponse(event, response) {
  for (const [key, value] of response.headers) {
    if (key === "set-cookie") {
      event.node.res.appendHeader(key, splitCookiesString(value));
    } else {
      event.node.res.setHeader(key, value);
    }
  }
  if (response.status) {
    event.node.res.statusCode = sanitizeStatusCode(
      response.status,
      event.node.res.statusCode
    );
  }
  if (response.statusText) {
    event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  }
  if (response.redirected) {
    event.node.res.setHeader("location", response.url);
  }
  if (!response.body) {
    event.node.res.end();
    return;
  }
  return sendStream(event, response.body);
}

const PayloadMethods = /* @__PURE__ */ new Set(["PATCH", "POST", "PUT", "DELETE"]);
const ignoredHeaders = /* @__PURE__ */ new Set([
  "transfer-encoding",
  "accept-encoding",
  "connection",
  "keep-alive",
  "upgrade",
  "expect",
  "host",
  "accept"
]);
async function proxyRequest(event, target, opts = {}) {
  let body;
  let duplex;
  if (PayloadMethods.has(event.method)) {
    if (opts.streamRequest) {
      body = getRequestWebStream(event);
      duplex = "half";
    } else {
      body = await readRawBody(event, false).catch(() => void 0);
    }
  }
  const method = opts.fetchOptions?.method || event.method;
  const fetchHeaders = mergeHeaders$1(
    getProxyRequestHeaders(event, { host: target.startsWith("/") }),
    opts.fetchOptions?.headers,
    opts.headers
  );
  return sendProxy(event, target, {
    ...opts,
    fetchOptions: {
      method,
      body,
      duplex,
      ...opts.fetchOptions,
      headers: fetchHeaders
    }
  });
}
async function sendProxy(event, target, opts = {}) {
  let response;
  try {
    response = await _getFetch(opts.fetch)(target, {
      headers: opts.headers,
      ignoreResponseError: true,
      // make $ofetch.raw transparent
      ...opts.fetchOptions
    });
  } catch (error) {
    throw createError$1({
      status: 502,
      statusMessage: "Bad Gateway",
      cause: error
    });
  }
  event.node.res.statusCode = sanitizeStatusCode(
    response.status,
    event.node.res.statusCode
  );
  event.node.res.statusMessage = sanitizeStatusMessage(response.statusText);
  const cookies = [];
  for (const [key, value] of response.headers.entries()) {
    if (key === "content-encoding") {
      continue;
    }
    if (key === "content-length") {
      continue;
    }
    if (key === "set-cookie") {
      cookies.push(...splitCookiesString(value));
      continue;
    }
    event.node.res.setHeader(key, value);
  }
  if (cookies.length > 0) {
    event.node.res.setHeader(
      "set-cookie",
      cookies.map((cookie) => {
        if (opts.cookieDomainRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookieDomainRewrite,
            "domain"
          );
        }
        if (opts.cookiePathRewrite) {
          cookie = rewriteCookieProperty(
            cookie,
            opts.cookiePathRewrite,
            "path"
          );
        }
        return cookie;
      })
    );
  }
  if (opts.onResponse) {
    await opts.onResponse(event, response);
  }
  if (response._data !== void 0) {
    return response._data;
  }
  if (event.handled) {
    return;
  }
  if (opts.sendStream === false) {
    const data = new Uint8Array(await response.arrayBuffer());
    return event.node.res.end(data);
  }
  if (response.body) {
    for await (const chunk of response.body) {
      event.node.res.write(chunk);
    }
  }
  return event.node.res.end();
}
function getProxyRequestHeaders(event, opts) {
  const headers = /* @__PURE__ */ Object.create(null);
  const reqHeaders = getRequestHeaders(event);
  for (const name in reqHeaders) {
    if (!ignoredHeaders.has(name) || name === "host" && opts?.host) {
      headers[name] = reqHeaders[name];
    }
  }
  return headers;
}
function fetchWithEvent(event, req, init, options) {
  return _getFetch(options?.fetch)(req, {
    ...init,
    context: init?.context || event.context,
    headers: {
      ...getProxyRequestHeaders(event, {
        host: typeof req === "string" && req.startsWith("/")
      }),
      ...init?.headers
    }
  });
}
function _getFetch(_fetch) {
  if (_fetch) {
    return _fetch;
  }
  if (globalThis.fetch) {
    return globalThis.fetch;
  }
  throw new Error(
    "fetch is not available. Try importing `node-fetch-native/polyfill` for Node.js."
  );
}
function rewriteCookieProperty(header, map, property) {
  const _map = typeof map === "string" ? { "*": map } : map;
  return header.replace(
    new RegExp(`(;\\s*${property}=)([^;]+)`, "gi"),
    (match, prefix, previousValue) => {
      let newValue;
      if (previousValue in _map) {
        newValue = _map[previousValue];
      } else if ("*" in _map) {
        newValue = _map["*"];
      } else {
        return match;
      }
      return newValue ? prefix + newValue : "";
    }
  );
}
function mergeHeaders$1(defaults, ...inputs) {
  const _inputs = inputs.filter(Boolean);
  if (_inputs.length === 0) {
    return defaults;
  }
  const merged = new Headers(defaults);
  for (const input of _inputs) {
    const entries = Array.isArray(input) ? input : typeof input.entries === "function" ? input.entries() : Object.entries(input);
    for (const [key, value] of entries) {
      if (value !== void 0) {
        merged.set(key, value);
      }
    }
  }
  return merged;
}

class H3Event {
  "__is_event__" = true;
  // Context
  node;
  // Node
  web;
  // Web
  context = {};
  // Shared
  // Request
  _method;
  _path;
  _headers;
  _requestBody;
  // Response
  _handled = false;
  // Hooks
  _onBeforeResponseCalled;
  _onAfterResponseCalled;
  constructor(req, res) {
    this.node = { req, res };
  }
  // --- Request ---
  get method() {
    if (!this._method) {
      this._method = (this.node.req.method || "GET").toUpperCase();
    }
    return this._method;
  }
  get path() {
    return this._path || this.node.req.url || "/";
  }
  get headers() {
    if (!this._headers) {
      this._headers = _normalizeNodeHeaders(this.node.req.headers);
    }
    return this._headers;
  }
  // --- Respoonse ---
  get handled() {
    return this._handled || this.node.res.writableEnded || this.node.res.headersSent;
  }
  respondWith(response) {
    return Promise.resolve(response).then(
      (_response) => sendWebResponse(this, _response)
    );
  }
  // --- Utils ---
  toString() {
    return `[${this.method}] ${this.path}`;
  }
  toJSON() {
    return this.toString();
  }
  // --- Deprecated ---
  /** @deprecated Please use `event.node.req` instead. */
  get req() {
    return this.node.req;
  }
  /** @deprecated Please use `event.node.res` instead. */
  get res() {
    return this.node.res;
  }
}
function isEvent(input) {
  return hasProp(input, "__is_event__");
}
function createEvent(req, res) {
  return new H3Event(req, res);
}
function _normalizeNodeHeaders(nodeHeaders) {
  const headers = new Headers();
  for (const [name, value] of Object.entries(nodeHeaders)) {
    if (Array.isArray(value)) {
      for (const item of value) {
        headers.append(name, item);
      }
    } else if (value) {
      headers.set(name, value);
    }
  }
  return headers;
}

function defineEventHandler(handler) {
  if (typeof handler === "function") {
    handler.__is_handler__ = true;
    return handler;
  }
  const _hooks = {
    onRequest: _normalizeArray(handler.onRequest),
    onBeforeResponse: _normalizeArray(handler.onBeforeResponse)
  };
  const _handler = (event) => {
    return _callHandler(event, handler.handler, _hooks);
  };
  _handler.__is_handler__ = true;
  _handler.__resolve__ = handler.handler.__resolve__;
  _handler.__websocket__ = handler.websocket;
  return _handler;
}
function _normalizeArray(input) {
  return input ? Array.isArray(input) ? input : [input] : void 0;
}
async function _callHandler(event, handler, hooks) {
  if (hooks.onRequest) {
    for (const hook of hooks.onRequest) {
      await hook(event);
      if (event.handled) {
        return;
      }
    }
  }
  const body = await handler(event);
  const response = { body };
  if (hooks.onBeforeResponse) {
    for (const hook of hooks.onBeforeResponse) {
      await hook(event, response);
    }
  }
  return response.body;
}
const eventHandler = defineEventHandler;
function isEventHandler(input) {
  return hasProp(input, "__is_handler__");
}
function toEventHandler(input, _, _route) {
  return input;
}
function defineLazyEventHandler(factory) {
  let _promise;
  let _resolved;
  const resolveHandler = () => {
    if (_resolved) {
      return Promise.resolve(_resolved);
    }
    if (!_promise) {
      _promise = Promise.resolve(factory()).then((r) => {
        const handler2 = r.default || r;
        if (typeof handler2 !== "function") {
          throw new TypeError(
            "Invalid lazy handler result. It should be a function:",
            handler2
          );
        }
        _resolved = { handler: toEventHandler(r.default || r) };
        return _resolved;
      });
    }
    return _promise;
  };
  const handler = eventHandler((event) => {
    if (_resolved) {
      return _resolved.handler(event);
    }
    return resolveHandler().then((r) => r.handler(event));
  });
  handler.__resolve__ = resolveHandler;
  return handler;
}
const lazyEventHandler = defineLazyEventHandler;

function createApp(options = {}) {
  const stack = [];
  const handler = createAppEventHandler(stack, options);
  const resolve = createResolver(stack);
  handler.__resolve__ = resolve;
  const getWebsocket = cachedFn(() => websocketOptions(resolve, options));
  const app = {
    // @ts-expect-error
    use: (arg1, arg2, arg3) => use(app, arg1, arg2, arg3),
    resolve,
    handler,
    stack,
    options,
    get websocket() {
      return getWebsocket();
    }
  };
  return app;
}
function use(app, arg1, arg2, arg3) {
  if (Array.isArray(arg1)) {
    for (const i of arg1) {
      use(app, i, arg2, arg3);
    }
  } else if (Array.isArray(arg2)) {
    for (const i of arg2) {
      use(app, arg1, i, arg3);
    }
  } else if (typeof arg1 === "string") {
    app.stack.push(
      normalizeLayer({ ...arg3, route: arg1, handler: arg2 })
    );
  } else if (typeof arg1 === "function") {
    app.stack.push(normalizeLayer({ ...arg2, handler: arg1 }));
  } else {
    app.stack.push(normalizeLayer({ ...arg1 }));
  }
  return app;
}
function createAppEventHandler(stack, options) {
  const spacing = options.debug ? 2 : void 0;
  return eventHandler(async (event) => {
    event.node.req.originalUrl = event.node.req.originalUrl || event.node.req.url || "/";
    const _rawReqUrl = event.node.req.url || "/";
    const _reqPath = _decodePath(event._path || _rawReqUrl);
    event._path = _reqPath;
    const _needsRawUrl = _reqPath !== _rawReqUrl;
    let _layerPath;
    if (options.onRequest) {
      await options.onRequest(event);
    }
    for (const layer of stack) {
      if (layer.route.length > 1) {
        if (!_reqPath.startsWith(layer.route)) {
          continue;
        }
        _layerPath = _reqPath.slice(layer.route.length) || "/";
      } else {
        _layerPath = _reqPath;
      }
      if (layer.match && !layer.match(_layerPath, event)) {
        continue;
      }
      event._path = _layerPath;
      event.node.req.url = _needsRawUrl ? layer.route.length > 1 ? _rawReqUrl.slice(layer.route.length) || "/" : _rawReqUrl : _layerPath;
      const val = await layer.handler(event);
      const _body = val === void 0 ? void 0 : await val;
      if (_body !== void 0) {
        const _response = { body: _body };
        if (options.onBeforeResponse) {
          event._onBeforeResponseCalled = true;
          await options.onBeforeResponse(event, _response);
        }
        await handleHandlerResponse(event, _response.body, spacing);
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, _response);
        }
        return;
      }
      if (event.handled) {
        if (options.onAfterResponse) {
          event._onAfterResponseCalled = true;
          await options.onAfterResponse(event, void 0);
        }
        return;
      }
    }
    if (!event.handled) {
      throw createError$1({
        statusCode: 404,
        statusMessage: `Cannot find any path matching ${event.path || "/"}.`
      });
    }
    if (options.onAfterResponse) {
      event._onAfterResponseCalled = true;
      await options.onAfterResponse(event, void 0);
    }
  });
}
function createResolver(stack) {
  return async (path) => {
    let _layerPath;
    for (const layer of stack) {
      if (layer.route === "/" && !layer.handler.__resolve__) {
        continue;
      }
      if (!path.startsWith(layer.route)) {
        continue;
      }
      _layerPath = path.slice(layer.route.length) || "/";
      if (layer.match && !layer.match(_layerPath, void 0)) {
        continue;
      }
      let res = { route: layer.route, handler: layer.handler };
      if (res.handler.__resolve__) {
        const _res = await res.handler.__resolve__(_layerPath);
        if (!_res) {
          continue;
        }
        res = {
          ...res,
          ..._res,
          route: joinURL(res.route || "/", _res.route || "/")
        };
      }
      return res;
    }
  };
}
function normalizeLayer(input) {
  let handler = input.handler;
  if (handler.handler) {
    handler = handler.handler;
  }
  if (input.lazy) {
    handler = lazyEventHandler(handler);
  } else if (!isEventHandler(handler)) {
    handler = toEventHandler(handler, void 0, input.route);
  }
  return {
    route: withoutTrailingSlash(input.route),
    match: input.match,
    handler
  };
}
function handleHandlerResponse(event, val, jsonSpace) {
  if (val === null) {
    return sendNoContent(event);
  }
  if (val) {
    if (isWebResponse(val)) {
      return sendWebResponse(event, val);
    }
    if (isStream(val)) {
      return sendStream(event, val);
    }
    if (val.buffer) {
      return send(event, val);
    }
    if (val.arrayBuffer && typeof val.arrayBuffer === "function") {
      return val.arrayBuffer().then((arrayBuffer) => {
        return send(event, Buffer.from(arrayBuffer), val.type);
      });
    }
    if (val instanceof Error) {
      throw createError$1(val);
    }
    if (typeof val.end === "function") {
      return true;
    }
  }
  const valType = typeof val;
  if (valType === "string") {
    return send(event, val, MIMES.html);
  }
  if (valType === "object" || valType === "boolean" || valType === "number") {
    return send(event, JSON.stringify(val, void 0, jsonSpace), MIMES.json);
  }
  if (valType === "bigint") {
    return send(event, val.toString(), MIMES.json);
  }
  throw createError$1({
    statusCode: 500,
    statusMessage: `[h3] Cannot send ${valType} as response.`
  });
}
function cachedFn(fn) {
  let cache;
  return () => {
    if (!cache) {
      cache = fn();
    }
    return cache;
  };
}
function _decodePath(url) {
  const qIndex = url.indexOf("?");
  const path = qIndex === -1 ? url : url.slice(0, qIndex);
  const query = qIndex === -1 ? "" : url.slice(qIndex);
  const decodedPath = path.includes("%25") ? decodePath(path.replace(/%25/g, "%2525")) : decodePath(path);
  return decodedPath + query;
}
function websocketOptions(evResolver, appOptions) {
  return {
    ...appOptions.websocket,
    async resolve(info) {
      const url = info.request?.url || info.url || "/";
      const { pathname } = typeof url === "string" ? parseURL(url) : url;
      const resolved = await evResolver(pathname);
      return resolved?.handler?.__websocket__ || {};
    }
  };
}

const RouterMethods = [
  "connect",
  "delete",
  "get",
  "head",
  "options",
  "post",
  "put",
  "trace",
  "patch"
];
function createRouter(opts = {}) {
  const _router = createRouter$1({});
  const routes = {};
  let _matcher;
  const router = {};
  const addRoute = (path, handler, method) => {
    let route = routes[path];
    if (!route) {
      routes[path] = route = { path, handlers: {} };
      _router.insert(path, route);
    }
    if (Array.isArray(method)) {
      for (const m of method) {
        addRoute(path, handler, m);
      }
    } else {
      route.handlers[method] = toEventHandler(handler);
    }
    return router;
  };
  router.use = router.add = (path, handler, method) => addRoute(path, handler, method || "all");
  for (const method of RouterMethods) {
    router[method] = (path, handle) => router.add(path, handle, method);
  }
  const matchHandler = (path = "/", method = "get") => {
    const qIndex = path.indexOf("?");
    if (qIndex !== -1) {
      path = path.slice(0, Math.max(0, qIndex));
    }
    const matched = _router.lookup(path);
    if (!matched || !matched.handlers) {
      return {
        error: createError$1({
          statusCode: 404,
          name: "Not Found",
          statusMessage: `Cannot find any route matching ${path || "/"}.`
        })
      };
    }
    let handler = matched.handlers[method] || matched.handlers.all;
    if (!handler) {
      if (!_matcher) {
        _matcher = toRouteMatcher(_router);
      }
      const _matches = _matcher.matchAll(path).reverse();
      for (const _match of _matches) {
        if (_match.handlers[method]) {
          handler = _match.handlers[method];
          matched.handlers[method] = matched.handlers[method] || handler;
          break;
        }
        if (_match.handlers.all) {
          handler = _match.handlers.all;
          matched.handlers.all = matched.handlers.all || handler;
          break;
        }
      }
    }
    if (!handler) {
      return {
        error: createError$1({
          statusCode: 405,
          name: "Method Not Allowed",
          statusMessage: `Method ${method} is not allowed on this route.`
        })
      };
    }
    return { matched, handler };
  };
  const isPreemptive = opts.preemptive || opts.preemtive;
  router.handler = eventHandler((event) => {
    const match = matchHandler(
      event.path,
      event.method.toLowerCase()
    );
    if ("error" in match) {
      if (isPreemptive) {
        throw match.error;
      } else {
        return;
      }
    }
    event.context.matchedRoute = match.matched;
    const params = match.matched.params || {};
    event.context.params = params;
    return Promise.resolve(match.handler(event)).then((res) => {
      if (res === void 0 && isPreemptive) {
        return null;
      }
      return res;
    });
  });
  router.handler.__resolve__ = async (path) => {
    path = withLeadingSlash(path);
    const match = matchHandler(path);
    if ("error" in match) {
      return;
    }
    let res = {
      route: match.matched.path,
      handler: match.handler
    };
    if (match.handler.__resolve__) {
      const _res = await match.handler.__resolve__(path);
      if (!_res) {
        return;
      }
      res = { ...res, ..._res };
    }
    return res;
  };
  return router;
}
function toNodeListener(app) {
  const toNodeHandle = async function(req, res) {
    const event = createEvent(req, res);
    try {
      await app.handler(event);
    } catch (_error) {
      const error = createError$1(_error);
      if (!isError(_error)) {
        error.unhandled = true;
      }
      setResponseStatus(event, error.statusCode, error.statusMessage);
      if (app.options.onError) {
        await app.options.onError(error, event);
      }
      if (event.handled) {
        return;
      }
      if (error.unhandled || error.fatal) {
        console.error("[h3]", error.fatal ? "[fatal]" : "[unhandled]", error);
      }
      if (app.options.onBeforeResponse && !event._onBeforeResponseCalled) {
        await app.options.onBeforeResponse(event, { body: error });
      }
      await sendError(event, error, !!app.options.debug);
      if (app.options.onAfterResponse && !event._onAfterResponseCalled) {
        await app.options.onAfterResponse(event, { body: error });
      }
    }
  };
  return toNodeHandle;
}

function flatHooks(configHooks, hooks = {}, parentName) {
  for (const key in configHooks) {
    const subHook = configHooks[key];
    const name = parentName ? `${parentName}:${key}` : key;
    if (typeof subHook === "object" && subHook !== null) {
      flatHooks(subHook, hooks, name);
    } else if (typeof subHook === "function") {
      hooks[name] = subHook;
    }
  }
  return hooks;
}
const defaultTask = { run: (function_) => function_() };
const _createTask = () => defaultTask;
const createTask = typeof console.createTask !== "undefined" ? console.createTask : _createTask;
function serialTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return hooks.reduce(
    (promise, hookFunction) => promise.then(() => task.run(() => hookFunction(...args))),
    Promise.resolve()
  );
}
function parallelTaskCaller(hooks, args) {
  const name = args.shift();
  const task = createTask(name);
  return Promise.all(hooks.map((hook) => task.run(() => hook(...args))));
}
function callEachWith(callbacks, arg0) {
  for (const callback of [...callbacks]) {
    callback(arg0);
  }
}

class Hookable {
  constructor() {
    this._hooks = {};
    this._before = void 0;
    this._after = void 0;
    this._deprecatedMessages = void 0;
    this._deprecatedHooks = {};
    this.hook = this.hook.bind(this);
    this.callHook = this.callHook.bind(this);
    this.callHookWith = this.callHookWith.bind(this);
  }
  hook(name, function_, options = {}) {
    if (!name || typeof function_ !== "function") {
      return () => {
      };
    }
    const originalName = name;
    let dep;
    while (this._deprecatedHooks[name]) {
      dep = this._deprecatedHooks[name];
      name = dep.to;
    }
    if (dep && !options.allowDeprecated) {
      let message = dep.message;
      if (!message) {
        message = `${originalName} hook has been deprecated` + (dep.to ? `, please use ${dep.to}` : "");
      }
      if (!this._deprecatedMessages) {
        this._deprecatedMessages = /* @__PURE__ */ new Set();
      }
      if (!this._deprecatedMessages.has(message)) {
        console.warn(message);
        this._deprecatedMessages.add(message);
      }
    }
    if (!function_.name) {
      try {
        Object.defineProperty(function_, "name", {
          get: () => "_" + name.replace(/\W+/g, "_") + "_hook_cb",
          configurable: true
        });
      } catch {
      }
    }
    this._hooks[name] = this._hooks[name] || [];
    this._hooks[name].push(function_);
    return () => {
      if (function_) {
        this.removeHook(name, function_);
        function_ = void 0;
      }
    };
  }
  hookOnce(name, function_) {
    let _unreg;
    let _function = (...arguments_) => {
      if (typeof _unreg === "function") {
        _unreg();
      }
      _unreg = void 0;
      _function = void 0;
      return function_(...arguments_);
    };
    _unreg = this.hook(name, _function);
    return _unreg;
  }
  removeHook(name, function_) {
    if (this._hooks[name]) {
      const index = this._hooks[name].indexOf(function_);
      if (index !== -1) {
        this._hooks[name].splice(index, 1);
      }
      if (this._hooks[name].length === 0) {
        delete this._hooks[name];
      }
    }
  }
  deprecateHook(name, deprecated) {
    this._deprecatedHooks[name] = typeof deprecated === "string" ? { to: deprecated } : deprecated;
    const _hooks = this._hooks[name] || [];
    delete this._hooks[name];
    for (const hook of _hooks) {
      this.hook(name, hook);
    }
  }
  deprecateHooks(deprecatedHooks) {
    Object.assign(this._deprecatedHooks, deprecatedHooks);
    for (const name in deprecatedHooks) {
      this.deprecateHook(name, deprecatedHooks[name]);
    }
  }
  addHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    const removeFns = Object.keys(hooks).map(
      (key) => this.hook(key, hooks[key])
    );
    return () => {
      for (const unreg of removeFns.splice(0, removeFns.length)) {
        unreg();
      }
    };
  }
  removeHooks(configHooks) {
    const hooks = flatHooks(configHooks);
    for (const key in hooks) {
      this.removeHook(key, hooks[key]);
    }
  }
  removeAllHooks() {
    for (const key in this._hooks) {
      delete this._hooks[key];
    }
  }
  callHook(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(serialTaskCaller, name, ...arguments_);
  }
  callHookParallel(name, ...arguments_) {
    arguments_.unshift(name);
    return this.callHookWith(parallelTaskCaller, name, ...arguments_);
  }
  callHookWith(caller, name, ...arguments_) {
    const event = this._before || this._after ? { name, args: arguments_, context: {} } : void 0;
    if (this._before) {
      callEachWith(this._before, event);
    }
    const result = caller(
      name in this._hooks ? [...this._hooks[name]] : [],
      arguments_
    );
    if (result instanceof Promise) {
      return result.finally(() => {
        if (this._after && event) {
          callEachWith(this._after, event);
        }
      });
    }
    if (this._after && event) {
      callEachWith(this._after, event);
    }
    return result;
  }
  beforeEach(function_) {
    this._before = this._before || [];
    this._before.push(function_);
    return () => {
      if (this._before !== void 0) {
        const index = this._before.indexOf(function_);
        if (index !== -1) {
          this._before.splice(index, 1);
        }
      }
    };
  }
  afterEach(function_) {
    this._after = this._after || [];
    this._after.push(function_);
    return () => {
      if (this._after !== void 0) {
        const index = this._after.indexOf(function_);
        if (index !== -1) {
          this._after.splice(index, 1);
        }
      }
    };
  }
}
function createHooks() {
  return new Hookable();
}

const s$1=globalThis.Headers,i=globalThis.AbortController,l=globalThis.fetch||(()=>{throw new Error("[node-fetch-native] Failed to fetch: `globalThis.fetch` is not available!")});

class FetchError extends Error {
  constructor(message, opts) {
    super(message, opts);
    this.name = "FetchError";
    if (opts?.cause && !this.cause) {
      this.cause = opts.cause;
    }
  }
}
function createFetchError(ctx) {
  const errorMessage = ctx.error?.message || ctx.error?.toString() || "";
  const method = ctx.request?.method || ctx.options?.method || "GET";
  const url = ctx.request?.url || String(ctx.request) || "/";
  const requestStr = `[${method}] ${JSON.stringify(url)}`;
  const statusStr = ctx.response ? `${ctx.response.status} ${ctx.response.statusText}` : "<no response>";
  const message = `${requestStr}: ${statusStr}${errorMessage ? ` ${errorMessage}` : ""}`;
  const fetchError = new FetchError(
    message,
    ctx.error ? { cause: ctx.error } : void 0
  );
  for (const key of ["request", "options", "response"]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx[key];
      }
    });
  }
  for (const [key, refKey] of [
    ["data", "_data"],
    ["status", "status"],
    ["statusCode", "status"],
    ["statusText", "statusText"],
    ["statusMessage", "statusText"]
  ]) {
    Object.defineProperty(fetchError, key, {
      get() {
        return ctx.response && ctx.response[refKey];
      }
    });
  }
  return fetchError;
}

const payloadMethods = new Set(
  Object.freeze(["PATCH", "POST", "PUT", "DELETE"])
);
function isPayloadMethod(method = "GET") {
  return payloadMethods.has(method.toUpperCase());
}
function isJSONSerializable(value) {
  if (value === void 0) {
    return false;
  }
  const t = typeof value;
  if (t === "string" || t === "number" || t === "boolean" || t === null) {
    return true;
  }
  if (t !== "object") {
    return false;
  }
  if (Array.isArray(value)) {
    return true;
  }
  if (value.buffer) {
    return false;
  }
  if (value instanceof FormData || value instanceof URLSearchParams) {
    return false;
  }
  return value.constructor && value.constructor.name === "Object" || typeof value.toJSON === "function";
}
const textTypes = /* @__PURE__ */ new Set([
  "image/svg",
  "application/xml",
  "application/xhtml",
  "application/html"
]);
const JSON_RE = /^application\/(?:[\w!#$%&*.^`~-]*\+)?json(;.+)?$/i;
function detectResponseType(_contentType = "") {
  if (!_contentType) {
    return "json";
  }
  const contentType = _contentType.split(";").shift() || "";
  if (JSON_RE.test(contentType)) {
    return "json";
  }
  if (contentType === "text/event-stream") {
    return "stream";
  }
  if (textTypes.has(contentType) || contentType.startsWith("text/")) {
    return "text";
  }
  return "blob";
}
function resolveFetchOptions(request, input, defaults, Headers) {
  const headers = mergeHeaders(
    input?.headers ?? request?.headers,
    defaults?.headers,
    Headers
  );
  let query;
  if (defaults?.query || defaults?.params || input?.params || input?.query) {
    query = {
      ...defaults?.params,
      ...defaults?.query,
      ...input?.params,
      ...input?.query
    };
  }
  return {
    ...defaults,
    ...input,
    query,
    params: query,
    headers
  };
}
function mergeHeaders(input, defaults, Headers) {
  if (!defaults) {
    return new Headers(input);
  }
  const headers = new Headers(defaults);
  if (input) {
    for (const [key, value] of Symbol.iterator in input || Array.isArray(input) ? input : new Headers(input)) {
      headers.set(key, value);
    }
  }
  return headers;
}
async function callHooks(context, hooks) {
  if (hooks) {
    if (Array.isArray(hooks)) {
      for (const hook of hooks) {
        await hook(context);
      }
    } else {
      await hooks(context);
    }
  }
}

const retryStatusCodes = /* @__PURE__ */ new Set([
  408,
  // Request Timeout
  409,
  // Conflict
  425,
  // Too Early (Experimental)
  429,
  // Too Many Requests
  500,
  // Internal Server Error
  502,
  // Bad Gateway
  503,
  // Service Unavailable
  504
  // Gateway Timeout
]);
const nullBodyResponses = /* @__PURE__ */ new Set([101, 204, 205, 304]);
function createFetch(globalOptions = {}) {
  const {
    fetch = globalThis.fetch,
    Headers = globalThis.Headers,
    AbortController = globalThis.AbortController
  } = globalOptions;
  async function onError(context) {
    const isAbort = context.error && context.error.name === "AbortError" && !context.options.timeout || false;
    if (context.options.retry !== false && !isAbort) {
      let retries;
      if (typeof context.options.retry === "number") {
        retries = context.options.retry;
      } else {
        retries = isPayloadMethod(context.options.method) ? 0 : 1;
      }
      const responseCode = context.response && context.response.status || 500;
      if (retries > 0 && (Array.isArray(context.options.retryStatusCodes) ? context.options.retryStatusCodes.includes(responseCode) : retryStatusCodes.has(responseCode))) {
        const retryDelay = typeof context.options.retryDelay === "function" ? context.options.retryDelay(context) : context.options.retryDelay || 0;
        if (retryDelay > 0) {
          await new Promise((resolve) => setTimeout(resolve, retryDelay));
        }
        return $fetchRaw(context.request, {
          ...context.options,
          retry: retries - 1
        });
      }
    }
    const error = createFetchError(context);
    if (Error.captureStackTrace) {
      Error.captureStackTrace(error, $fetchRaw);
    }
    throw error;
  }
  const $fetchRaw = async function $fetchRaw2(_request, _options = {}) {
    const context = {
      request: _request,
      options: resolveFetchOptions(
        _request,
        _options,
        globalOptions.defaults,
        Headers
      ),
      response: void 0,
      error: void 0
    };
    if (context.options.method) {
      context.options.method = context.options.method.toUpperCase();
    }
    if (context.options.onRequest) {
      await callHooks(context, context.options.onRequest);
      if (!(context.options.headers instanceof Headers)) {
        context.options.headers = new Headers(
          context.options.headers || {}
          /* compat */
        );
      }
    }
    if (typeof context.request === "string") {
      if (context.options.baseURL) {
        context.request = withBase(context.request, context.options.baseURL);
      }
      if (context.options.query) {
        context.request = withQuery(context.request, context.options.query);
        delete context.options.query;
      }
      if ("query" in context.options) {
        delete context.options.query;
      }
      if ("params" in context.options) {
        delete context.options.params;
      }
    }
    if (context.options.body && isPayloadMethod(context.options.method)) {
      if (isJSONSerializable(context.options.body)) {
        const contentType = context.options.headers.get("content-type");
        if (typeof context.options.body !== "string") {
          context.options.body = contentType === "application/x-www-form-urlencoded" ? new URLSearchParams(
            context.options.body
          ).toString() : JSON.stringify(context.options.body);
        }
        if (!contentType) {
          context.options.headers.set("content-type", "application/json");
        }
        if (!context.options.headers.has("accept")) {
          context.options.headers.set("accept", "application/json");
        }
      } else if (
        // ReadableStream Body
        "pipeTo" in context.options.body && typeof context.options.body.pipeTo === "function" || // Node.js Stream Body
        typeof context.options.body.pipe === "function"
      ) {
        if (!("duplex" in context.options)) {
          context.options.duplex = "half";
        }
      }
    }
    let abortTimeout;
    if (!context.options.signal && context.options.timeout) {
      const controller = new AbortController();
      abortTimeout = setTimeout(() => {
        const error = new Error(
          "[TimeoutError]: The operation was aborted due to timeout"
        );
        error.name = "TimeoutError";
        error.code = 23;
        controller.abort(error);
      }, context.options.timeout);
      context.options.signal = controller.signal;
    }
    try {
      context.response = await fetch(
        context.request,
        context.options
      );
    } catch (error) {
      context.error = error;
      if (context.options.onRequestError) {
        await callHooks(
          context,
          context.options.onRequestError
        );
      }
      return await onError(context);
    } finally {
      if (abortTimeout) {
        clearTimeout(abortTimeout);
      }
    }
    const hasBody = (context.response.body || // https://github.com/unjs/ofetch/issues/324
    // https://github.com/unjs/ofetch/issues/294
    // https://github.com/JakeChampion/fetch/issues/1454
    context.response._bodyInit) && !nullBodyResponses.has(context.response.status) && context.options.method !== "HEAD";
    if (hasBody) {
      const responseType = (context.options.parseResponse ? "json" : context.options.responseType) || detectResponseType(context.response.headers.get("content-type") || "");
      switch (responseType) {
        case "json": {
          const data = await context.response.text();
          const parseFunction = context.options.parseResponse || destr;
          context.response._data = parseFunction(data);
          break;
        }
        case "stream": {
          context.response._data = context.response.body || context.response._bodyInit;
          break;
        }
        default: {
          context.response._data = await context.response[responseType]();
        }
      }
    }
    if (context.options.onResponse) {
      await callHooks(
        context,
        context.options.onResponse
      );
    }
    if (!context.options.ignoreResponseError && context.response.status >= 400 && context.response.status < 600) {
      if (context.options.onResponseError) {
        await callHooks(
          context,
          context.options.onResponseError
        );
      }
      return await onError(context);
    }
    return context.response;
  };
  const $fetch = async function $fetch2(request, options) {
    const r = await $fetchRaw(request, options);
    return r._data;
  };
  $fetch.raw = $fetchRaw;
  $fetch.native = (...args) => fetch(...args);
  $fetch.create = (defaultOptions = {}, customGlobalOptions = {}) => createFetch({
    ...globalOptions,
    ...customGlobalOptions,
    defaults: {
      ...globalOptions.defaults,
      ...customGlobalOptions.defaults,
      ...defaultOptions
    }
  });
  return $fetch;
}

function createNodeFetch() {
  const useKeepAlive = JSON.parse(process.env.FETCH_KEEP_ALIVE || "false");
  if (!useKeepAlive) {
    return l;
  }
  const agentOptions = { keepAlive: true };
  const httpAgent = new http.Agent(agentOptions);
  const httpsAgent = new https.Agent(agentOptions);
  const nodeFetchOptions = {
    agent(parsedURL) {
      return parsedURL.protocol === "http:" ? httpAgent : httpsAgent;
    }
  };
  return function nodeFetchWithKeepAlive(input, init) {
    return l(input, { ...nodeFetchOptions, ...init });
  };
}
const fetch = globalThis.fetch ? (...args) => globalThis.fetch(...args) : createNodeFetch();
const Headers$1 = globalThis.Headers || s$1;
const AbortController = globalThis.AbortController || i;
const ofetch = createFetch({ fetch, Headers: Headers$1, AbortController });
const $fetch = ofetch;

function wrapToPromise(value) {
  if (!value || typeof value.then !== "function") {
    return Promise.resolve(value);
  }
  return value;
}
function asyncCall(function_, ...arguments_) {
  try {
    return wrapToPromise(function_(...arguments_));
  } catch (error) {
    return Promise.reject(error);
  }
}
function isPrimitive(value) {
  const type = typeof value;
  return value === null || type !== "object" && type !== "function";
}
function isPureObject(value) {
  const proto = Object.getPrototypeOf(value);
  return !proto || proto.isPrototypeOf(Object);
}
function stringify(value) {
  if (isPrimitive(value)) {
    return String(value);
  }
  if (isPureObject(value) || Array.isArray(value)) {
    return JSON.stringify(value);
  }
  if (typeof value.toJSON === "function") {
    return stringify(value.toJSON());
  }
  throw new Error("[unstorage] Cannot stringify value!");
}
const BASE64_PREFIX = "base64:";
function serializeRaw(value) {
  if (typeof value === "string") {
    return value;
  }
  return BASE64_PREFIX + base64Encode(value);
}
function deserializeRaw(value) {
  if (typeof value !== "string") {
    return value;
  }
  if (!value.startsWith(BASE64_PREFIX)) {
    return value;
  }
  return base64Decode(value.slice(BASE64_PREFIX.length));
}
function base64Decode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input, "base64");
  }
  return Uint8Array.from(
    globalThis.atob(input),
    (c) => c.codePointAt(0)
  );
}
function base64Encode(input) {
  if (globalThis.Buffer) {
    return Buffer.from(input).toString("base64");
  }
  return globalThis.btoa(String.fromCodePoint(...input));
}

const storageKeyProperties = [
  "has",
  "hasItem",
  "get",
  "getItem",
  "getItemRaw",
  "set",
  "setItem",
  "setItemRaw",
  "del",
  "remove",
  "removeItem",
  "getMeta",
  "setMeta",
  "removeMeta",
  "getKeys",
  "clear",
  "mount",
  "unmount"
];
function prefixStorage(storage, base) {
  base = normalizeBaseKey(base);
  if (!base) {
    return storage;
  }
  const nsStorage = { ...storage };
  for (const property of storageKeyProperties) {
    nsStorage[property] = (key = "", ...args) => (
      // @ts-ignore
      storage[property](base + key, ...args)
    );
  }
  nsStorage.getKeys = (key = "", ...arguments_) => storage.getKeys(base + key, ...arguments_).then((keys) => keys.map((key2) => key2.slice(base.length)));
  nsStorage.keys = nsStorage.getKeys;
  nsStorage.getItems = async (items, commonOptions) => {
    const prefixedItems = items.map(
      (item) => typeof item === "string" ? base + item : { ...item, key: base + item.key }
    );
    const results = await storage.getItems(prefixedItems, commonOptions);
    return results.map((entry) => ({
      key: entry.key.slice(base.length),
      value: entry.value
    }));
  };
  nsStorage.setItems = async (items, commonOptions) => {
    const prefixedItems = items.map((item) => ({
      key: base + item.key,
      value: item.value,
      options: item.options
    }));
    return storage.setItems(prefixedItems, commonOptions);
  };
  return nsStorage;
}
function normalizeKey$1(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
}
function joinKeys(...keys) {
  return normalizeKey$1(keys.join(":"));
}
function normalizeBaseKey(base) {
  base = normalizeKey$1(base);
  return base ? base + ":" : "";
}
function filterKeyByDepth(key, depth) {
  if (depth === void 0) {
    return true;
  }
  let substrCount = 0;
  let index = key.indexOf(":");
  while (index > -1) {
    substrCount++;
    index = key.indexOf(":", index + 1);
  }
  return substrCount <= depth;
}
function filterKeyByBase(key, base) {
  if (base) {
    return key.startsWith(base) && key[key.length - 1] !== "$";
  }
  return key[key.length - 1] !== "$";
}

function defineDriver$1(factory) {
  return factory;
}

const DRIVER_NAME$1 = "memory";
const memory = defineDriver$1(() => {
  const data = /* @__PURE__ */ new Map();
  return {
    name: DRIVER_NAME$1,
    getInstance: () => data,
    hasItem(key) {
      return data.has(key);
    },
    getItem(key) {
      return data.get(key) ?? null;
    },
    getItemRaw(key) {
      return data.get(key) ?? null;
    },
    setItem(key, value) {
      data.set(key, value);
    },
    setItemRaw(key, value) {
      data.set(key, value);
    },
    removeItem(key) {
      data.delete(key);
    },
    getKeys() {
      return [...data.keys()];
    },
    clear() {
      data.clear();
    },
    dispose() {
      data.clear();
    }
  };
});

function createStorage(options = {}) {
  const context = {
    mounts: { "": options.driver || memory() },
    mountpoints: [""],
    watching: false,
    watchListeners: [],
    unwatch: {}
  };
  const getMount = (key) => {
    for (const base of context.mountpoints) {
      if (key.startsWith(base)) {
        return {
          base,
          relativeKey: key.slice(base.length),
          driver: context.mounts[base]
        };
      }
    }
    return {
      base: "",
      relativeKey: key,
      driver: context.mounts[""]
    };
  };
  const getMounts = (base, includeParent) => {
    return context.mountpoints.filter(
      (mountpoint) => mountpoint.startsWith(base) || includeParent && base.startsWith(mountpoint)
    ).map((mountpoint) => ({
      relativeBase: base.length > mountpoint.length ? base.slice(mountpoint.length) : void 0,
      mountpoint,
      driver: context.mounts[mountpoint]
    }));
  };
  const onChange = (event, key) => {
    if (!context.watching) {
      return;
    }
    key = normalizeKey$1(key);
    for (const listener of context.watchListeners) {
      listener(event, key);
    }
  };
  const startWatch = async () => {
    if (context.watching) {
      return;
    }
    context.watching = true;
    for (const mountpoint in context.mounts) {
      context.unwatch[mountpoint] = await watch(
        context.mounts[mountpoint],
        onChange,
        mountpoint
      );
    }
  };
  const stopWatch = async () => {
    if (!context.watching) {
      return;
    }
    for (const mountpoint in context.unwatch) {
      await context.unwatch[mountpoint]();
    }
    context.unwatch = {};
    context.watching = false;
  };
  const runBatch = (items, commonOptions, cb) => {
    const batches = /* @__PURE__ */ new Map();
    const getBatch = (mount) => {
      let batch = batches.get(mount.base);
      if (!batch) {
        batch = {
          driver: mount.driver,
          base: mount.base,
          items: []
        };
        batches.set(mount.base, batch);
      }
      return batch;
    };
    for (const item of items) {
      const isStringItem = typeof item === "string";
      const key = normalizeKey$1(isStringItem ? item : item.key);
      const value = isStringItem ? void 0 : item.value;
      const options2 = isStringItem || !item.options ? commonOptions : { ...commonOptions, ...item.options };
      const mount = getMount(key);
      getBatch(mount).items.push({
        key,
        value,
        relativeKey: mount.relativeKey,
        options: options2
      });
    }
    return Promise.all([...batches.values()].map((batch) => cb(batch))).then(
      (r) => r.flat()
    );
  };
  const storage = {
    // Item
    hasItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.hasItem, relativeKey, opts);
    },
    getItem(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => destr(value)
      );
    },
    getItems(items, commonOptions = {}) {
      return runBatch(items, commonOptions, (batch) => {
        if (batch.driver.getItems) {
          return asyncCall(
            batch.driver.getItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              options: item.options
            })),
            commonOptions
          ).then(
            (r) => r.map((item) => ({
              key: joinKeys(batch.base, item.key),
              value: destr(item.value)
            }))
          );
        }
        return Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.getItem,
              item.relativeKey,
              item.options
            ).then((value) => ({
              key: item.key,
              value: destr(value)
            }));
          })
        );
      });
    },
    getItemRaw(key, opts = {}) {
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.getItemRaw) {
        return asyncCall(driver.getItemRaw, relativeKey, opts);
      }
      return asyncCall(driver.getItem, relativeKey, opts).then(
        (value) => deserializeRaw(value)
      );
    },
    async setItem(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.setItem) {
        return;
      }
      await asyncCall(driver.setItem, relativeKey, stringify(value), opts);
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async setItems(items, commonOptions) {
      await runBatch(items, commonOptions, async (batch) => {
        if (batch.driver.setItems) {
          return asyncCall(
            batch.driver.setItems,
            batch.items.map((item) => ({
              key: item.relativeKey,
              value: stringify(item.value),
              options: item.options
            })),
            commonOptions
          );
        }
        if (!batch.driver.setItem) {
          return;
        }
        await Promise.all(
          batch.items.map((item) => {
            return asyncCall(
              batch.driver.setItem,
              item.relativeKey,
              stringify(item.value),
              item.options
            );
          })
        );
      });
    },
    async setItemRaw(key, value, opts = {}) {
      if (value === void 0) {
        return storage.removeItem(key, opts);
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (driver.setItemRaw) {
        await asyncCall(driver.setItemRaw, relativeKey, value, opts);
      } else if (driver.setItem) {
        await asyncCall(driver.setItem, relativeKey, serializeRaw(value), opts);
      } else {
        return;
      }
      if (!driver.watch) {
        onChange("update", key);
      }
    },
    async removeItem(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { removeMeta: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      if (!driver.removeItem) {
        return;
      }
      await asyncCall(driver.removeItem, relativeKey, opts);
      if (opts.removeMeta || opts.removeMata) {
        await asyncCall(driver.removeItem, relativeKey + "$", opts);
      }
      if (!driver.watch) {
        onChange("remove", key);
      }
    },
    // Meta
    async getMeta(key, opts = {}) {
      if (typeof opts === "boolean") {
        opts = { nativeOnly: opts };
      }
      key = normalizeKey$1(key);
      const { relativeKey, driver } = getMount(key);
      const meta = /* @__PURE__ */ Object.create(null);
      if (driver.getMeta) {
        Object.assign(meta, await asyncCall(driver.getMeta, relativeKey, opts));
      }
      if (!opts.nativeOnly) {
        const value = await asyncCall(
          driver.getItem,
          relativeKey + "$",
          opts
        ).then((value_) => destr(value_));
        if (value && typeof value === "object") {
          if (typeof value.atime === "string") {
            value.atime = new Date(value.atime);
          }
          if (typeof value.mtime === "string") {
            value.mtime = new Date(value.mtime);
          }
          Object.assign(meta, value);
        }
      }
      return meta;
    },
    setMeta(key, value, opts = {}) {
      return this.setItem(key + "$", value, opts);
    },
    removeMeta(key, opts = {}) {
      return this.removeItem(key + "$", opts);
    },
    // Keys
    async getKeys(base, opts = {}) {
      base = normalizeBaseKey(base);
      const mounts = getMounts(base, true);
      let maskedMounts = [];
      const allKeys = [];
      let allMountsSupportMaxDepth = true;
      for (const mount of mounts) {
        if (!mount.driver.flags?.maxDepth) {
          allMountsSupportMaxDepth = false;
        }
        const rawKeys = await asyncCall(
          mount.driver.getKeys,
          mount.relativeBase,
          opts
        );
        for (const key of rawKeys) {
          const fullKey = mount.mountpoint + normalizeKey$1(key);
          if (!maskedMounts.some((p) => fullKey.startsWith(p))) {
            allKeys.push(fullKey);
          }
        }
        maskedMounts = [
          mount.mountpoint,
          ...maskedMounts.filter((p) => !p.startsWith(mount.mountpoint))
        ];
      }
      const shouldFilterByDepth = opts.maxDepth !== void 0 && !allMountsSupportMaxDepth;
      return allKeys.filter(
        (key) => (!shouldFilterByDepth || filterKeyByDepth(key, opts.maxDepth)) && filterKeyByBase(key, base)
      );
    },
    // Utils
    async clear(base, opts = {}) {
      base = normalizeBaseKey(base);
      await Promise.all(
        getMounts(base, false).map(async (m) => {
          if (m.driver.clear) {
            return asyncCall(m.driver.clear, m.relativeBase, opts);
          }
          if (m.driver.removeItem) {
            const keys = await m.driver.getKeys(m.relativeBase || "", opts);
            return Promise.all(
              keys.map((key) => m.driver.removeItem(key, opts))
            );
          }
        })
      );
    },
    async dispose() {
      await Promise.all(
        Object.values(context.mounts).map((driver) => dispose(driver))
      );
    },
    async watch(callback) {
      await startWatch();
      context.watchListeners.push(callback);
      return async () => {
        context.watchListeners = context.watchListeners.filter(
          (listener) => listener !== callback
        );
        if (context.watchListeners.length === 0) {
          await stopWatch();
        }
      };
    },
    async unwatch() {
      context.watchListeners = [];
      await stopWatch();
    },
    // Mount
    mount(base, driver) {
      base = normalizeBaseKey(base);
      if (base && context.mounts[base]) {
        throw new Error(`already mounted at ${base}`);
      }
      if (base) {
        context.mountpoints.push(base);
        context.mountpoints.sort((a, b) => b.length - a.length);
      }
      context.mounts[base] = driver;
      if (context.watching) {
        Promise.resolve(watch(driver, onChange, base)).then((unwatcher) => {
          context.unwatch[base] = unwatcher;
        }).catch(console.error);
      }
      return storage;
    },
    async unmount(base, _dispose = true) {
      base = normalizeBaseKey(base);
      if (!base || !context.mounts[base]) {
        return;
      }
      if (context.watching && base in context.unwatch) {
        context.unwatch[base]?.();
        delete context.unwatch[base];
      }
      if (_dispose) {
        await dispose(context.mounts[base]);
      }
      context.mountpoints = context.mountpoints.filter((key) => key !== base);
      delete context.mounts[base];
    },
    getMount(key = "") {
      key = normalizeKey$1(key) + ":";
      const m = getMount(key);
      return {
        driver: m.driver,
        base: m.base
      };
    },
    getMounts(base = "", opts = {}) {
      base = normalizeKey$1(base);
      const mounts = getMounts(base, opts.parents);
      return mounts.map((m) => ({
        driver: m.driver,
        base: m.mountpoint
      }));
    },
    // Aliases
    keys: (base, opts = {}) => storage.getKeys(base, opts),
    get: (key, opts = {}) => storage.getItem(key, opts),
    set: (key, value, opts = {}) => storage.setItem(key, value, opts),
    has: (key, opts = {}) => storage.hasItem(key, opts),
    del: (key, opts = {}) => storage.removeItem(key, opts),
    remove: (key, opts = {}) => storage.removeItem(key, opts)
  };
  return storage;
}
function watch(driver, onChange, base) {
  return driver.watch ? driver.watch((event, key) => onChange(event, base + key)) : () => {
  };
}
async function dispose(driver) {
  if (typeof driver.dispose === "function") {
    await asyncCall(driver.dispose);
  }
}

const _assets = {

};

const normalizeKey = function normalizeKey(key) {
  if (!key) {
    return "";
  }
  return key.split("?")[0]?.replace(/[/\\]/g, ":").replace(/:+/g, ":").replace(/^:|:$/g, "") || "";
};

const assets$1 = {
  getKeys() {
    return Promise.resolve(Object.keys(_assets))
  },
  hasItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(id in _assets)
  },
  getItem (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].import() : null)
  },
  getMeta (id) {
    id = normalizeKey(id);
    return Promise.resolve(_assets[id] ? _assets[id].meta : {})
  }
};

function defineDriver(factory) {
  return factory;
}
function createError(driver, message, opts) {
  const err = new Error(`[unstorage] [${driver}] ${message}`, opts);
  if (Error.captureStackTrace) {
    Error.captureStackTrace(err, createError);
  }
  return err;
}
function createRequiredError(driver, name) {
  if (Array.isArray(name)) {
    return createError(
      driver,
      `Missing some of the required options ${name.map((n) => "`" + n + "`").join(", ")}`
    );
  }
  return createError(driver, `Missing required option \`${name}\`.`);
}

function ignoreNotfound(err) {
  return err.code === "ENOENT" || err.code === "EISDIR" ? null : err;
}
function ignoreExists(err) {
  return err.code === "EEXIST" ? null : err;
}
async function writeFile(path, data, encoding) {
  await ensuredir(dirname$1(path));
  return promises.writeFile(path, data, encoding);
}
function readFile(path, encoding) {
  return promises.readFile(path, encoding).catch(ignoreNotfound);
}
function unlink(path) {
  return promises.unlink(path).catch(ignoreNotfound);
}
function readdir(dir) {
  return promises.readdir(dir, { withFileTypes: true }).catch(ignoreNotfound).then((r) => r || []);
}
async function ensuredir(dir) {
  if (existsSync(dir)) {
    return;
  }
  await ensuredir(dirname$1(dir)).catch(ignoreExists);
  await promises.mkdir(dir).catch(ignoreExists);
}
async function readdirRecursive(dir, ignore, maxDepth) {
  if (ignore && ignore(dir)) {
    return [];
  }
  const entries = await readdir(dir);
  const files = [];
  await Promise.all(
    entries.map(async (entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        if (maxDepth === void 0 || maxDepth > 0) {
          const dirFiles = await readdirRecursive(
            entryPath,
            ignore,
            maxDepth === void 0 ? void 0 : maxDepth - 1
          );
          files.push(...dirFiles.map((f) => entry.name + "/" + f));
        }
      } else {
        if (!(ignore && ignore(entry.name))) {
          files.push(entry.name);
        }
      }
    })
  );
  return files;
}
async function rmRecursive(dir) {
  const entries = await readdir(dir);
  await Promise.all(
    entries.map((entry) => {
      const entryPath = resolve$1(dir, entry.name);
      if (entry.isDirectory()) {
        return rmRecursive(entryPath).then(() => promises.rmdir(entryPath));
      } else {
        return promises.unlink(entryPath);
      }
    })
  );
}

const PATH_TRAVERSE_RE = /\.\.:|\.\.$/;
const DRIVER_NAME = "fs-lite";
const unstorage_47drivers_47fs_45lite = defineDriver((opts = {}) => {
  if (!opts.base) {
    throw createRequiredError(DRIVER_NAME, "base");
  }
  opts.base = resolve$1(opts.base);
  const r = (key) => {
    if (PATH_TRAVERSE_RE.test(key)) {
      throw createError(
        DRIVER_NAME,
        `Invalid key: ${JSON.stringify(key)}. It should not contain .. segments`
      );
    }
    const resolved = join(opts.base, key.replace(/:/g, "/"));
    return resolved;
  };
  return {
    name: DRIVER_NAME,
    options: opts,
    flags: {
      maxDepth: true
    },
    hasItem(key) {
      return existsSync(r(key));
    },
    getItem(key) {
      return readFile(r(key), "utf8");
    },
    getItemRaw(key) {
      return readFile(r(key));
    },
    async getMeta(key) {
      const { atime, mtime, size, birthtime, ctime } = await promises.stat(r(key)).catch(() => ({}));
      return { atime, mtime, size, birthtime, ctime };
    },
    setItem(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value, "utf8");
    },
    setItemRaw(key, value) {
      if (opts.readOnly) {
        return;
      }
      return writeFile(r(key), value);
    },
    removeItem(key) {
      if (opts.readOnly) {
        return;
      }
      return unlink(r(key));
    },
    getKeys(_base, topts) {
      return readdirRecursive(r("."), opts.ignore, topts?.maxDepth);
    },
    async clear() {
      if (opts.readOnly || opts.noClear) {
        return;
      }
      await rmRecursive(r("."));
    }
  };
});

const storage = createStorage({});

storage.mount('/assets', assets$1);

storage.mount('data', unstorage_47drivers_47fs_45lite({"driver":"fsLite","base":"./.data/kv"}));

function useStorage(base = "") {
  return base ? prefixStorage(storage, base) : storage;
}

function serialize$1(o){return typeof o=="string"?`'${o}'`:new c().serialize(o)}const c=/*@__PURE__*/function(){class o{#t=new Map;compare(t,r){const e=typeof t,n=typeof r;return e==="string"&&n==="string"?t.localeCompare(r):e==="number"&&n==="number"?t-r:String.prototype.localeCompare.call(this.serialize(t,true),this.serialize(r,true))}serialize(t,r){if(t===null)return "null";switch(typeof t){case "string":return r?t:`'${t}'`;case "bigint":return `${t}n`;case "object":return this.$object(t);case "function":return this.$function(t)}return String(t)}serializeObject(t){const r=Object.prototype.toString.call(t);if(r!=="[object Object]")return this.serializeBuiltInType(r.length<10?`unknown:${r}`:r.slice(8,-1),t);const e=t.constructor,n=e===Object||e===void 0?"":e.name;if(n!==""&&globalThis[n]===e)return this.serializeBuiltInType(n,t);if(typeof t.toJSON=="function"){const i=t.toJSON();return n+(i!==null&&typeof i=="object"?this.$object(i):`(${this.serialize(i)})`)}return this.serializeObjectEntries(n,Object.entries(t))}serializeBuiltInType(t,r){const e=this["$"+t];if(e)return e.call(this,r);if(typeof r?.entries=="function")return this.serializeObjectEntries(t,r.entries());throw new Error(`Cannot serialize ${t}`)}serializeObjectEntries(t,r){const e=Array.from(r).sort((i,a)=>this.compare(i[0],a[0]));let n=`${t}{`;for(let i=0;i<e.length;i++){const[a,l]=e[i];n+=`${this.serialize(a,true)}:${this.serialize(l)}`,i<e.length-1&&(n+=",");}return n+"}"}$object(t){let r=this.#t.get(t);return r===void 0&&(this.#t.set(t,`#${this.#t.size}`),r=this.serializeObject(t),this.#t.set(t,r)),r}$function(t){const r=Function.prototype.toString.call(t);return r.slice(-15)==="[native code] }"?`${t.name||""}()[native]`:`${t.name}(${t.length})${r.replace(/\s*\n\s*/g,"")}`}$Array(t){let r="[";for(let e=0;e<t.length;e++)r+=this.serialize(t[e]),e<t.length-1&&(r+=",");return r+"]"}$Date(t){try{return `Date(${t.toISOString()})`}catch{return "Date(null)"}}$ArrayBuffer(t){return `ArrayBuffer[${new Uint8Array(t).join(",")}]`}$Set(t){return `Set${this.$Array(Array.from(t).sort((r,e)=>this.compare(r,e)))}`}$Map(t){return this.serializeObjectEntries("Map",t.entries())}}for(const s of ["Error","RegExp","URL"])o.prototype["$"+s]=function(t){return `${s}(${t})`};for(const s of ["Int8Array","Uint8Array","Uint8ClampedArray","Int16Array","Uint16Array","Int32Array","Uint32Array","Float32Array","Float64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join(",")}]`};for(const s of ["BigInt64Array","BigUint64Array"])o.prototype["$"+s]=function(t){return `${s}[${t.join("n,")}${t.length>0?"n":""}]`};return o}();

function isEqual(object1, object2) {
  if (object1 === object2) {
    return true;
  }
  if (serialize$1(object1) === serialize$1(object2)) {
    return true;
  }
  return false;
}

const e=globalThis.process?.getBuiltinModule?.("crypto")?.hash,r="sha256",s="base64url";function digest(t){if(e)return e(r,t,s);const o=createHash(r).update(t);return globalThis.process?.versions?.webcontainer?o.digest().toString(s):o.digest(s)}

function hash$1(input) {
  return digest(serialize$1(input));
}

const Hasher = /* @__PURE__ */ (() => {
  class Hasher2 {
    buff = "";
    #context = /* @__PURE__ */ new Map();
    write(str) {
      this.buff += str;
    }
    dispatch(value) {
      const type = value === null ? "null" : typeof value;
      return this[type](value);
    }
    object(object) {
      if (object && typeof object.toJSON === "function") {
        return this.object(object.toJSON());
      }
      const objString = Object.prototype.toString.call(object);
      let objType = "";
      const objectLength = objString.length;
      objType = objectLength < 10 ? "unknown:[" + objString + "]" : objString.slice(8, objectLength - 1);
      objType = objType.toLowerCase();
      let objectNumber = null;
      if ((objectNumber = this.#context.get(object)) === void 0) {
        this.#context.set(object, this.#context.size);
      } else {
        return this.dispatch("[CIRCULAR:" + objectNumber + "]");
      }
      if (typeof Buffer !== "undefined" && Buffer.isBuffer && Buffer.isBuffer(object)) {
        this.write("buffer:");
        return this.write(object.toString("utf8"));
      }
      if (objType !== "object" && objType !== "function" && objType !== "asyncfunction") {
        if (this[objType]) {
          this[objType](object);
        } else {
          this.unknown(object, objType);
        }
      } else {
        const keys = Object.keys(object).sort();
        const extraKeys = [];
        this.write("object:" + (keys.length + extraKeys.length) + ":");
        const dispatchForKey = (key) => {
          this.dispatch(key);
          this.write(":");
          this.dispatch(object[key]);
          this.write(",");
        };
        for (const key of keys) {
          dispatchForKey(key);
        }
        for (const key of extraKeys) {
          dispatchForKey(key);
        }
      }
    }
    array(arr, unordered) {
      unordered = unordered === void 0 ? false : unordered;
      this.write("array:" + arr.length + ":");
      if (!unordered || arr.length <= 1) {
        for (const entry of arr) {
          this.dispatch(entry);
        }
        return;
      }
      const contextAdditions = /* @__PURE__ */ new Map();
      const entries = arr.map((entry) => {
        const hasher = new Hasher2();
        hasher.dispatch(entry);
        for (const [key, value] of hasher.#context) {
          contextAdditions.set(key, value);
        }
        return hasher.toString();
      });
      this.#context = contextAdditions;
      entries.sort();
      return this.array(entries, false);
    }
    date(date) {
      return this.write("date:" + date.toJSON());
    }
    symbol(sym) {
      return this.write("symbol:" + sym.toString());
    }
    unknown(value, type) {
      this.write(type);
      if (!value) {
        return;
      }
      this.write(":");
      if (value && typeof value.entries === "function") {
        return this.array(
          [...value.entries()],
          true
          /* ordered */
        );
      }
    }
    error(err) {
      return this.write("error:" + err.toString());
    }
    boolean(bool) {
      return this.write("bool:" + bool);
    }
    string(string) {
      this.write("string:" + string.length + ":");
      this.write(string);
    }
    function(fn) {
      this.write("fn:");
      if (isNativeFunction(fn)) {
        this.dispatch("[native]");
      } else {
        this.dispatch(fn.toString());
      }
    }
    number(number) {
      return this.write("number:" + number);
    }
    null() {
      return this.write("Null");
    }
    undefined() {
      return this.write("Undefined");
    }
    regexp(regex) {
      return this.write("regex:" + regex.toString());
    }
    arraybuffer(arr) {
      this.write("arraybuffer:");
      return this.dispatch(new Uint8Array(arr));
    }
    url(url) {
      return this.write("url:" + url.toString());
    }
    map(map) {
      this.write("map:");
      const arr = [...map];
      return this.array(arr, false);
    }
    set(set) {
      this.write("set:");
      const arr = [...set];
      return this.array(arr, false);
    }
    bigint(number) {
      return this.write("bigint:" + number.toString());
    }
  }
  for (const type of [
    "uint8array",
    "uint8clampedarray",
    "unt8array",
    "uint16array",
    "unt16array",
    "uint32array",
    "unt32array",
    "float32array",
    "float64array"
  ]) {
    Hasher2.prototype[type] = function(arr) {
      this.write(type + ":");
      return this.array([...arr], false);
    };
  }
  function isNativeFunction(f) {
    if (typeof f !== "function") {
      return false;
    }
    return Function.prototype.toString.call(f).slice(
      -15
      /* "[native code] }".length */
    ) === "[native code] }";
  }
  return Hasher2;
})();
function serialize(object) {
  const hasher = new Hasher();
  hasher.dispatch(object);
  return hasher.buff;
}
function hash(value) {
  return digest(typeof value === "string" ? value : serialize(value)).replace(/[-_]/g, "").slice(0, 10);
}

function defaultCacheOptions() {
  return {
    name: "_",
    base: "/cache",
    swr: true,
    maxAge: 1
  };
}
function defineCachedFunction(fn, opts = {}) {
  opts = { ...defaultCacheOptions(), ...opts };
  const pending = {};
  const group = opts.group || "nitro/functions";
  const name = opts.name || fn.name || "_";
  const integrity = opts.integrity || hash([fn, opts]);
  const validate = opts.validate || ((entry) => entry.value !== void 0);
  async function get(key, resolver, shouldInvalidateCache, event) {
    const cacheKey = [opts.base, group, name, key + ".json"].filter(Boolean).join(":").replace(/:\/$/, ":index");
    let entry = await useStorage().getItem(cacheKey).catch((error) => {
      console.error(`[cache] Cache read error.`, error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }) || {};
    if (typeof entry !== "object") {
      entry = {};
      const error = new Error("Malformed data read from cache.");
      console.error("[cache]", error);
      useNitroApp().captureError(error, { event, tags: ["cache"] });
    }
    const ttl = (opts.maxAge ?? 0) * 1e3;
    if (ttl) {
      entry.expires = Date.now() + ttl;
    }
    const expired = shouldInvalidateCache || entry.integrity !== integrity || ttl && Date.now() - (entry.mtime || 0) > ttl || validate(entry) === false;
    const _resolve = async () => {
      const isPending = pending[key];
      if (!isPending) {
        if (entry.value !== void 0 && (opts.staleMaxAge || 0) >= 0 && opts.swr === false) {
          entry.value = void 0;
          entry.integrity = void 0;
          entry.mtime = void 0;
          entry.expires = void 0;
        }
        pending[key] = Promise.resolve(resolver());
      }
      try {
        entry.value = await pending[key];
      } catch (error) {
        if (!isPending) {
          delete pending[key];
        }
        throw error;
      }
      if (!isPending) {
        entry.mtime = Date.now();
        entry.integrity = integrity;
        delete pending[key];
        if (validate(entry) !== false) {
          let setOpts;
          if (opts.maxAge && !opts.swr) {
            setOpts = { ttl: opts.maxAge };
          }
          const promise = useStorage().setItem(cacheKey, entry, setOpts).catch((error) => {
            console.error(`[cache] Cache write error.`, error);
            useNitroApp().captureError(error, { event, tags: ["cache"] });
          });
          if (event?.waitUntil) {
            event.waitUntil(promise);
          }
        }
      }
    };
    const _resolvePromise = expired ? _resolve() : Promise.resolve();
    if (entry.value === void 0) {
      await _resolvePromise;
    } else if (expired && event && event.waitUntil) {
      event.waitUntil(_resolvePromise);
    }
    if (opts.swr && validate(entry) !== false) {
      _resolvePromise.catch((error) => {
        console.error(`[cache] SWR handler error.`, error);
        useNitroApp().captureError(error, { event, tags: ["cache"] });
      });
      return entry;
    }
    return _resolvePromise.then(() => entry);
  }
  return async (...args) => {
    const shouldBypassCache = await opts.shouldBypassCache?.(...args);
    if (shouldBypassCache) {
      return fn(...args);
    }
    const key = await (opts.getKey || getKey)(...args);
    const shouldInvalidateCache = await opts.shouldInvalidateCache?.(...args);
    const entry = await get(
      key,
      () => fn(...args),
      shouldInvalidateCache,
      args[0] && isEvent(args[0]) ? args[0] : void 0
    );
    let value = entry.value;
    if (opts.transform) {
      value = await opts.transform(entry, ...args) || value;
    }
    return value;
  };
}
function cachedFunction(fn, opts = {}) {
  return defineCachedFunction(fn, opts);
}
function getKey(...args) {
  return args.length > 0 ? hash(args) : "";
}
function escapeKey(key) {
  return String(key).replace(/\W/g, "");
}
function defineCachedEventHandler(handler, opts = defaultCacheOptions()) {
  const variableHeaderNames = (opts.varies || []).filter(Boolean).map((h) => h.toLowerCase()).sort();
  const _opts = {
    ...opts,
    getKey: async (event) => {
      const customKey = await opts.getKey?.(event);
      if (customKey) {
        return escapeKey(customKey);
      }
      const _path = event.node.req.originalUrl || event.node.req.url || event.path;
      let _pathname;
      try {
        _pathname = escapeKey(decodeURI(parseURL(_path).pathname)).slice(0, 16) || "index";
      } catch {
        _pathname = "-";
      }
      const _hashedPath = `${_pathname}.${hash(_path)}`;
      const _headers = variableHeaderNames.map((header) => [header, event.node.req.headers[header]]).map(([name, value]) => `${escapeKey(name)}.${hash(value)}`);
      return [_hashedPath, ..._headers].join(":");
    },
    validate: (entry) => {
      if (!entry.value) {
        return false;
      }
      if (entry.value.code >= 400) {
        return false;
      }
      if (entry.value.body === void 0) {
        return false;
      }
      if (entry.value.headers.etag === "undefined" || entry.value.headers["last-modified"] === "undefined") {
        return false;
      }
      return true;
    },
    group: opts.group || "nitro/handlers",
    integrity: opts.integrity || hash([handler, opts])
  };
  const _cachedHandler = cachedFunction(
    async (incomingEvent) => {
      const variableHeaders = {};
      for (const header of variableHeaderNames) {
        const value = incomingEvent.node.req.headers[header];
        if (value !== void 0) {
          variableHeaders[header] = value;
        }
      }
      const reqProxy = cloneWithProxy(incomingEvent.node.req, {
        headers: variableHeaders
      });
      const resHeaders = {};
      let _resSendBody;
      const resProxy = cloneWithProxy(incomingEvent.node.res, {
        statusCode: 200,
        writableEnded: false,
        writableFinished: false,
        headersSent: false,
        closed: false,
        getHeader(name) {
          return resHeaders[name];
        },
        setHeader(name, value) {
          resHeaders[name] = value;
          return this;
        },
        getHeaderNames() {
          return Object.keys(resHeaders);
        },
        hasHeader(name) {
          return name in resHeaders;
        },
        removeHeader(name) {
          delete resHeaders[name];
        },
        getHeaders() {
          return resHeaders;
        },
        end(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2();
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return this;
        },
        write(chunk, arg2, arg3) {
          if (typeof chunk === "string") {
            _resSendBody = chunk;
          }
          if (typeof arg2 === "function") {
            arg2(void 0);
          }
          if (typeof arg3 === "function") {
            arg3();
          }
          return true;
        },
        writeHead(statusCode, headers2) {
          this.statusCode = statusCode;
          if (headers2) {
            if (Array.isArray(headers2) || typeof headers2 === "string") {
              throw new TypeError("Raw headers  is not supported.");
            }
            for (const header in headers2) {
              const value = headers2[header];
              if (value !== void 0) {
                this.setHeader(
                  header,
                  value
                );
              }
            }
          }
          return this;
        }
      });
      const event = createEvent(reqProxy, resProxy);
      event.fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: useNitroApp().localFetch
      });
      event.$fetch = (url, fetchOptions) => fetchWithEvent(event, url, fetchOptions, {
        fetch: globalThis.$fetch
      });
      event.waitUntil = incomingEvent.waitUntil;
      event.context = incomingEvent.context;
      event.context.cache = {
        options: _opts
      };
      const body = await handler(event) || _resSendBody;
      const headers = event.node.res.getHeaders();
      headers.etag = String(
        headers.Etag || headers.etag || `W/"${hash(body)}"`
      );
      headers["last-modified"] = String(
        headers["Last-Modified"] || headers["last-modified"] || (/* @__PURE__ */ new Date()).toUTCString()
      );
      const cacheControl = [];
      if (opts.swr) {
        if (opts.maxAge) {
          cacheControl.push(`s-maxage=${opts.maxAge}`);
        }
        if (opts.staleMaxAge) {
          cacheControl.push(`stale-while-revalidate=${opts.staleMaxAge}`);
        } else {
          cacheControl.push("stale-while-revalidate");
        }
      } else if (opts.maxAge) {
        cacheControl.push(`max-age=${opts.maxAge}`);
      }
      if (cacheControl.length > 0) {
        headers["cache-control"] = cacheControl.join(", ");
      }
      const cacheEntry = {
        code: event.node.res.statusCode,
        headers,
        body
      };
      return cacheEntry;
    },
    _opts
  );
  return defineEventHandler(async (event) => {
    if (opts.headersOnly) {
      if (handleCacheHeaders(event, { maxAge: opts.maxAge })) {
        return;
      }
      return handler(event);
    }
    const response = await _cachedHandler(
      event
    );
    if (event.node.res.headersSent || event.node.res.writableEnded) {
      return response.body;
    }
    if (handleCacheHeaders(event, {
      modifiedTime: new Date(response.headers["last-modified"]),
      etag: response.headers.etag,
      maxAge: opts.maxAge
    })) {
      return;
    }
    event.node.res.statusCode = response.code;
    for (const name in response.headers) {
      const value = response.headers[name];
      if (name === "set-cookie") {
        event.node.res.appendHeader(
          name,
          splitCookiesString(value)
        );
      } else {
        if (value !== void 0) {
          event.node.res.setHeader(name, value);
        }
      }
    }
    return response.body;
  });
}
function cloneWithProxy(obj, overrides) {
  return new Proxy(obj, {
    get(target, property, receiver) {
      if (property in overrides) {
        return overrides[property];
      }
      return Reflect.get(target, property, receiver);
    },
    set(target, property, value, receiver) {
      if (property in overrides) {
        overrides[property] = value;
        return true;
      }
      return Reflect.set(target, property, value, receiver);
    }
  });
}
const cachedEventHandler = defineCachedEventHandler;

function klona(x) {
	if (typeof x !== 'object') return x;

	var k, tmp, str=Object.prototype.toString.call(x);

	if (str === '[object Object]') {
		if (x.constructor !== Object && typeof x.constructor === 'function') {
			tmp = new x.constructor();
			for (k in x) {
				if (x.hasOwnProperty(k) && tmp[k] !== x[k]) {
					tmp[k] = klona(x[k]);
				}
			}
		} else {
			tmp = {}; // null
			for (k in x) {
				if (k === '__proto__') {
					Object.defineProperty(tmp, k, {
						value: klona(x[k]),
						configurable: true,
						enumerable: true,
						writable: true,
					});
				} else {
					tmp[k] = klona(x[k]);
				}
			}
		}
		return tmp;
	}

	if (str === '[object Array]') {
		k = x.length;
		for (tmp=Array(k); k--;) {
			tmp[k] = klona(x[k]);
		}
		return tmp;
	}

	if (str === '[object Set]') {
		tmp = new Set;
		x.forEach(function (val) {
			tmp.add(klona(val));
		});
		return tmp;
	}

	if (str === '[object Map]') {
		tmp = new Map;
		x.forEach(function (val, key) {
			tmp.set(klona(key), klona(val));
		});
		return tmp;
	}

	if (str === '[object Date]') {
		return new Date(+x);
	}

	if (str === '[object RegExp]') {
		tmp = new RegExp(x.source, x.flags);
		tmp.lastIndex = x.lastIndex;
		return tmp;
	}

	if (str === '[object DataView]') {
		return new x.constructor( klona(x.buffer) );
	}

	if (str === '[object ArrayBuffer]') {
		return x.slice(0);
	}

	// ArrayBuffer.isView(x)
	// ~> `new` bcuz `Buffer.slice` => ref
	if (str.slice(-6) === 'Array]') {
		return new x.constructor(x);
	}

	return x;
}

const inlineAppConfig = {
  "nuxt": {}
};



const appConfig = defuFn(inlineAppConfig);

const NUMBER_CHAR_RE = /\d/;
const STR_SPLITTERS = ["-", "_", "/", "."];
function isUppercase(char = "") {
  if (NUMBER_CHAR_RE.test(char)) {
    return void 0;
  }
  return char !== char.toLowerCase();
}
function splitByCase(str, separators) {
  const splitters = STR_SPLITTERS;
  const parts = [];
  if (!str || typeof str !== "string") {
    return parts;
  }
  let buff = "";
  let previousUpper;
  let previousSplitter;
  for (const char of str) {
    const isSplitter = splitters.includes(char);
    if (isSplitter === true) {
      parts.push(buff);
      buff = "";
      previousUpper = void 0;
      continue;
    }
    const isUpper = isUppercase(char);
    if (previousSplitter === false) {
      if (previousUpper === false && isUpper === true) {
        parts.push(buff);
        buff = char;
        previousUpper = isUpper;
        continue;
      }
      if (previousUpper === true && isUpper === false && buff.length > 1) {
        const lastChar = buff.at(-1);
        parts.push(buff.slice(0, Math.max(0, buff.length - 1)));
        buff = lastChar + char;
        previousUpper = isUpper;
        continue;
      }
    }
    buff += char;
    previousUpper = isUpper;
    previousSplitter = isSplitter;
  }
  parts.push(buff);
  return parts;
}
function kebabCase(str, joiner) {
  return str ? (Array.isArray(str) ? str : splitByCase(str)).map((p) => p.toLowerCase()).join(joiner) : "";
}
function snakeCase(str) {
  return kebabCase(str || "", "_");
}

function getEnv(key, opts) {
  const envKey = snakeCase(key).toUpperCase();
  return destr(
    process.env[opts.prefix + envKey] ?? process.env[opts.altPrefix + envKey]
  );
}
function _isObject(input) {
  return typeof input === "object" && !Array.isArray(input);
}
function applyEnv(obj, opts, parentKey = "") {
  for (const key in obj) {
    const subKey = parentKey ? `${parentKey}_${key}` : key;
    const envValue = getEnv(subKey, opts);
    if (_isObject(obj[key])) {
      if (_isObject(envValue)) {
        obj[key] = { ...obj[key], ...envValue };
        applyEnv(obj[key], opts, subKey);
      } else if (envValue === void 0) {
        applyEnv(obj[key], opts, subKey);
      } else {
        obj[key] = envValue ?? obj[key];
      }
    } else {
      obj[key] = envValue ?? obj[key];
    }
    if (opts.envExpansion && typeof obj[key] === "string") {
      obj[key] = _expandFromEnv(obj[key]);
    }
  }
  return obj;
}
const envExpandRx = /\{\{([^{}]*)\}\}/g;
function _expandFromEnv(value) {
  return value.replace(envExpandRx, (match, key) => {
    return process.env[key] || match;
  });
}

const _inlineRuntimeConfig = {
  "app": {
    "baseURL": "/",
    "buildId": "641000f4-43e8-415e-ba78-b1197918ab90",
    "buildAssetsDir": "/_nuxt/",
    "cdnURL": ""
  },
  "nitro": {
    "envPrefix": "NUXT_",
    "routeRules": {
      "/__nuxt_error": {
        "cache": false
      },
      "/_nuxt/builds/meta/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      },
      "/_nuxt/builds/**": {
        "headers": {
          "cache-control": "public, max-age=1, immutable"
        }
      },
      "/_nuxt/**": {
        "headers": {
          "cache-control": "public, max-age=31536000, immutable"
        }
      }
    }
  },
  "public": {
    "apiPrefix": "/api",
    "apiBase": "http://localhost:8086",
    "piniaPluginPersistedstate": {}
  }
};
const envOptions = {
  prefix: "NITRO_",
  altPrefix: _inlineRuntimeConfig.nitro.envPrefix ?? process.env.NITRO_ENV_PREFIX ?? "_",
  envExpansion: _inlineRuntimeConfig.nitro.envExpansion ?? process.env.NITRO_ENV_EXPANSION ?? false
};
const _sharedRuntimeConfig = _deepFreeze(
  applyEnv(klona(_inlineRuntimeConfig), envOptions)
);
function useRuntimeConfig(event) {
  if (!event) {
    return _sharedRuntimeConfig;
  }
  if (event.context.nitro.runtimeConfig) {
    return event.context.nitro.runtimeConfig;
  }
  const runtimeConfig = klona(_inlineRuntimeConfig);
  applyEnv(runtimeConfig, envOptions);
  event.context.nitro.runtimeConfig = runtimeConfig;
  return runtimeConfig;
}
_deepFreeze(klona(appConfig));
function _deepFreeze(object) {
  const propNames = Object.getOwnPropertyNames(object);
  for (const name of propNames) {
    const value = object[name];
    if (value && typeof value === "object") {
      _deepFreeze(value);
    }
  }
  return Object.freeze(object);
}
new Proxy(/* @__PURE__ */ Object.create(null), {
  get: (_, prop) => {
    console.warn(
      "Please use `useRuntimeConfig()` instead of accessing config directly."
    );
    const runtimeConfig = useRuntimeConfig();
    if (prop in runtimeConfig) {
      return runtimeConfig[prop];
    }
    return void 0;
  }
});

function createContext(opts = {}) {
  let currentInstance;
  let isSingleton = false;
  const checkConflict = (instance) => {
    if (currentInstance && currentInstance !== instance) {
      throw new Error("Context conflict");
    }
  };
  let als;
  if (opts.asyncContext) {
    const _AsyncLocalStorage = opts.AsyncLocalStorage || globalThis.AsyncLocalStorage;
    if (_AsyncLocalStorage) {
      als = new _AsyncLocalStorage();
    } else {
      console.warn("[unctx] `AsyncLocalStorage` is not provided.");
    }
  }
  const _getCurrentInstance = () => {
    if (als) {
      const instance = als.getStore();
      if (instance !== void 0) {
        return instance;
      }
    }
    return currentInstance;
  };
  return {
    use: () => {
      const _instance = _getCurrentInstance();
      if (_instance === void 0) {
        throw new Error("Context is not available");
      }
      return _instance;
    },
    tryUse: () => {
      return _getCurrentInstance();
    },
    set: (instance, replace) => {
      if (!replace) {
        checkConflict(instance);
      }
      currentInstance = instance;
      isSingleton = true;
    },
    unset: () => {
      currentInstance = void 0;
      isSingleton = false;
    },
    call: (instance, callback) => {
      checkConflict(instance);
      currentInstance = instance;
      try {
        return als ? als.run(instance, callback) : callback();
      } finally {
        if (!isSingleton) {
          currentInstance = void 0;
        }
      }
    },
    async callAsync(instance, callback) {
      currentInstance = instance;
      const onRestore = () => {
        currentInstance = instance;
      };
      const onLeave = () => currentInstance === instance ? onRestore : void 0;
      asyncHandlers.add(onLeave);
      try {
        const r = als ? als.run(instance, callback) : callback();
        if (!isSingleton) {
          currentInstance = void 0;
        }
        return await r;
      } finally {
        asyncHandlers.delete(onLeave);
      }
    }
  };
}
function createNamespace(defaultOpts = {}) {
  const contexts = {};
  return {
    get(key, opts = {}) {
      if (!contexts[key]) {
        contexts[key] = createContext({ ...defaultOpts, ...opts });
      }
      return contexts[key];
    }
  };
}
const _globalThis = typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : typeof global !== "undefined" ? global : {};
const globalKey = "__unctx__";
const defaultNamespace = _globalThis[globalKey] || (_globalThis[globalKey] = createNamespace());
const getContext = (key, opts = {}) => defaultNamespace.get(key, opts);
const asyncHandlersKey = "__unctx_async_handlers__";
const asyncHandlers = _globalThis[asyncHandlersKey] || (_globalThis[asyncHandlersKey] = /* @__PURE__ */ new Set());
function executeAsync(function_) {
  const restores = [];
  for (const leaveHandler of asyncHandlers) {
    const restore2 = leaveHandler();
    if (restore2) {
      restores.push(restore2);
    }
  }
  const restore = () => {
    for (const restore2 of restores) {
      restore2();
    }
  };
  let awaitable = function_();
  if (awaitable && typeof awaitable === "object" && "catch" in awaitable) {
    awaitable = awaitable.catch((error) => {
      restore();
      throw error;
    });
  }
  return [awaitable, restore];
}

getContext("nitro-app", {
  asyncContext: false,
  AsyncLocalStorage: void 0
});

function isPathInScope(pathname, base) {
  let canonical;
  try {
    const pre = pathname.replace(/%2f/gi, "/").replace(/%5c/gi, "\\");
    canonical = new URL(pre, "http://_").pathname;
  } catch {
    return false;
  }
  return !base || canonical === base || canonical.startsWith(base + "/");
}

const config = useRuntimeConfig();
const _routeRulesMatcher = toRouteMatcher(
  createRouter$1({ routes: config.nitro.routeRules })
);
function createRouteRulesHandler(ctx) {
  return eventHandler((event) => {
    const routeRules = getRouteRules(event);
    if (routeRules.headers) {
      setHeaders(event, routeRules.headers);
    }
    if (routeRules.redirect) {
      let target = routeRules.redirect.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.redirect._redirectStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return sendRedirect(event, target, routeRules.redirect.statusCode);
    }
    if (routeRules.proxy) {
      let target = routeRules.proxy.to;
      if (target.endsWith("/**")) {
        let targetPath = event.path;
        const strpBase = routeRules.proxy._proxyStripBase;
        if (strpBase) {
          if (!isPathInScope(event.path.split("?")[0], strpBase)) {
            throw createError$1({ statusCode: 400 });
          }
          targetPath = withoutBase(targetPath, strpBase);
        } else if (targetPath.startsWith("//")) {
          targetPath = targetPath.replace(/^\/+/, "/");
        }
        target = joinURL(target.slice(0, -3), targetPath);
      } else if (event.path.includes("?")) {
        const query = getQuery$1(event.path);
        target = withQuery(target, query);
      }
      return proxyRequest(event, target, {
        fetch: ctx.localFetch,
        ...routeRules.proxy
      });
    }
  });
}
function getRouteRules(event) {
  event.context._nitro = event.context._nitro || {};
  if (!event.context._nitro.routeRules) {
    event.context._nitro.routeRules = getRouteRulesForPath(
      withoutBase(event.path.split("?")[0], useRuntimeConfig().app.baseURL)
    );
  }
  return event.context._nitro.routeRules;
}
function getRouteRulesForPath(path) {
  return defu({}, ..._routeRulesMatcher.matchAll(path).reverse());
}

function _captureError(error, type) {
  console.error(`[${type}]`, error);
  useNitroApp().captureError(error, { tags: [type] });
}
function trapUnhandledNodeErrors() {
  process.on(
    "unhandledRejection",
    (error) => _captureError(error, "unhandledRejection")
  );
  process.on(
    "uncaughtException",
    (error) => _captureError(error, "uncaughtException")
  );
}
function joinHeaders(value) {
  return Array.isArray(value) ? value.join(", ") : String(value);
}
function normalizeFetchResponse(response) {
  if (!response.headers.has("set-cookie")) {
    return response;
  }
  return new Response(response.body, {
    status: response.status,
    statusText: response.statusText,
    headers: normalizeCookieHeaders(response.headers)
  });
}
function normalizeCookieHeader(header = "") {
  return splitCookiesString(joinHeaders(header));
}
function normalizeCookieHeaders(headers) {
  const outgoingHeaders = new Headers();
  for (const [name, header] of headers) {
    if (name === "set-cookie") {
      for (const cookie of normalizeCookieHeader(header)) {
        outgoingHeaders.append("set-cookie", cookie);
      }
    } else {
      outgoingHeaders.set(name, joinHeaders(header));
    }
  }
  return outgoingHeaders;
}

function isJsonRequest(event) {
	
	if (hasReqHeader(event, "accept", "text/html")) {
		return false;
	}
	return hasReqHeader(event, "accept", "application/json") || hasReqHeader(event, "user-agent", "curl/") || hasReqHeader(event, "user-agent", "httpie/") || hasReqHeader(event, "sec-fetch-mode", "cors") || event.path.startsWith("/api/") || event.path.endsWith(".json");
}
function hasReqHeader(event, name, includes) {
	const value = getRequestHeader(event, name);
	return !!(value && typeof value === "string" && value.toLowerCase().includes(includes));
}

const errorHandler$0 = (async function errorhandler(error, event, { defaultHandler }) {
	if (event.handled || isJsonRequest(event)) {
		
		return;
	}
	
	const defaultRes = await defaultHandler(error, event, { json: true });
	
	const status = error.status || error.statusCode || 500;
	if (status === 404 && defaultRes.status === 302) {
		setResponseHeaders(event, defaultRes.headers);
		setResponseStatus(event, defaultRes.status, defaultRes.statusText);
		return send(event, JSON.stringify(defaultRes.body, null, 2));
	}
	const errorObject = defaultRes.body;
	
	const url = new URL(errorObject.url);
	errorObject.url = withoutBase(url.pathname, useRuntimeConfig(event).app.baseURL) + url.search + url.hash;
	
	errorObject.message = error.unhandled ? errorObject.message || "Server Error" : error.message || errorObject.message || "Server Error";
	
	errorObject.data ||= error.data;
	errorObject.statusText ||= error.statusText || error.statusMessage;
	delete defaultRes.headers["content-type"];
	delete defaultRes.headers["content-security-policy"];
	setResponseHeaders(event, defaultRes.headers);
	
	const reqHeaders = getRequestHeaders(event);
	
	const isRenderingError = event.path.startsWith("/__nuxt_error") || !!reqHeaders["x-nuxt-error"];
	
	const res = isRenderingError ? null : await useNitroApp().localFetch(withQuery(joinURL(useRuntimeConfig(event).app.baseURL, "/__nuxt_error"), errorObject), {
		headers: {
			...reqHeaders,
			"x-nuxt-error": "true"
		},
		redirect: "manual"
	}).catch(() => null);
	if (event.handled) {
		return;
	}
	
	if (!res) {
		const { template } = await import('../_/error-500.mjs');
		setResponseHeader(event, "Content-Type", "text/html;charset=UTF-8");
		return send(event, template(errorObject));
	}
	const html = await res.text();
	for (const [header, value] of res.headers.entries()) {
		if (header === "set-cookie") {
			appendResponseHeader(event, header, value);
			continue;
		}
		setResponseHeader(event, header, value);
	}
	setResponseStatus(event, res.status && res.status !== 200 ? res.status : defaultRes.status, res.statusText || defaultRes.statusText);
	return send(event, html);
});

function defineNitroErrorHandler(handler) {
  return handler;
}

const errorHandler$1 = defineNitroErrorHandler(
  function defaultNitroErrorHandler(error, event) {
    const res = defaultHandler(error, event);
    setResponseHeaders(event, res.headers);
    setResponseStatus(event, res.status, res.statusText);
    return send(event, JSON.stringify(res.body, null, 2));
  }
);
function defaultHandler(error, event, opts) {
  const isSensitive = error.unhandled || error.fatal;
  const statusCode = error.statusCode || 500;
  const statusMessage = error.statusMessage || "Server Error";
  const url = getRequestURL(event, { xForwardedHost: true, xForwardedProto: true });
  if (statusCode === 404) {
    const baseURL = "/";
    if (/^\/[^/]/.test(baseURL) && !url.pathname.startsWith(baseURL)) {
      const redirectTo = `${baseURL}${url.pathname.slice(1)}${url.search}`;
      return {
        status: 302,
        statusText: "Found",
        headers: { location: redirectTo },
        body: `Redirecting...`
      };
    }
  }
  if (isSensitive && !opts?.silent) {
    const tags = [error.unhandled && "[unhandled]", error.fatal && "[fatal]"].filter(Boolean).join(" ");
    console.error(`[request error] ${tags} [${event.method}] ${url}
`, error);
  }
  const headers = {
    "content-type": "application/json",
    // Prevent browser from guessing the MIME types of resources.
    "x-content-type-options": "nosniff",
    // Prevent error page from being embedded in an iframe
    "x-frame-options": "DENY",
    // Prevent browsers from sending the Referer header
    "referrer-policy": "no-referrer",
    // Disable the execution of any js
    "content-security-policy": "script-src 'none'; frame-ancestors 'none';"
  };
  setResponseStatus(event, statusCode, statusMessage);
  if (statusCode === 404 || !getResponseHeader(event, "cache-control")) {
    headers["cache-control"] = "no-cache";
  }
  const body = {
    error: true,
    url: url.href,
    statusCode,
    statusMessage,
    message: isSensitive ? "Server Error" : error.message,
    data: isSensitive ? void 0 : error.data
  };
  return {
    status: statusCode,
    statusText: statusMessage,
    headers,
    body
  };
}

const errorHandlers = [errorHandler$0, errorHandler$1];

async function errorHandler(error, event) {
  for (const handler of errorHandlers) {
    try {
      await handler(error, event, { defaultHandler });
      if (event.handled) {
        return; // Response handled
      }
    } catch(error) {
      // Handler itself thrown, log and continue
      console.error(error);
    }
  }
  // H3 will handle fallback
}

function defineNitroPlugin(def) {
  return def;
}

const _T6iO5HPOdCVPuNIin0MzW0LKocXFzGCHBJ5kuBzgNE8 = defineNitroPlugin((nitroApp) => {
  nitroApp.hooks.hook("render:html", (html) => {
    if (!Array.isArray(html.bodyAppend)) html.bodyAppend = [];
    if (html.bodyAppend.some((t) => t.includes("app-loading"))) return;
    const loaderHtml = `
<div id="app-loading" class="app-loading" role="status" aria-label="Loading">
  <div class="app-loading-spinner"></div>
  <div class="app-loading-text">JAY.BLOG</div>
</div>
`;
    html.bodyAppend.push(loaderHtml);
  });
});

const plugins = [
  _T6iO5HPOdCVPuNIin0MzW0LKocXFzGCHBJ5kuBzgNE8
];

const assets = {
  "/favicon.ico": {
    "type": "image/vnd.microsoft.icon",
    "etag": "\"10be-n8egyE9tcb7sKGr/pYCaQ4uWqxI\"",
    "mtime": "2026-08-31T14:31:19.746Z",
    "size": 4286,
    "path": "../public/favicon.ico"
  },
  "/favicon.svg": {
    "type": "image/svg+xml",
    "etag": "\"1ee-hwTd0j9oTrupSPbKBbMu9lHw8Eo\"",
    "mtime": "2026-08-31T14:31:19.746Z",
    "size": 494,
    "path": "../public/favicon.svg"
  },
  "/manifest.webmanifest": {
    "type": "application/manifest+json",
    "etag": "\"15c-CkIiRQT9Hd3lkoWsbVFyBCddGws\"",
    "mtime": "2026-08-31T14:31:19.712Z",
    "size": 348,
    "path": "../public/manifest.webmanifest"
  },
  "/og-cover.svg": {
    "type": "image/svg+xml",
    "etag": "\"7dd-gV+4OIIPZjCehMFo2HFuTFFGPlE\"",
    "mtime": "2026-08-31T14:31:19.746Z",
    "size": 2013,
    "path": "../public/og-cover.svg"
  },
  "/robots.txt": {
    "type": "text/plain; charset=utf-8",
    "etag": "\"18-j8OIsL9qGDmNZ+lHhp2tyH4XtaE\"",
    "mtime": "2026-08-31T14:31:19.746Z",
    "size": 24,
    "path": "../public/robots.txt"
  },
  "/_nuxt/-L3eBynH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8fd-QbRC0hMNQXk16buduvPwWZMbo68\"",
    "mtime": "2026-08-31T14:31:19.741Z",
    "size": 2301,
    "path": "../public/_nuxt/-L3eBynH.js"
  },
  "/workbox-e5cff4b9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5578-Ud8dRfAuVommbMfhUBJ+pAe72gU\"",
    "mtime": "2026-08-31T14:31:20.624Z",
    "size": 21880,
    "path": "../public/workbox-e5cff4b9.js"
  },
  "/_nuxt/4D5F-n5U.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"67c-ebZDY1u2yhiihGa9wbWHPSJRKV0\"",
    "mtime": "2026-08-31T14:31:19.730Z",
    "size": 1660,
    "path": "../public/_nuxt/4D5F-n5U.js"
  },
  "/_nuxt/6UpNiIaq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2d31-lsHdi948/1OiNivfkFFkWAp5RMM\"",
    "mtime": "2026-08-31T14:31:19.730Z",
    "size": 11569,
    "path": "../public/_nuxt/6UpNiIaq.js"
  },
  "/sw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"288e-paYLnW3u1C02KeA5VntrICCwtN4\"",
    "mtime": "2026-08-31T14:31:20.624Z",
    "size": 10382,
    "path": "../public/sw.js"
  },
  "/_nuxt/7ixHkPKx.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"514f-U7Yz7e2wr9PSKKrDULA26lCcRQE\"",
    "mtime": "2026-08-31T14:31:19.730Z",
    "size": 20815,
    "path": "../public/_nuxt/7ixHkPKx.js"
  },
  "/_nuxt/B-8jnY81.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1180-ZWdY3NYmf0fn7LR50RAZ17iQD+8\"",
    "mtime": "2026-08-31T14:31:19.730Z",
    "size": 4480,
    "path": "../public/_nuxt/B-8jnY81.js"
  },
  "/_nuxt/B1tBg_DP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7b9-bVKRZU8i1+vUCQV8Xmq9X6xX1mM\"",
    "mtime": "2026-08-31T14:31:19.730Z",
    "size": 1977,
    "path": "../public/_nuxt/B1tBg_DP.js"
  },
  "/_nuxt/B3OsMv9k.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"393d-WO/c0kv79DGMYp5P4I/KrneJ3Qo\"",
    "mtime": "2026-08-31T14:31:19.730Z",
    "size": 14653,
    "path": "../public/_nuxt/B3OsMv9k.js"
  },
  "/_nuxt/B4CMkyY2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8fd-lyp8u6QiNFJ0j90lWnKWv6VB3/8\"",
    "mtime": "2026-08-31T14:31:19.730Z",
    "size": 2301,
    "path": "../public/_nuxt/B4CMkyY2.js"
  },
  "/_nuxt/B4kiWyti.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2476-k1paXLnu9B+ZXhmVPUdwQ9pokgc\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 9334,
    "path": "../public/_nuxt/B4kiWyti.js"
  },
  "/_nuxt/B533Al4x.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"64c6-DAzA/qcrSWkzE9YI/kCbfK0fo2g\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 25798,
    "path": "../public/_nuxt/B533Al4x.js"
  },
  "/_nuxt/B5dirrnb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d5-Rhru3ywhpSIQtZE0hp6FiYR4Tao\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 213,
    "path": "../public/_nuxt/B5dirrnb.js"
  },
  "/_nuxt/B6wPVr8A.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b7e-d8H6XZ5HocE+HQG3/TTWH1si9NU\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 2942,
    "path": "../public/_nuxt/B6wPVr8A.js"
  },
  "/_nuxt/B9uivgTg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"571e-r5KY2eSFi+PnaDNBzimkVGyGArk\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 22302,
    "path": "../public/_nuxt/B9uivgTg.js"
  },
  "/_nuxt/B9xdYoR4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"fd2-Y6HkWka/W26uoU65jVxVF5viSxI\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 4050,
    "path": "../public/_nuxt/B9xdYoR4.js"
  },
  "/_nuxt/BA5vi2Kp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"db6-vQ21m3ZQeSYxagOlf3kyZoDeoYk\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 3510,
    "path": "../public/_nuxt/BA5vi2Kp.js"
  },
  "/_nuxt/-unCOHro.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5f4d2-+uleKvje+2kEtLQ7cduR6i0cWUk\"",
    "mtime": "2026-08-31T14:31:19.741Z",
    "size": 390354,
    "path": "../public/_nuxt/-unCOHro.js"
  },
  "/_nuxt/B2Rjki9n.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"142c-KKM0f4n7Mcqe/xX6b8q9sDTEBOQ\"",
    "mtime": "2026-08-31T14:31:19.730Z",
    "size": 5164,
    "path": "../public/_nuxt/B2Rjki9n.js"
  },
  "/_nuxt/5HRHbU5Z.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f6a-aCSrsfi2LWI/Wosb1hpyB+MukyI\"",
    "mtime": "2026-08-31T14:31:19.730Z",
    "size": 8042,
    "path": "../public/_nuxt/5HRHbU5Z.js"
  },
  "/_nuxt/BBnX5xw4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1674-HyZL1eUl9QW4o4RCa0ogOE8HLCk\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 5748,
    "path": "../public/_nuxt/BBnX5xw4.js"
  },
  "/_nuxt/BCZA_wO0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"472-o3D2g5yx/Z1jkOrHJTKGNVnR1DI\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 1138,
    "path": "../public/_nuxt/BCZA_wO0.js"
  },
  "/_nuxt/BEk9thJj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1a8b-1+2rGYhpUUWMkcjHe1zTVwMpPMI\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 6795,
    "path": "../public/_nuxt/BEk9thJj.js"
  },
  "/_nuxt/BEugSyMb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2d72-DO+q/iY1PZ2wRMZOAoNt/YTzTdU\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 11634,
    "path": "../public/_nuxt/BEugSyMb.js"
  },
  "/_nuxt/BFAgLIlb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1348-2F5Bg+3NxfELKPjECXXf5lwibwY\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 4936,
    "path": "../public/_nuxt/BFAgLIlb.js"
  },
  "/_nuxt/BHlzJJRZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"174f-n5VOatfVdtaBFvxCpOjftUlsSUs\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 5967,
    "path": "../public/_nuxt/BHlzJJRZ.js"
  },
  "/_nuxt/BFCCtTvK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7c7d-ayFMRLb2caksydNSmfVY222x+qM\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 31869,
    "path": "../public/_nuxt/BFCCtTvK.js"
  },
  "/_nuxt/BJ4BC0dw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"86a-7M//hJi3CEH4PZPuB6kuqrzgodU\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 2154,
    "path": "../public/_nuxt/BJ4BC0dw.js"
  },
  "/_nuxt/BMjYHr_A.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2a3f-bnwS3hB3zP5ygcKnYLknuasMz+Y\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 10815,
    "path": "../public/_nuxt/BMjYHr_A.js"
  },
  "/_nuxt/BNw1qcRV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1f9f-RYiHlfi/FmpQgxiqXDvHs1RTfqw\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 8095,
    "path": "../public/_nuxt/BNw1qcRV.js"
  },
  "/_nuxt/BQqOBYOt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"30f-DFefkXRPVNlNKqV9hwp3odATW2k\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 783,
    "path": "../public/_nuxt/BQqOBYOt.js"
  },
  "/_nuxt/BT43cFF4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"815-Gu9v3Ip+Ai5wtN8ktXEdXNkxwRU\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 2069,
    "path": "../public/_nuxt/BT43cFF4.js"
  },
  "/_nuxt/BVhg1jT6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"22be-Wwh6yZme81NU9XDQhKwVZ2ZJaGU\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 8894,
    "path": "../public/_nuxt/BVhg1jT6.js"
  },
  "/_nuxt/B_0Y7a6B.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b535-jerCoOuu6tMX6NjkfugsglqXXA8\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 46389,
    "path": "../public/_nuxt/B_0Y7a6B.js"
  },
  "/_nuxt/B_uTE-jC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1649-vDyo9KHeQHwRpCC39T4LHnl0pe4\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 5705,
    "path": "../public/_nuxt/B_uTE-jC.js"
  },
  "/_nuxt/Bb0MdfpT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"200-T72ptuLBEY5usdRW6Rhs4BmHWRs\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 512,
    "path": "../public/_nuxt/Bb0MdfpT.js"
  },
  "/_nuxt/Bd9bhGg5.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5257-kIh3PQd5mDwzKotQLw/gOnxECLQ\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 21079,
    "path": "../public/_nuxt/Bd9bhGg5.js"
  },
  "/_nuxt/BfvgReVJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"836-vREa0gApDBp0ds0W1+DdpNuPlVk\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 2102,
    "path": "../public/_nuxt/BfvgReVJ.js"
  },
  "/_nuxt/BlBGlhcy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"cc2-VF2AWyMNNAvGTVpzMEP0O+k7LHo\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 3266,
    "path": "../public/_nuxt/BlBGlhcy.js"
  },
  "/_nuxt/Bm5Em-hy.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"472-CwqCb2/ZmwaIxhAvTX3tl5Rtx6g\"",
    "mtime": "2026-08-31T14:31:19.731Z",
    "size": 1138,
    "path": "../public/_nuxt/Bm5Em-hy.js"
  },
  "/_nuxt/BnMrqG3P.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"69fc-BLIWxZcj0qygoKcXzUCl3cv2130\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 27132,
    "path": "../public/_nuxt/BnMrqG3P.js"
  },
  "/_nuxt/Bneqetm1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11d7-36M+BuNh3yjzMK2Iy/LNx7j7QHU\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 4567,
    "path": "../public/_nuxt/Bneqetm1.js"
  },
  "/_nuxt/Br8DLbfD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3978-5f5/1yXKbS2s8di+LoKcAQOMx50\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 14712,
    "path": "../public/_nuxt/Br8DLbfD.js"
  },
  "/_nuxt/BuJXcnF6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"16b7-d0GcdVft9Hw2v7NBxaVAZayslzs\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 5815,
    "path": "../public/_nuxt/BuJXcnF6.js"
  },
  "/_nuxt/BuPzkPfP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"194b-5nCdlOOQYn7hcxwshQQ4TPxRa/8\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 6475,
    "path": "../public/_nuxt/BuPzkPfP.js"
  },
  "/_nuxt/BwQOo05w.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ff7-CW5xfGYX9vri7nnm+MMBj5ofLdk\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 4087,
    "path": "../public/_nuxt/BwQOo05w.js"
  },
  "/_nuxt/Bx9AMqL3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"25fe-3D34ra7hs5UiBpUiYpMy5jRhQpU\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 9726,
    "path": "../public/_nuxt/Bx9AMqL3.js"
  },
  "/_nuxt/By8Tirw3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2f61-tPZ2KKoaghKlTYH5DYRlib29tSM\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 12129,
    "path": "../public/_nuxt/By8Tirw3.js"
  },
  "/_nuxt/Byu4wKQ2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4563-Ol7jS2s8F3632sh8kSwZFhGes8A\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 17763,
    "path": "../public/_nuxt/Byu4wKQ2.js"
  },
  "/_nuxt/BzpIVaGY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f73-r9BLGDgyoLaaOrgEZChYdfsh8Zk\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 3955,
    "path": "../public/_nuxt/BzpIVaGY.js"
  },
  "/_nuxt/C-XEfYMY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2791-z/JF0mF7yiTLF0NECqYKCYu//5g\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 10129,
    "path": "../public/_nuxt/C-XEfYMY.js"
  },
  "/_nuxt/BzwKVEFT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b50-Z+/G/yctBtfAHDdPzWvZBeifk78\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 2896,
    "path": "../public/_nuxt/BzwKVEFT.js"
  },
  "/_nuxt/C1YWyW7O.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2993-4LMMJ5bFgGS0wQW683+hWQ4iWfs\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 10643,
    "path": "../public/_nuxt/C1YWyW7O.js"
  },
  "/_nuxt/C2Q229Ql.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11e6-REpnCbCApWiAtuNETI92uFZloQY\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 4582,
    "path": "../public/_nuxt/C2Q229Ql.js"
  },
  "/_nuxt/C3Gn_uJK.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"652-unmA3eX14wtzZiiBzZq/92mvoCY\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 1618,
    "path": "../public/_nuxt/C3Gn_uJK.js"
  },
  "/_nuxt/C3f8Ysf7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"c34-oFv+jsTxXHstmajyod19ibaqmhg\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 3124,
    "path": "../public/_nuxt/C3f8Ysf7.js"
  },
  "/_nuxt/C41bIUwD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"18e0-ok5bgVSVtP3rZsL6S6iN8lz3OoI\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 6368,
    "path": "../public/_nuxt/C41bIUwD.js"
  },
  "/_nuxt/C4LP7Hcl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"25e-g9QCecH5DQ1bgq9XQ8hg/UBC6vM\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 606,
    "path": "../public/_nuxt/C4LP7Hcl.js"
  },
  "/_nuxt/C4B5JI7H.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"195db-aLAr27yij5AW8VfQYKs2hFP/z7A\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 103899,
    "path": "../public/_nuxt/C4B5JI7H.js"
  },
  "/_nuxt/C6RDOZhf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2034-iQtXMdqgAH3R04z9SsHXFudwbK0\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 8244,
    "path": "../public/_nuxt/C6RDOZhf.js"
  },
  "/_nuxt/C78fOPTZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"29b-t1+k46tbt13NbzZqsbOnyYWsuOA\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 667,
    "path": "../public/_nuxt/C78fOPTZ.js"
  },
  "/_nuxt/CAhUzF7g.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"64ab-m+fwzhHacz28/OpZI2fYwQPOCuQ\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 25771,
    "path": "../public/_nuxt/CAhUzF7g.js"
  },
  "/_nuxt/CCS75Kuz.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"83-mUtbRZ8oEL3BDHMDOS3j989mm1w\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 131,
    "path": "../public/_nuxt/CCS75Kuz.js"
  },
  "/_nuxt/CDyGwa7X.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7c2-7vuqMcb2oG5cn8Nk5aii6bsMmsY\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 1986,
    "path": "../public/_nuxt/CDyGwa7X.js"
  },
  "/_nuxt/CFHJl5sT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1e59-dwhojfQzryHqzl6IMu0/Bb2TFqk\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 7769,
    "path": "../public/_nuxt/CFHJl5sT.js"
  },
  "/_nuxt/CLExgr4k.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"77e-KCV1Qtzm1AUv3PbDw1ldECkrZBo\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 1918,
    "path": "../public/_nuxt/CLExgr4k.js"
  },
  "/_nuxt/CN9LRtIa.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"b01c-r05QY9pj+cIH0ixe4W8WP346NlQ\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 45084,
    "path": "../public/_nuxt/CN9LRtIa.js"
  },
  "/_nuxt/CNhZ1qSd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"575-ihPON8Z8YUh2vjvUpYhECzfZmW8\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 1397,
    "path": "../public/_nuxt/CNhZ1qSd.js"
  },
  "/_nuxt/CODI31cl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ce-5TPA3zz38Hw5RkZcEOu7U9UFfKA\"",
    "mtime": "2026-08-31T14:31:19.732Z",
    "size": 206,
    "path": "../public/_nuxt/CODI31cl.js"
  },
  "/_nuxt/CPZrO5cU.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7e17-3Mjr776AKTZPcdNvxSrknpBb02A\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 32279,
    "path": "../public/_nuxt/CPZrO5cU.js"
  },
  "/_nuxt/CQfJNk6m.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4d03-RfXB9/uo/bqkQ1kn/zYrgMeJAwY\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 19715,
    "path": "../public/_nuxt/CQfJNk6m.js"
  },
  "/_nuxt/CSMna6qm.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"4b1-f86anpQMH+w8HgaX5R3qh2FQEpQ\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 1201,
    "path": "../public/_nuxt/CSMna6qm.js"
  },
  "/_nuxt/CTu-6PCP.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"656-G3UZSa34P7Tw0n/dtK+KFlbyceY\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 1622,
    "path": "../public/_nuxt/CTu-6PCP.js"
  },
  "/_nuxt/CUtmouGv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"464-zAEcBjRjMgSRjsS465/HkKnn1UI\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 1124,
    "path": "../public/_nuxt/CUtmouGv.js"
  },
  "/_nuxt/CWcv1MsR.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1839-Y+z7+FegnI5mhOV3RPbsQlymgu8\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 6201,
    "path": "../public/_nuxt/CWcv1MsR.js"
  },
  "/_nuxt/CXdrOF99.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"12b4-PLLfcvk2EoA/+V2x5P2kC1n+B1g\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 4788,
    "path": "../public/_nuxt/CXdrOF99.js"
  },
  "/_nuxt/CXf4wxQc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"63f-Oyvf98XF/NOWWSvler6ciL8Xagk\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 1599,
    "path": "../public/_nuxt/CXf4wxQc.js"
  },
  "/_nuxt/C_CwsFkJ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"de9-b/iha8a7ituYd7CFd8YilK6YRuU\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 3561,
    "path": "../public/_nuxt/C_CwsFkJ.js"
  },
  "/_nuxt/C_YlbXfo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2876-PLAayAL4lcCO/jbVcXqEobk+0OY\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 10358,
    "path": "../public/_nuxt/C_YlbXfo.js"
  },
  "/_nuxt/Cabwm37j.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1408-yJcFOwPhqDMWLPoCOAb1QW47C14\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 5128,
    "path": "../public/_nuxt/Cabwm37j.js"
  },
  "/_nuxt/Cb0sVfnY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1db-QDVAI1d6lw2LScKdtiuhylzVVBg\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 475,
    "path": "../public/_nuxt/Cb0sVfnY.js"
  },
  "/_nuxt/CdXCOZ3F.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2619-rtqKWYGjGbGZG5x8wqUNYLxSXFY\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 9753,
    "path": "../public/_nuxt/CdXCOZ3F.js"
  },
  "/_nuxt/CevX1Tat.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9e6-nhIEIH5KoZ2UqhJgrZGe1gHbQSo\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 2534,
    "path": "../public/_nuxt/CevX1Tat.js"
  },
  "/_nuxt/CfJYG6tj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"12c0-Zt2XLLQHY+NLRqqZjKAglrC3y9I\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 4800,
    "path": "../public/_nuxt/CfJYG6tj.js"
  },
  "/_nuxt/CgTVE_fC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5f-dMNz7iCd+HtyT8FaKNesYmxwDYU\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 95,
    "path": "../public/_nuxt/CgTVE_fC.js"
  },
  "/_nuxt/ChK-085T.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"360-Zw5nFUOUGoaKnMOBpZb/VdcEDmY\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 864,
    "path": "../public/_nuxt/ChK-085T.js"
  },
  "/_nuxt/CjFT_Tl9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a0b-TMrn13AvPZxLrJEXP5XkqBTemRE\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 2571,
    "path": "../public/_nuxt/CjFT_Tl9.js"
  },
  "/_nuxt/CjQqDB4T.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1720-JiGKqCR9r9oBSeZ5i3WilDPhSSo\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 5920,
    "path": "../public/_nuxt/CjQqDB4T.js"
  },
  "/_nuxt/Cip0qk2l.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"15445-8YYiPWOCGIdCO3I5DeuDs0ipTW8\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 87109,
    "path": "../public/_nuxt/Cip0qk2l.js"
  },
  "/_nuxt/Ck1zUtKM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"902-OnFiVodNmsLNuv5z7LQlgsFfjDs\"",
    "mtime": "2026-08-31T14:31:19.733Z",
    "size": 2306,
    "path": "../public/_nuxt/Ck1zUtKM.js"
  },
  "/_nuxt/CmGdzxic.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f40-vHhsqgEar8aB6YsABjjHbFIIs+0\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 3904,
    "path": "../public/_nuxt/CmGdzxic.js"
  },
  "/_nuxt/CnDTJFAw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1a91-XPwM9rQDJlXP3PcumIKVz+kLK8k\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 6801,
    "path": "../public/_nuxt/CnDTJFAw.js"
  },
  "/_nuxt/CnHTOXQT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7d7-elkNKybRkPVAu437KQ7GUMOTA+M\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 2007,
    "path": "../public/_nuxt/CnHTOXQT.js"
  },
  "/_nuxt/CnydiIhH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"70f-Aq2J5vHiDoeektgwv6r8EweXlBI\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 1807,
    "path": "../public/_nuxt/CnydiIhH.js"
  },
  "/_nuxt/CcB9pKbf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1151a8-sR3ANuS9KP7+Bx74+zxzDC+FBN0\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 1135016,
    "path": "../public/_nuxt/CcB9pKbf.js"
  },
  "/_nuxt/Cq3US-2P.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"64c-hZQZbbQ6YyBwoVbVwc/96yS8EEI\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 1612,
    "path": "../public/_nuxt/Cq3US-2P.js"
  },
  "/_nuxt/CqXBkRAD.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"69b8-Ra+HCEz2mAysT8k3xZQtythjME8\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 27064,
    "path": "../public/_nuxt/CqXBkRAD.js"
  },
  "/_nuxt/Cw1EW3IL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1046-49HTM0ZR3VJYGLxLTlkKYWjaotM\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 4166,
    "path": "../public/_nuxt/Cw1EW3IL.js"
  },
  "/_nuxt/CwgQXqLV.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a37-WVhtUl5KrFJreC8YtMx3er1RXqs\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 2615,
    "path": "../public/_nuxt/CwgQXqLV.js"
  },
  "/_nuxt/Czmdt5Fg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"eac-+oQmV91Hs7Do0J+IQ0AXGSd1hdo\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 3756,
    "path": "../public/_nuxt/Czmdt5Fg.js"
  },
  "/_nuxt/D0XecflT.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"90bc-OEu6xQNoDZ/2cvoiOJuMDJCw+NQ\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 37052,
    "path": "../public/_nuxt/D0XecflT.js"
  },
  "/_nuxt/D42f8D8i.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"93-BqZSWQNGM+XGh8rumxxGV90P7qA\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 147,
    "path": "../public/_nuxt/D42f8D8i.js"
  },
  "/_nuxt/D1SgWz6p.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"26cd3-HoEVsd2SmjumJkjaYb+fNK8Qq1Q\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 158931,
    "path": "../public/_nuxt/D1SgWz6p.js"
  },
  "/_nuxt/D6FW0B1r.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3f-QBSY1lPXbirKYATyRw0AIKu0ex4\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 63,
    "path": "../public/_nuxt/D6FW0B1r.js"
  },
  "/_nuxt/D8B20fx6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"a6f-m/nBGE855Ir4XymA1hp45GRfqDg\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 2671,
    "path": "../public/_nuxt/D8B20fx6.js"
  },
  "/_nuxt/D4F66V3E.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"17dd6-J4vwALMiHUNCb/zu5VBRNeyJ1k8\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 97750,
    "path": "../public/_nuxt/D4F66V3E.js"
  },
  "/_nuxt/D9Dt4D0W.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"102b-pzPFOaVufiyE1YwWZrBTrCmkhxE\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 4139,
    "path": "../public/_nuxt/D9Dt4D0W.js"
  },
  "/_nuxt/DBC5H0O8.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2cc5-2YTunyk/r1tow7FYeBn0Lw6XYxE\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 11461,
    "path": "../public/_nuxt/DBC5H0O8.js"
  },
  "/_nuxt/DBKNyK5s.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"913-JNIFxTycsFfR24dy75Mxh0lwBEc\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 2323,
    "path": "../public/_nuxt/DBKNyK5s.js"
  },
  "/_nuxt/DBlCnlav.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"350-W/j73uiF9oxpuOzp4/xe12/JXII\"",
    "mtime": "2026-08-31T14:31:19.734Z",
    "size": 848,
    "path": "../public/_nuxt/DBlCnlav.js"
  },
  "/_nuxt/DDnLBVmH.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"11488-ydEgDkRJw0GX1KJklNtxju4fBF8\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 70792,
    "path": "../public/_nuxt/DDnLBVmH.js"
  },
  "/_nuxt/DELagWij.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3f6c-7N/0ZqbiMqYbHiO2Mjz/cvqXn9c\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 16236,
    "path": "../public/_nuxt/DELagWij.js"
  },
  "/_nuxt/DF_7sFjM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"80b-0VuaWO4Z20J89uVLSegrylfzc6Q\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 2059,
    "path": "../public/_nuxt/DF_7sFjM.js"
  },
  "/_nuxt/DGYXhP31.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"cb1-CBxGs3g6yI/Til8lz0MQ8B7+LsY\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 3249,
    "path": "../public/_nuxt/DGYXhP31.js"
  },
  "/_nuxt/DMA9R1ak.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9ef-cuCZFM83+8nE1R+YxFnJWw7osAA\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 2543,
    "path": "../public/_nuxt/DMA9R1ak.js"
  },
  "/_nuxt/DO-Gjzrf.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"add-eF0z+5+hZFYkWOPVFXELE2MDM80\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 2781,
    "path": "../public/_nuxt/DO-Gjzrf.js"
  },
  "/_nuxt/DQJEBXf9.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7838-i8V8FHrepinZ5zL9jO7apXMKVRk\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 30776,
    "path": "../public/_nuxt/DQJEBXf9.js"
  },
  "/_nuxt/DSJnyJyo.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"966-Zf4PqPMx7jCdEV8NkI3mLTLuxq0\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 2406,
    "path": "../public/_nuxt/DSJnyJyo.js"
  },
  "/_nuxt/DDzY8omC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d4cd6-7K08J7AnKECODpTBTqfhH7KvJak\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 871638,
    "path": "../public/_nuxt/DDzY8omC.js"
  },
  "/_nuxt/DTrFuWx2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"77c-KDyCLr975q/BsxuznEF2gewyX98\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 1916,
    "path": "../public/_nuxt/DTrFuWx2.js"
  },
  "/_nuxt/DVfN8rqt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"934-CGECd1FAu+HyHd7f4ALcSct3NSw\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 2356,
    "path": "../public/_nuxt/DVfN8rqt.js"
  },
  "/_nuxt/DVfSvwGj.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1145-7HttrqQV6efS/qAgLKvNtezk8Fc\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 4421,
    "path": "../public/_nuxt/DVfSvwGj.js"
  },
  "/_nuxt/DYr57U_2.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1d0-D2FtowqCrQfsSRvwpq4rdSrlArI\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 464,
    "path": "../public/_nuxt/DYr57U_2.js"
  },
  "/_nuxt/DYz_wnZ1.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"122c-HFpuJCvimy2mde2Vpdg6lComrks\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 4652,
    "path": "../public/_nuxt/DYz_wnZ1.js"
  },
  "/_nuxt/DXEQVQnt.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"31151-TyUyRNm9rR2JDwpyAxcruTmmr6A\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 201041,
    "path": "../public/_nuxt/DXEQVQnt.js"
  },
  "/_nuxt/DZPZEOli.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1a07-XAnlBsXh3CqPnwx+4OiqczddAwo\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 6663,
    "path": "../public/_nuxt/DZPZEOli.js"
  },
  "/_nuxt/DZkJ_74n.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1cf5-yveLZzbjWMXG/3d8/MFCP8yL5XE\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 7413,
    "path": "../public/_nuxt/DZkJ_74n.js"
  },
  "/_nuxt/D_9xzGlC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"2195-obci+2i4Y1kwobWJg6B5oG2o/hk\"",
    "mtime": "2026-08-31T14:31:19.735Z",
    "size": 8597,
    "path": "../public/_nuxt/D_9xzGlC.js"
  },
  "/_nuxt/D_TM09nn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"12f8-4GCHCI+pLvOc7x+QNr7djcj7Qmg\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 4856,
    "path": "../public/_nuxt/D_TM09nn.js"
  },
  "/_nuxt/DbItnlRl.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"135-iKoNteNzucuZpKMc/f8fhN9OpPU\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 309,
    "path": "../public/_nuxt/DbItnlRl.js"
  },
  "/_nuxt/Dc1JOy9r.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"ae4-NUU0j+JASz1UDU4xXNM46TogNRE\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 2788,
    "path": "../public/_nuxt/Dc1JOy9r.js"
  },
  "/_nuxt/DdIZxoE0.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1cad-Ag5o9p4F/Djr8tWoCEUn/sAmGPM\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 7341,
    "path": "../public/_nuxt/DdIZxoE0.js"
  },
  "/_nuxt/DehyRSwq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"362-O3fim2FTRqQbD5Nike7nHACpoEk\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 866,
    "path": "../public/_nuxt/DehyRSwq.js"
  },
  "/_nuxt/Df11BRmG.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"312-zgv63uF9+m69mVQpB/3X2oZack4\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 786,
    "path": "../public/_nuxt/Df11BRmG.js"
  },
  "/_nuxt/DkYu6x3z.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"dd9-3MUWvjAjkneJnafow3LlXxEOwhI\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 3545,
    "path": "../public/_nuxt/DkYu6x3z.js"
  },
  "/_nuxt/DuDQsnwc.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3195-dOV0jBW6bL6gaG9x568vwGky/gI\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 12693,
    "path": "../public/_nuxt/DuDQsnwc.js"
  },
  "/_nuxt/DuME0IfC.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1509-x4Zh2hxD4bhUJ1ND15203y+4fTY\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 5385,
    "path": "../public/_nuxt/DuME0IfC.js"
  },
  "/_nuxt/DwRh75JA.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"fd3-Ch05H7ujPtjXf7WNKuZyroZASm4\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 4051,
    "path": "../public/_nuxt/DwRh75JA.js"
  },
  "/_nuxt/DwpmLMds.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1a2-IBmoz3ZJjbHD/w4RnbJmskQ+bCw\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 418,
    "path": "../public/_nuxt/DwpmLMds.js"
  },
  "/_nuxt/Dyk9ri8O.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"7e-ngo5IQjGc7zZ7dLnY47eHOQEEPY\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 126,
    "path": "../public/_nuxt/Dyk9ri8O.js"
  },
  "/_nuxt/Df2ujMI4.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"5e6d0-xw9lIOR0gKaq/TMf9DmWOArFDe0\"",
    "mtime": "2026-08-31T14:31:19.736Z",
    "size": 386768,
    "path": "../public/_nuxt/Df2ujMI4.js"
  },
  "/_nuxt/DzFWVndE.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"19e0-r3rS68onllqLKva+U5pHUAGEs1g\"",
    "mtime": "2026-08-31T14:31:19.737Z",
    "size": 6624,
    "path": "../public/_nuxt/DzFWVndE.js"
  },
  "/_nuxt/EdZsLKOL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f8d-v13dPajnH2aGZoNyzQWo3bhJHpw\"",
    "mtime": "2026-08-31T14:31:19.737Z",
    "size": 3981,
    "path": "../public/_nuxt/EdZsLKOL.js"
  },
  "/_nuxt/Ffai-XNe.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9f0-Z5RFrlG+6Q0NSJKuIxBBS9NHTTs\"",
    "mtime": "2026-08-31T14:31:19.737Z",
    "size": 2544,
    "path": "../public/_nuxt/Ffai-XNe.js"
  },
  "/_nuxt/FjPdJcy_.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8f23-CdEcwSq0KG8XThgrN7hEGHe0pWI\"",
    "mtime": "2026-08-31T14:31:19.737Z",
    "size": 36643,
    "path": "../public/_nuxt/FjPdJcy_.js"
  },
  "/_nuxt/GW_nhZxv.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8e5-Qnam6yHPVXhuyPtogPeG28t+2XA\"",
    "mtime": "2026-08-31T14:31:19.737Z",
    "size": 2277,
    "path": "../public/_nuxt/GW_nhZxv.js"
  },
  "/_nuxt/H-WmDvRZ.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1ed5-7TkdHIj3N3n0ZQdhXr2eQNeFOv4\"",
    "mtime": "2026-08-31T14:31:19.737Z",
    "size": 7893,
    "path": "../public/_nuxt/H-WmDvRZ.js"
  },
  "/_nuxt/Hz9HOZM7.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"6d7-C5cQ6t4wd3M3XSWve4Yg0xvd/w8\"",
    "mtime": "2026-08-31T14:31:19.737Z",
    "size": 1751,
    "path": "../public/_nuxt/Hz9HOZM7.js"
  },
  "/_nuxt/KVbaHTHw.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"cd0b-0xoaYK5UGElO4I+OFz/ovJCmweU\"",
    "mtime": "2026-08-31T14:31:19.737Z",
    "size": 52491,
    "path": "../public/_nuxt/KVbaHTHw.js"
  },
  "/_nuxt/Kk6Joddg.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"59c5-Kfkpm91Nq1+VHVrIj09lb1Bu7y8\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 22981,
    "path": "../public/_nuxt/Kk6Joddg.js"
  },
  "/_nuxt/Kvtd6kyn.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"81b-En9t/MZ9xb1v1U0h4wrBF3fb/OM\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 2075,
    "path": "../public/_nuxt/Kvtd6kyn.js"
  },
  "/_nuxt/Q1N35T77.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"93-tE4+oE/XwEVdjwXfAgM2HQ4knqM\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 147,
    "path": "../public/_nuxt/Q1N35T77.js"
  },
  "/_nuxt/S37ZYGWr.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"f1c-C79rmrw8Aapy/dpLhOPAtBEAOjo\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 3868,
    "path": "../public/_nuxt/S37ZYGWr.js"
  },
  "/_nuxt/SWqX1oyp.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"72a-a6HZkg7C9EMs7wmFBq6pE7HAtog\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 1834,
    "path": "../public/_nuxt/SWqX1oyp.js"
  },
  "/_nuxt/SjHAIU92.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"140a-oa2TteYUwUMj6+FSzKnUqbQNxfc\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 5130,
    "path": "../public/_nuxt/SjHAIU92.js"
  },
  "/_nuxt/VAEuO923.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d4f-57wY6zHq/ri5PbPZujw/6JQF340\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 3407,
    "path": "../public/_nuxt/VAEuO923.js"
  },
  "/_nuxt/XRfBkHHb.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1267-KtDgTkTH6ZW93Ca+H7KW59d304Y\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 4711,
    "path": "../public/_nuxt/XRfBkHHb.js"
  },
  "/_nuxt/XjSziqeq.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"27f5-k0LNcMM+jHH8Uk9Lue/8DZu5WBs\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 10229,
    "path": "../public/_nuxt/XjSziqeq.js"
  },
  "/_nuxt/ZXfAyPTL.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9d5-e97eMejt72jA1LVSCEz2L9N/0jA\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 2517,
    "path": "../public/_nuxt/ZXfAyPTL.js"
  },
  "/_nuxt/ZyLRZF0J.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"162b-JZA7kCMj6PU0eptf6sHZXWYNvRI\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 5675,
    "path": "../public/_nuxt/ZyLRZF0J.js"
  },
  "/_nuxt/about.CnApxnON.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"8ad-5558HhEKDuTRRajXE/1nBZGv+EI\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 2221,
    "path": "../public/_nuxt/about.CnApxnON.css"
  },
  "/_nuxt/all.CyAiAzLY.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7fe-Tcg91dvQEiy9RFY3OF5dHq34aV4\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 2046,
    "path": "../public/_nuxt/all.CyAiAzLY.css"
  },
  "/_nuxt/article.BlLljn9d.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"40d9-qt8+wMf0EB1W82Dk+wfGc7qBQr8\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 16601,
    "path": "../public/_nuxt/article.BlLljn9d.css"
  },
  "/_nuxt/articlelist.CfOzAPry.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"dd3-694MRQYFz1DSetNbumkOP6hn+fI\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 3539,
    "path": "../public/_nuxt/articlelist.CfOzAPry.css"
  },
  "/_nuxt/article.DxPExFrl.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"11a75-PNs25hg/YtqzbqAeo/iMKg4wnWE\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 72309,
    "path": "../public/_nuxt/article.DxPExFrl.css"
  },
  "/_nuxt/category.Bzxsuu5b.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"480-XUvq6I4pNGurZ375cS6s27Vdhkk\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 1152,
    "path": "../public/_nuxt/category.Bzxsuu5b.css"
  },
  "/_nuxt/category.GODY4EmH.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7fe-PRLio4aadnjbcfn+vhpO4aMPGWA\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 2046,
    "path": "../public/_nuxt/category.GODY4EmH.css"
  },
  "/_nuxt/comment.B2GjAOFj.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"47c-kOaFHq5fG3TsZVltzb28vzXAV84\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 1148,
    "path": "../public/_nuxt/comment.B2GjAOFj.css"
  },
  "/_nuxt/default.CIwO_8bk.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3968-/z9NdpKFiGbDABhAHtBajqw0ayc\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 14696,
    "path": "../public/_nuxt/default.CIwO_8bk.css"
  },
  "/_nuxt/echart.DajLY8xx.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"9691-buYbw8Br6YBPhAeFUNwDW9BxkHQ\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 38545,
    "path": "../public/_nuxt/echart.DajLY8xx.css"
  },
  "/_nuxt/el-dialog.BK1BAsUO.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"dcb-a7wD29CeCFCHbUJx7kF9PN9/XeM\"",
    "mtime": "2026-08-31T14:31:19.738Z",
    "size": 3531,
    "path": "../public/_nuxt/el-dialog.BK1BAsUO.css"
  },
  "/_nuxt/el-dropdown.Bl5_6jYo.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2737-bsy+dHZ5hqbDFTLIXKCBvQWT7rI\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 10039,
    "path": "../public/_nuxt/el-dropdown.Bl5_6jYo.css"
  },
  "/_nuxt/el-empty.S7fQQ3B8.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"484-biZi75T9/gHEGxHod8br9jw0krA\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 1156,
    "path": "../public/_nuxt/el-empty.S7fQQ3B8.css"
  },
  "/_nuxt/el-form.C-I2nTSJ.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"15aa-nuOpS+rqA9KQ+9/5b7JTTABb938\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 5546,
    "path": "../public/_nuxt/el-form.C-I2nTSJ.css"
  },
  "/_nuxt/el-loading.Bm9hfvJ7.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"637-42NjgRpaaWx4bPpI99RD1OwS1yA\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 1591,
    "path": "../public/_nuxt/el-loading.Bm9hfvJ7.css"
  },
  "/_nuxt/el-message.CtZgN7aL.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1412-6a/Fv+AaIyaMHuXg8qVBIc5wWes\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 5138,
    "path": "../public/_nuxt/el-message.CtZgN7aL.css"
  },
  "/_nuxt/el-pagination.uZhvKMkb.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1aa3-vZbAbPWHguHLR2jCS2xgtKWEPCo\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 6819,
    "path": "../public/_nuxt/el-pagination.uZhvKMkb.css"
  },
  "/_nuxt/el-popper.CCaty0DZ.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"e93-Spp2gAyPVRtW4Xx1zRfwLCQqdEs\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 3731,
    "path": "../public/_nuxt/el-popper.CCaty0DZ.css"
  },
  "/_nuxt/el-radio-group.CPrAtVWW.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1121-xidcAXFbXjUHuM7ICx5nqrYurjQ\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 4385,
    "path": "../public/_nuxt/el-radio-group.CPrAtVWW.css"
  },
  "/_nuxt/el-select.BDkEkPqz.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"22ff-C4bHH6Z04wEZ36oxVhlrlJN+KJg\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 8959,
    "path": "../public/_nuxt/el-select.BDkEkPqz.css"
  },
  "/_nuxt/el-table.BCOes9sS.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"6435-mK0UmiXmK44e6X4bO9YC2d0DOnU\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 25653,
    "path": "../public/_nuxt/el-table.BCOes9sS.css"
  },
  "/_nuxt/el-tag.ltYZTxs4.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"167a-rUhMnio4QdbgLe48fYpM0WZQ0nM\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 5754,
    "path": "../public/_nuxt/el-tag.ltYZTxs4.css"
  },
  "/_nuxt/el-tooltip.tn0RQdqM.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"0-2jmj7l5rSw0yVb/vlWAYkK/YBwk\"",
    "mtime": "2026-08-31T14:31:15.429Z",
    "size": 0,
    "path": "../public/_nuxt/el-tooltip.tn0RQdqM.css"
  },
  "/_nuxt/el-upload.CB28aMHZ.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"3817-7FEeaIrfRncVfPk/ohJAVR0Dt0I\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 14359,
    "path": "../public/_nuxt/el-upload.CB28aMHZ.css"
  },
  "/_nuxt/fCUp34qd.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"791-gn8j6SReDoPz3O3kGoLegFp0TJM\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 1937,
    "path": "../public/_nuxt/fCUp34qd.js"
  },
  "/_nuxt/entry.Cq3Xw_5V.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"d67d-XC/trUgStq8NTfF8pmLWAl5nx5c\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 54909,
    "path": "../public/_nuxt/entry.Cq3Xw_5V.css"
  },
  "/_nuxt/front.5IPi02ST.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2277-9EJbxNVEbL9HL039NGOVtf0u94c\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 8823,
    "path": "../public/_nuxt/front.5IPi02ST.css"
  },
  "/_nuxt/heZmZLOM.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"27af-TlRoCc6JmX5to1abwsqDWHNfS6c\"",
    "mtime": "2026-08-31T14:31:19.739Z",
    "size": 10159,
    "path": "../public/_nuxt/heZmZLOM.js"
  },
  "/_nuxt/iXu5QeM3.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"42ba-Jrkh6yB+gxsGW73sfx1X+OVjiRs\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 17082,
    "path": "../public/_nuxt/iXu5QeM3.js"
  },
  "/_nuxt/index.DXWyCWV4.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2482-AtD7Ywah0470aywYbm6guQYF0kM\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 9346,
    "path": "../public/_nuxt/index.DXWyCWV4.css"
  },
  "/_nuxt/index.DoJ6UWuy.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2d8d-HvgnYfe9o/RxqnNqoR8lQYg/9u0\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 11661,
    "path": "../public/_nuxt/index.DoJ6UWuy.css"
  },
  "/_nuxt/k-DjscdI.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"8ec-/kjatvbufqjwNbYJJ2GU9FfjwBs\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 2284,
    "path": "../public/_nuxt/k-DjscdI.js"
  },
  "/_nuxt/lSbBsy5d.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"d14-gX6Arn5K0XGgU1+DzMtMeeJRUug\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 3348,
    "path": "../public/_nuxt/lSbBsy5d.js"
  },
  "/_nuxt/login.C7_IgsUJ.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"2347-qCr6TxNJ8QGZWGT77RAiZA4HTWM\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 9031,
    "path": "../public/_nuxt/login.C7_IgsUJ.css"
  },
  "/_nuxt/logo.Ca7hAnb0.png": {
    "type": "image/png",
    "etag": "\"544c-v6jkaebDi2XMpcBsGsD9YsWR7E8\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 21580,
    "path": "../public/_nuxt/logo.Ca7hAnb0.png"
  },
  "/_nuxt/pRatUO7H.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"e87-4Sd67z21b858eZdNPWOSWUCsbOg\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 3719,
    "path": "../public/_nuxt/pRatUO7H.js"
  },
  "/_nuxt/pXgVlZs6.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"fc0-+tnnu3Zv5w173x5s+tHiksk7xHM\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 4032,
    "path": "../public/_nuxt/pXgVlZs6.js"
  },
  "/_nuxt/profile.DI_veEGu.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"94c-5U1M4wQ77fG3Nf1Bji1D0Kj51iU\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 2380,
    "path": "../public/_nuxt/profile.DI_veEGu.css"
  },
  "/_nuxt/roles.Cb3hgJRi.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"1b96-qSbIvLkaErtBM3RE7/8AsG8pKa0\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 7062,
    "path": "../public/_nuxt/roles.Cb3hgJRi.css"
  },
  "/_nuxt/system.NL8o4Bwh.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"159a-pd/vtEra7Rny4Y/ZAPTsaIr2S/w\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 5530,
    "path": "../public/_nuxt/system.NL8o4Bwh.css"
  },
  "/_nuxt/tag.C_HJAQLR.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"47b-mPcbdWTeCjAHqkRaxK8Awl/fGWc\"",
    "mtime": "2026-08-31T14:31:19.741Z",
    "size": 1147,
    "path": "../public/_nuxt/tag.C_HJAQLR.css"
  },
  "/_nuxt/prwMihry.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"1449-HrslAWwlp6rviOoFTExaDlgQ5s8\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 5193,
    "path": "../public/_nuxt/prwMihry.js"
  },
  "/_nuxt/timeline.B_xMWK3Y.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"7a6-Hj4wmf64MqXIIeHF5urrbtlKCSY\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 1958,
    "path": "../public/_nuxt/timeline.B_xMWK3Y.css"
  },
  "/_nuxt/rNdr6OdY.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"29a-f6gvJCv6WOhEX9OiHjJu1mnTMhM\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 666,
    "path": "../public/_nuxt/rNdr6OdY.js"
  },
  "/_nuxt/users.CSpo-TQW.css": {
    "type": "text/css; charset=utf-8",
    "etag": "\"47c-c2ZHlLmC36penmekkEBf/RzKZVw\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 1148,
    "path": "../public/_nuxt/users.CSpo-TQW.css"
  },
  "/_nuxt/vLlmbW-K.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"763-SFLhT0nMq4hoOD1+xUM3co7G+S4\"",
    "mtime": "2026-08-31T14:31:19.740Z",
    "size": 1891,
    "path": "../public/_nuxt/vLlmbW-K.js"
  },
  "/_nuxt/wAsdV37c.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"3c0-mUkUiEGUVGGeaORIpPc4OFyPTL0\"",
    "mtime": "2026-08-31T14:31:19.741Z",
    "size": 960,
    "path": "../public/_nuxt/wAsdV37c.js"
  },
  "/_nuxt/builds/latest.json": {
    "type": "application/json",
    "etag": "\"47-sd0KBdSAoo0rYUchbqR4xfHSPqs\"",
    "mtime": "2026-08-31T14:31:19.711Z",
    "size": 71,
    "path": "../public/_nuxt/builds/latest.json"
  },
  "/_nuxt/uYRFUcGN.js": {
    "type": "text/javascript; charset=utf-8",
    "etag": "\"9f0b-RGGQAIPUkR0P0IYF/je835h+K2g\"",
    "mtime": "2026-08-31T14:31:19.741Z",
    "size": 40715,
    "path": "../public/_nuxt/uYRFUcGN.js"
  },
  "/_nuxt/builds/meta/641000f4-43e8-415e-ba78-b1197918ab90.json": {
    "type": "application/json",
    "etag": "\"58-9Es9nN3aCbc8Iaav2BcFXgADGgs\"",
    "mtime": "2026-08-31T14:31:19.708Z",
    "size": 88,
    "path": "../public/_nuxt/builds/meta/641000f4-43e8-415e-ba78-b1197918ab90.json"
  },
  "/_nuxt/zsm.C6bSKg11.jpg": {
    "type": "image/jpeg",
    "etag": "\"13581-KvM1K38tseLVNcpQ9Odo90Ry7Ws\"",
    "mtime": "2026-08-31T14:31:19.741Z",
    "size": 79233,
    "path": "../public/_nuxt/zsm.C6bSKg11.jpg"
  },
  "/_nuxt/background.Bc447oNk.png": {
    "type": "image/png",
    "etag": "\"55c2ac-S5Llut7NqaShMq6bt96yk2sCdSE\"",
    "mtime": "2026-08-31T14:31:19.744Z",
    "size": 5620396,
    "path": "../public/_nuxt/background.Bc447oNk.png"
  }
};

const _DRIVE_LETTER_START_RE = /^[A-Za-z]:\//;
function normalizeWindowsPath(input = "") {
  if (!input) {
    return input;
  }
  return input.replace(/\\/g, "/").replace(_DRIVE_LETTER_START_RE, (r) => r.toUpperCase());
}
const _IS_ABSOLUTE_RE = /^[/\\](?![/\\])|^[/\\]{2}(?!\.)|^[A-Za-z]:[/\\]/;
const _DRIVE_LETTER_RE = /^[A-Za-z]:$/;
function cwd() {
  if (typeof process !== "undefined" && typeof process.cwd === "function") {
    return process.cwd().replace(/\\/g, "/");
  }
  return "/";
}
const resolve = function(...arguments_) {
  arguments_ = arguments_.map((argument) => normalizeWindowsPath(argument));
  let resolvedPath = "";
  let resolvedAbsolute = false;
  for (let index = arguments_.length - 1; index >= -1 && !resolvedAbsolute; index--) {
    const path = index >= 0 ? arguments_[index] : cwd();
    if (!path || path.length === 0) {
      continue;
    }
    resolvedPath = `${path}/${resolvedPath}`;
    resolvedAbsolute = isAbsolute(path);
  }
  resolvedPath = normalizeString(resolvedPath, !resolvedAbsolute);
  if (resolvedAbsolute && !isAbsolute(resolvedPath)) {
    return `/${resolvedPath}`;
  }
  return resolvedPath.length > 0 ? resolvedPath : ".";
};
function normalizeString(path, allowAboveRoot) {
  let res = "";
  let lastSegmentLength = 0;
  let lastSlash = -1;
  let dots = 0;
  let char = null;
  for (let index = 0; index <= path.length; ++index) {
    if (index < path.length) {
      char = path[index];
    } else if (char === "/") {
      break;
    } else {
      char = "/";
    }
    if (char === "/") {
      if (lastSlash === index - 1 || dots === 1) ; else if (dots === 2) {
        if (res.length < 2 || lastSegmentLength !== 2 || res[res.length - 1] !== "." || res[res.length - 2] !== ".") {
          if (res.length > 2) {
            const lastSlashIndex = res.lastIndexOf("/");
            if (lastSlashIndex === -1) {
              res = "";
              lastSegmentLength = 0;
            } else {
              res = res.slice(0, lastSlashIndex);
              lastSegmentLength = res.length - 1 - res.lastIndexOf("/");
            }
            lastSlash = index;
            dots = 0;
            continue;
          } else if (res.length > 0) {
            res = "";
            lastSegmentLength = 0;
            lastSlash = index;
            dots = 0;
            continue;
          }
        }
        if (allowAboveRoot) {
          res += res.length > 0 ? "/.." : "..";
          lastSegmentLength = 2;
        }
      } else {
        if (res.length > 0) {
          res += `/${path.slice(lastSlash + 1, index)}`;
        } else {
          res = path.slice(lastSlash + 1, index);
        }
        lastSegmentLength = index - lastSlash - 1;
      }
      lastSlash = index;
      dots = 0;
    } else if (char === "." && dots !== -1) {
      ++dots;
    } else {
      dots = -1;
    }
  }
  return res;
}
const isAbsolute = function(p) {
  return _IS_ABSOLUTE_RE.test(p);
};
const dirname = function(p) {
  const segments = normalizeWindowsPath(p).replace(/\/$/, "").split("/").slice(0, -1);
  if (segments.length === 1 && _DRIVE_LETTER_RE.test(segments[0])) {
    segments[0] += "/";
  }
  return segments.join("/") || (isAbsolute(p) ? "/" : ".");
};

function readAsset (id) {
  const serverDir = dirname(fileURLToPath(globalThis._importMeta_.url));
  return promises.readFile(resolve(serverDir, assets[id].path))
}

const publicAssetBases = {"/_nuxt/builds/meta/":{"maxAge":31536000},"/_nuxt/builds/":{"maxAge":1},"/_nuxt/":{"maxAge":31536000}};

function isPublicAssetURL(id = '') {
  if (assets[id]) {
    return true
  }
  for (const base in publicAssetBases) {
    if (id.startsWith(base)) { return true }
  }
  return false
}

function getAsset (id) {
  return assets[id]
}

const METHODS = /* @__PURE__ */ new Set(["HEAD", "GET"]);
const EncodingMap = { gzip: ".gz", br: ".br" };
const _OTLKnA = eventHandler((event) => {
  if (event.method && !METHODS.has(event.method)) {
    return;
  }
  let id = decodePath(
    withLeadingSlash(withoutTrailingSlash(parseURL(event.path).pathname))
  );
  let asset;
  const encodingHeader = String(
    getRequestHeader(event, "accept-encoding") || ""
  );
  const encodings = [
    ...encodingHeader.split(",").map((e) => EncodingMap[e.trim()]).filter(Boolean).sort(),
    ""
  ];
  for (const encoding of encodings) {
    for (const _id of [id + encoding, joinURL(id, "index.html" + encoding)]) {
      const _asset = getAsset(_id);
      if (_asset) {
        asset = _asset;
        id = _id;
        break;
      }
    }
  }
  if (!asset) {
    if (isPublicAssetURL(id)) {
      removeResponseHeader(event, "Cache-Control");
      throw createError$1({ statusCode: 404 });
    }
    return;
  }
  if (asset.encoding !== void 0) {
    appendResponseHeader(event, "Vary", "Accept-Encoding");
  }
  const ifNotMatch = getRequestHeader(event, "if-none-match") === asset.etag;
  if (ifNotMatch) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  const ifModifiedSinceH = getRequestHeader(event, "if-modified-since");
  const mtimeDate = new Date(asset.mtime);
  if (ifModifiedSinceH && asset.mtime && new Date(ifModifiedSinceH) >= mtimeDate) {
    setResponseStatus(event, 304, "Not Modified");
    return "";
  }
  if (asset.type && !getResponseHeader(event, "Content-Type")) {
    setResponseHeader(event, "Content-Type", asset.type);
  }
  if (asset.etag && !getResponseHeader(event, "ETag")) {
    setResponseHeader(event, "ETag", asset.etag);
  }
  if (asset.mtime && !getResponseHeader(event, "Last-Modified")) {
    setResponseHeader(event, "Last-Modified", mtimeDate.toUTCString());
  }
  if (asset.encoding && !getResponseHeader(event, "Content-Encoding")) {
    setResponseHeader(event, "Content-Encoding", asset.encoding);
  }
  if (asset.size > 0 && !getResponseHeader(event, "Content-Length")) {
    setResponseHeader(event, "Content-Length", asset.size);
  }
  return readAsset(id);
});

const _SxA8c9 = defineEventHandler(() => {});

const _lazy_3qsxBY = () => import('../routes/robots.txt.mjs');
const _lazy_o67QAm = () => import('../routes/rss.xml.mjs');
const _lazy_28PfvD = () => import('../routes/sitemap.xml.mjs');
const _lazy_KnuvoG = () => import('../routes/renderer.mjs').then(function (n) { return n.r; });

const handlers = [
  { route: '', handler: _OTLKnA, lazy: false, middleware: true, method: undefined },
  { route: '/robots.txt', handler: _lazy_3qsxBY, lazy: true, middleware: false, method: undefined },
  { route: '/rss.xml', handler: _lazy_o67QAm, lazy: true, middleware: false, method: undefined },
  { route: '/sitemap.xml', handler: _lazy_28PfvD, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_error', handler: _lazy_KnuvoG, lazy: true, middleware: false, method: undefined },
  { route: '/__nuxt_island/**', handler: _SxA8c9, lazy: false, middleware: false, method: undefined },
  { route: '/**', handler: _lazy_KnuvoG, lazy: true, middleware: false, method: undefined }
];

function createNitroApp() {
  const config = useRuntimeConfig();
  const hooks = createHooks();
  const captureError = (error, context = {}) => {
    const promise = hooks.callHookParallel("error", error, context).catch((error_) => {
      console.error("Error while capturing another error", error_);
    });
    if (context.event && isEvent(context.event)) {
      const errors = context.event.context.nitro?.errors;
      if (errors) {
        errors.push({ error, context });
      }
      if (context.event.waitUntil) {
        context.event.waitUntil(promise);
      }
    }
  };
  const h3App = createApp({
    debug: destr(false),
    onError: (error, event) => {
      captureError(error, { event, tags: ["request"] });
      return errorHandler(error, event);
    },
    onRequest: async (event) => {
      event.context.nitro = event.context.nitro || { errors: [] };
      const fetchContext = event.node.req?.__unenv__;
      if (fetchContext?._platform) {
        event.context = {
          _platform: fetchContext?._platform,
          // #3335
          ...fetchContext._platform,
          ...event.context
        };
      }
      if (!event.context.waitUntil && fetchContext?.waitUntil) {
        event.context.waitUntil = fetchContext.waitUntil;
      }
      event.fetch = (req, init) => fetchWithEvent(event, req, init, { fetch: localFetch });
      event.$fetch = (req, init) => fetchWithEvent(event, req, init, {
        fetch: $fetch
      });
      event.waitUntil = (promise) => {
        if (!event.context.nitro._waitUntilPromises) {
          event.context.nitro._waitUntilPromises = [];
        }
        event.context.nitro._waitUntilPromises.push(promise);
        if (event.context.waitUntil) {
          event.context.waitUntil(promise);
        }
      };
      event.captureError = (error, context) => {
        captureError(error, { event, ...context });
      };
      await nitroApp$1.hooks.callHook("request", event).catch((error) => {
        captureError(error, { event, tags: ["request"] });
      });
    },
    onBeforeResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("beforeResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    },
    onAfterResponse: async (event, response) => {
      await nitroApp$1.hooks.callHook("afterResponse", event, response).catch((error) => {
        captureError(error, { event, tags: ["request", "response"] });
      });
    }
  });
  const router = createRouter({
    preemptive: true
  });
  const nodeHandler = toNodeListener(h3App);
  const localCall = (aRequest) => b(
    nodeHandler,
    aRequest
  );
  const localFetch = (input, init) => {
    if (!input.toString().startsWith("/")) {
      return globalThis.fetch(input, init);
    }
    return C(
      nodeHandler,
      input,
      init
    ).then((response) => normalizeFetchResponse(response));
  };
  const $fetch = createFetch({
    fetch: localFetch,
    Headers: Headers$1,
    defaults: { baseURL: config.app.baseURL }
  });
  globalThis.$fetch = $fetch;
  h3App.use(createRouteRulesHandler({ localFetch }));
  for (const h of handlers) {
    let handler = h.lazy ? lazyEventHandler(h.handler) : h.handler;
    if (h.middleware || !h.route) {
      const middlewareBase = (config.app.baseURL + (h.route || "/")).replace(
        /\/+/g,
        "/"
      );
      h3App.use(middlewareBase, handler);
    } else {
      const routeRules = getRouteRulesForPath(
        h.route.replace(/:\w+|\*\*/g, "_")
      );
      if (routeRules.cache) {
        handler = cachedEventHandler(handler, {
          group: "nitro/routes",
          ...routeRules.cache
        });
      }
      router.use(h.route, handler, h.method);
    }
  }
  h3App.use(config.app.baseURL, router.handler);
  const app = {
    hooks,
    h3App,
    router,
    localCall,
    localFetch,
    captureError
  };
  return app;
}
function runNitroPlugins(nitroApp2) {
  for (const plugin of plugins) {
    try {
      plugin(nitroApp2);
    } catch (error) {
      nitroApp2.captureError(error, { tags: ["plugin"] });
      throw error;
    }
  }
}
const nitroApp$1 = createNitroApp();
function useNitroApp() {
  return nitroApp$1;
}
runNitroPlugins(nitroApp$1);

function defineRenderHandler(render) {
  const runtimeConfig = useRuntimeConfig();
  return eventHandler(async (event) => {
    const nitroApp = useNitroApp();
    const ctx = { event, render, response: void 0 };
    await nitroApp.hooks.callHook("render:before", ctx);
    if (!ctx.response) {
      if (event.path === `${runtimeConfig.app.baseURL}favicon.ico`) {
        setResponseHeader(event, "Content-Type", "image/x-icon");
        return send(
          event,
          "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7"
        );
      }
      ctx.response = await ctx.render(event);
      if (!ctx.response) {
        const _currentStatus = getResponseStatus(event);
        setResponseStatus(event, _currentStatus === 200 ? 500 : _currentStatus);
        return send(
          event,
          "No response returned from render handler: " + event.path
        );
      }
    }
    await nitroApp.hooks.callHook("render:response", ctx.response, ctx);
    if (ctx.response.headers) {
      setResponseHeaders(event, ctx.response.headers);
    }
    if (ctx.response.statusCode || ctx.response.statusMessage) {
      setResponseStatus(
        event,
        ctx.response.statusCode,
        ctx.response.statusMessage
      );
    }
    return ctx.response.body;
  });
}

const debug = (...args) => {
};
function GracefulShutdown(server, opts) {
  opts = opts || {};
  const options = Object.assign(
    {
      signals: "SIGINT SIGTERM",
      timeout: 3e4,
      development: false,
      forceExit: true,
      onShutdown: (signal) => Promise.resolve(signal),
      preShutdown: (signal) => Promise.resolve(signal)
    },
    opts
  );
  let isShuttingDown = false;
  const connections = {};
  let connectionCounter = 0;
  const secureConnections = {};
  let secureConnectionCounter = 0;
  let failed = false;
  let finalRun = false;
  function onceFactory() {
    let called = false;
    return (emitter, events, callback) => {
      function call() {
        if (!called) {
          called = true;
          return Reflect.apply(callback, this, arguments);
        }
      }
      for (const e of events) {
        emitter.on(e, call);
      }
    };
  }
  const signals = options.signals.split(" ").map((s) => s.trim()).filter((s) => s.length > 0);
  const once = onceFactory();
  once(process, signals, (signal) => {
    debug("received shut down signal", signal);
    shutdown(signal).then(() => {
      if (options.forceExit) {
        process.exit(failed ? 1 : 0);
      }
    }).catch((error) => {
      debug("server shut down error occurred", error);
      process.exit(1);
    });
  });
  function isFunction(functionToCheck) {
    const getType = Object.prototype.toString.call(functionToCheck);
    return /^\[object\s([A-Za-z]+)?Function]$/.test(getType);
  }
  function destroy(socket, force = false) {
    if (socket._isIdle && isShuttingDown || force) {
      socket.destroy();
      if (socket.server instanceof http.Server) {
        delete connections[socket._connectionId];
      } else {
        delete secureConnections[socket._connectionId];
      }
    }
  }
  function destroyAllConnections(force = false) {
    debug("Destroy Connections : " + (force ? "forced close" : "close"));
    let counter = 0;
    let secureCounter = 0;
    for (const key of Object.keys(connections)) {
      const socket = connections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        counter++;
        destroy(socket);
      }
    }
    debug("Connections destroyed : " + counter);
    debug("Connection Counter    : " + connectionCounter);
    for (const key of Object.keys(secureConnections)) {
      const socket = secureConnections[key];
      const serverResponse = socket._httpMessage;
      if (serverResponse && !force) {
        if (!serverResponse.headersSent) {
          serverResponse.setHeader("connection", "close");
        }
      } else {
        secureCounter++;
        destroy(socket);
      }
    }
    debug("Secure Connections destroyed : " + secureCounter);
    debug("Secure Connection Counter    : " + secureConnectionCounter);
  }
  server.on("request", (req, res) => {
    req.socket._isIdle = false;
    if (isShuttingDown && !res.headersSent) {
      res.setHeader("connection", "close");
    }
    res.on("finish", () => {
      req.socket._isIdle = true;
      destroy(req.socket);
    });
  });
  server.on("connection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = connectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      connections[id] = socket;
      socket.once("close", () => {
        delete connections[socket._connectionId];
      });
    }
  });
  server.on("secureConnection", (socket) => {
    if (isShuttingDown) {
      socket.destroy();
    } else {
      const id = secureConnectionCounter++;
      socket._isIdle = true;
      socket._connectionId = id;
      secureConnections[id] = socket;
      socket.once("close", () => {
        delete secureConnections[socket._connectionId];
      });
    }
  });
  process.on("close", () => {
    debug("closed");
  });
  function shutdown(sig) {
    function cleanupHttp() {
      destroyAllConnections();
      debug("Close http server");
      return new Promise((resolve, reject) => {
        server.close((err) => {
          if (err) {
            return reject(err);
          }
          return resolve(true);
        });
      });
    }
    debug("shutdown signal - " + sig);
    if (options.development) {
      debug("DEV-Mode - immediate forceful shutdown");
      return process.exit(0);
    }
    function finalHandler() {
      if (!finalRun) {
        finalRun = true;
        if (options.finally && isFunction(options.finally)) {
          debug("executing finally()");
          options.finally();
        }
      }
      return Promise.resolve();
    }
    function waitForReadyToShutDown(totalNumInterval) {
      debug(`waitForReadyToShutDown... ${totalNumInterval}`);
      if (totalNumInterval === 0) {
        debug(
          `Could not close connections in time (${options.timeout}ms), will forcefully shut down`
        );
        return Promise.resolve(true);
      }
      const allConnectionsClosed = Object.keys(connections).length === 0 && Object.keys(secureConnections).length === 0;
      if (allConnectionsClosed) {
        debug("All connections closed. Continue to shutting down");
        return Promise.resolve(false);
      }
      debug("Schedule the next waitForReadyToShutdown");
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve(waitForReadyToShutDown(totalNumInterval - 1));
        }, 250);
      });
    }
    if (isShuttingDown) {
      return Promise.resolve();
    }
    debug("shutting down");
    return options.preShutdown(sig).then(() => {
      isShuttingDown = true;
      cleanupHttp();
    }).then(() => {
      const pollIterations = options.timeout ? Math.round(options.timeout / 250) : 0;
      return waitForReadyToShutDown(pollIterations);
    }).then((force) => {
      debug("Do onShutdown now");
      if (force) {
        destroyAllConnections(force);
      }
      return options.onShutdown(sig);
    }).then(finalHandler).catch((error) => {
      const errString = typeof error === "string" ? error : JSON.stringify(error);
      debug(errString);
      failed = true;
      throw errString;
    });
  }
  function shutdownManual() {
    return shutdown("manual");
  }
  return shutdownManual;
}

function getGracefulShutdownConfig() {
  return {
    disabled: !!process.env.NITRO_SHUTDOWN_DISABLED,
    signals: (process.env.NITRO_SHUTDOWN_SIGNALS || "SIGTERM SIGINT").split(" ").map((s) => s.trim()),
    timeout: Number.parseInt(process.env.NITRO_SHUTDOWN_TIMEOUT || "", 10) || 3e4,
    forceExit: !process.env.NITRO_SHUTDOWN_NO_FORCE_EXIT
  };
}
function setupGracefulShutdown(listener, nitroApp) {
  const shutdownConfig = getGracefulShutdownConfig();
  if (shutdownConfig.disabled) {
    return;
  }
  GracefulShutdown(listener, {
    signals: shutdownConfig.signals.join(" "),
    timeout: shutdownConfig.timeout,
    forceExit: shutdownConfig.forceExit,
    onShutdown: async () => {
      await new Promise((resolve) => {
        const timeout = setTimeout(() => {
          console.warn("Graceful shutdown timeout, force exiting...");
          resolve();
        }, shutdownConfig.timeout);
        nitroApp.hooks.callHook("close").catch((error) => {
          console.error(error);
        }).finally(() => {
          clearTimeout(timeout);
          resolve();
        });
      });
    }
  });
}

const cert = process.env.NITRO_SSL_CERT;
const key = process.env.NITRO_SSL_KEY;
const nitroApp = useNitroApp();
const server = cert && key ? new Server({ key, cert }, toNodeListener(nitroApp.h3App)) : new Server$1(toNodeListener(nitroApp.h3App));
const port = destr(process.env.NITRO_PORT || process.env.PORT) || 3e3;
const host = process.env.NITRO_HOST || process.env.HOST;
const path = process.env.NITRO_UNIX_SOCKET;
const listener = server.listen(path ? { path } : { port, host }, (err) => {
  if (err) {
    console.error(err);
    process.exit(1);
  }
  const protocol = cert && key ? "https" : "http";
  const addressInfo = listener.address();
  if (typeof addressInfo === "string") {
    console.log(`Listening on unix socket ${addressInfo}`);
    return;
  }
  const baseURL = (useRuntimeConfig().app.baseURL || "").replace(/\/$/, "");
  const url = `${protocol}://${addressInfo.family === "IPv6" ? `[${addressInfo.address}]` : addressInfo.address}:${addressInfo.port}${baseURL}`;
  console.log(`Listening on ${url}`);
});
trapUnhandledNodeErrors();
setupGracefulShutdown(listener, nitroApp);
const nodeServer = {};

export { $fetch as $, deleteCookie as A, hash$1 as B, defu as C, executeAsync as D, parseQuery as E, withTrailingSlash as F, withoutTrailingSlash as G, nodeServer as H, defineRenderHandler as a, destr as b, createError$1 as c, defineEventHandler as d, encodePath as e, getRouteRules as f, getQuery as g, getResponseStatusText as h, getResponseStatus as i, joinRelativeURL as j, useNitroApp as k, decodePath as l, hasProtocol as m, isScriptProtocol as n, joinURL as o, parseURL as p, klona as q, sanitizeStatusCode as r, setHeader as s, getContext as t, useRuntimeConfig as u, getRequestHeader as v, withQuery as w, isEqual as x, setCookie as y, getCookie as z };
//# sourceMappingURL=nitro.mjs.map
