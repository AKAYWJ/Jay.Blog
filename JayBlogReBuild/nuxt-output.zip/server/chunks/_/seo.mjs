const SITE_NAME = "Jay.Blog";
const SITE_DESCRIPTION = "\u5206\u4EAB\u524D\u7AEF\u5F00\u53D1\u3001\u540E\u7AEF\u67B6\u6784\u3001AI \u4E0E\u751F\u6D3B\u601D\u8003\u7684\u4E2A\u4EBA\u6280\u672F\u535A\u5BA2";
const SITE_AUTHOR = "Jay";
const SITE_URL = "https://blog.jaywk.top";

export { SITE_URL as S, SITE_AUTHOR as a, SITE_NAME as b, SITE_DESCRIPTION as c };
//# sourceMappingURL=seo.mjs.map
