import { d as defineEventHandler, s as setHeader } from '../nitro/nitro.mjs';
import { S as SITE_URL } from '../_/seo.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const robots_txt = defineEventHandler((event) => {
  setHeader(event, "Content-Type", "text/plain; charset=utf-8");
  return `User-agent: *
Allow: /
Disallow: /admin
Disallow: /login
Disallow: /front/profile

Sitemap: ${SITE_URL}/sitemap.xml
`;
});

export { robots_txt as default };
//# sourceMappingURL=robots.txt.mjs.map
