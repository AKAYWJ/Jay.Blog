import { d as defineEventHandler, s as setHeader, u as useRuntimeConfig } from '../nitro/nitro.mjs';
import { S as SITE_URL, a as SITE_AUTHOR, b as SITE_NAME, c as SITE_DESCRIPTION } from '../_/seo.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const rss_xml = defineEventHandler(async (event) => {
  var _a;
  setHeader(event, "Content-Type", "application/xml; charset=utf-8");
  const config = useRuntimeConfig();
  const apiBase = config.public.apiBase || "http://localhost:8086";
  let articles = [];
  try {
    const res = await $fetch(`${apiBase}/article/front/list`, {
      params: { pageNum: 1, pageSize: 20 }
    });
    articles = (((_a = res == null ? void 0 : res.data) == null ? void 0 : _a.records) || []).filter((a) => a.status === 2);
  } catch (err) {
    console.error("[RSS] Failed to fetch articles:", err);
  }
  const buildDate = (/* @__PURE__ */ new Date()).toUTCString();
  const now = Date.now();
  const escapeXml = (s) => String(s || "").replace(/&/g, "&").replace(/</g, "<").replace(/>/g, ">").replace(/"/g, '"').replace(/'/g, "&apos;");
  const items = articles.map((a) => {
    const link = `${SITE_URL}/article?id=${a.id}`;
    const pubDate = a.updateTime ? new Date(a.updateTime).toUTCString() : new Date(a.createTime || now).toUTCString();
    const description = (a.summary || "").slice(0, 300);
    return `    <item>
      <title>${escapeXml(a.title)}</title>
      <link>${link}</link>
      <guid isPermaLink="true">${link}</guid>
      <pubDate>${pubDate}</pubDate>
      <author>noreply@jaywk.top (${escapeXml(SITE_AUTHOR)})</author>
      <description>${escapeXml(description)}</description>
    </item>`;
  }).join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${escapeXml(SITE_NAME)}</title>
    <link>${SITE_URL}</link>
    <atom:link href="${SITE_URL}/rss.xml" rel="self" type="application/rss+xml" />
    <description>${escapeXml(SITE_DESCRIPTION)}</description>
    <language>zh-CN</language>
    <lastBuildDate>${buildDate}</lastBuildDate>
    <generator>Jay.Blog RSS Generator</generator>
${items}
  </channel>
</rss>`;
});

export { rss_xml as default };
//# sourceMappingURL=rss.xml.mjs.map
