import { d as defineEventHandler, s as setHeader } from '../nitro/nitro.mjs';
import { S as SITE_URL } from '../_/seo.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

const sitemap_xml = defineEventHandler((event) => {
  setHeader(event, "Content-Type", "application/xml; charset=utf-8");
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const urls = [
    { loc: `${SITE_URL}/`, changefreq: "daily", priority: "1.0" },
    { loc: `${SITE_URL}/front`, changefreq: "daily", priority: "1.0" },
    { loc: `${SITE_URL}/front/timeline`, changefreq: "weekly", priority: "0.8" },
    { loc: `${SITE_URL}/front/category/all`, changefreq: "weekly", priority: "0.8" },
    { loc: `${SITE_URL}/front/about`, changefreq: "monthly", priority: "0.6" },
    { loc: `${SITE_URL}/articlelist`, changefreq: "daily", priority: "0.9" }
  ];
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${urls.map((u) => `  <url>
    <loc>${u.loc}</loc>
    <lastmod>${now}</lastmod>
    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`).join("\n")}
</urlset>`;
  return xml;
});

export { sitemap_xml as default };
//# sourceMappingURL=sitemap.xml.mjs.map
