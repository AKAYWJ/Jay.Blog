import{C as r,Y as t}from"./-unCOHro.js";const n={};function o(e,s){return t(e.$slots,"default")}const a=r(n,[["render",o]]);export{a as default};
