import{cX as e,cU as t}from"./-unCOHro.js";const r=e(()=>t("/front",{}));export{r as default};
