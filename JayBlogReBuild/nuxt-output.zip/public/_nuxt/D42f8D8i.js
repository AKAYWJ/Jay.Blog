import{a as _,h as o,b_ as e}from"./-unCOHro.js";const s={__name:"front",setup(n){return(a,c)=>{const t=e;return _(),o(t)}}};export{s as default};
