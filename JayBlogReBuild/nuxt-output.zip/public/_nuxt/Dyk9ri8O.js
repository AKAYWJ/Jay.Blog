import{a as e,c as t}from"./-unCOHro.js";const o={__name:"index",setup(a){return(c,r)=>(e(),t("div"))}};export{o as default};
